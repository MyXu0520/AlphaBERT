import argparse
import csv
import json
import os
from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import numpy as np
import torch
from transformers import BertConfig, BertForSequenceClassification, DNATokenizer

def iter_batches(path, batch_size):
    rows = []
    with Path(path).open(encoding='utf-8-sig') as handle:
        for index, line in enumerate(handle):
            parts = line.strip().split()
            if not parts or parts[0].lower() in {'sequence', 'label', 'kmer1', '5mer1'}:
                continue
            if parts[-1] in {'0', '1'}:
                raise ValueError(f'预测文件应只有序列，不应含标签: {path}, 第 {index + 1} 行')
            rows.append((index, ' '.join(parts)))
            if len(rows) >= batch_size:
                yield rows
                rows = []
    if rows:
        yield rows

def predict_file(path, output, model, tokenizer, device, batch_size, max_length, fp16=False):
    output = Path(output)
    output.mkdir(parents=True, exist_ok=True)
    temporary = output / 'predictions.csv.tmp'
    count = 0
    probabilities = []
    model.eval()
    with temporary.open('w', encoding='utf-8', newline='') as handle:
        writer = csv.writer(handle)
        writer.writerow(['read_id', 'prediction', 'probability'])
        for rows in iter_batches(path, batch_size):
            encoded = tokenizer.batch_encode_plus([text for _, text in rows], max_length=max_length, pad_to_max_length=True, return_tensors='pt')
            inputs = {key: value.to(device) for key, value in encoded.items() if key in {'input_ids', 'attention_mask', 'token_type_ids'}}
            with torch.no_grad(), torch.cuda.amp.autocast(enabled=fp16 and device.type == 'cuda'):
                logits = model(**inputs)[0]
                if logits.ndim != 2 or logits.shape[1] != 2:
                    raise ValueError('预测需要具有两个类别的分类模型')
                probs = torch.softmax(logits, dim=1).float().cpu().numpy()
            predictions = probs.argmax(axis=1)
            for (read_id, _), prediction, prob in zip(rows, predictions, probs[:, 1]):
                writer.writerow([read_id, int(prediction), float(prob)])
            probabilities.append(probs)
            count += len(rows)
    if count == 0:
        temporary.unlink(missing_ok=True)
        raise ValueError(f'没有可预测的序列: {path}')
    raw_temp = output / 'raw_predictions.npy.tmp'
    with raw_temp.open('wb') as handle:
        np.save(handle, np.vstack(probabilities), allow_pickle=False)
    os.replace(raw_temp, output / 'raw_predictions.npy')
    os.replace(temporary, output / 'predictions.csv')
    return count

def main():
    parser = argparse.ArgumentParser(description='AlphaBERT 批量读段预测')
    parser.add_argument('--model', type=Path, required=True)
    parser.add_argument('--input', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--batch-size', type=int, default=32)
    parser.add_argument('--max-length', type=int, default=200)
    parser.add_argument('--device', choices=['auto', 'cpu', 'cuda'], default='auto')
    parser.add_argument('--fp16', action='store_true')
    args = parser.parse_args()
    if args.batch_size < 1 or args.max_length < 3:
        parser.error('batch-size 必须为正数，max-length 至少为 3')
    if not args.model.is_dir():
        parser.error(f'模型目录不存在: {args.model}')
    if args.input.resolve() == args.output.resolve() or args.input.resolve() in args.output.resolve().parents:
        parser.error('输出目录必须位于输入目录之外')
    device = torch.device('cuda' if args.device == 'auto' and torch.cuda.is_available() else 'cpu' if args.device == 'auto' else args.device)
    if device.type == 'cuda' and (not torch.cuda.is_available()):
        parser.error('CUDA 不可用')
    config = BertConfig.from_pretrained(str(args.model))
    model, info = BertForSequenceClassification.from_pretrained(str(args.model), config=config, output_loading_info=True)
    missing_head = [key for key in info['missing_keys'] if 'classifier.' in key]
    if missing_head:
        raise ValueError('模型缺少训练好的分类头，请先微调后再预测')
    if config.num_labels != 2:
        raise ValueError('模型必须是二分类模型')
    if args.max_length > config.max_position_embeddings:
        parser.error('max-length 超过模型位置嵌入长度')
    model.to(device)
    tokenizer = DNATokenizer.from_pretrained(str(args.model), do_lower_case=False)
    files = [args.input] if args.input.is_file() else sorted(args.input.rglob('pred.tsv'))
    if not files:
        raise FileNotFoundError('没有找到 pred.tsv')
    report = []
    for path in files:
        relative = Path('.') if args.input.is_file() else path.parent.relative_to(args.input)
        target = args.output / relative
        count = predict_file(path, target, model, tokenizer, device, args.batch_size, args.max_length, args.fp16)
        report.append({'sample': str(relative), 'reads': count, 'output': str(target)})
        print(f'{path}: {count} 条序列')
    (args.output / 'batch_summary.json').write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
if __name__ == '__main__':
    main()
