import logging
from .configuration_roberta import RobertaConfig
logger = logging.getLogger(__name__)
CAMEMBERT_PRETRAINED_CONFIG_ARCHIVE_MAP = {'camembert-base': 'https://s3.amazonaws.com/models.huggingface.co/bert/camembert-base-config.json', 'umberto-commoncrawl-cased-v1': 'https://s3.amazonaws.com/models.huggingface.co/bert/Musixmatch/umberto-commoncrawl-cased-v1/config.json', 'umberto-wikipedia-uncased-v1': 'https://s3.amazonaws.com/models.huggingface.co/bert/Musixmatch/umberto-wikipedia-uncased-v1/config.json'}

class CamembertConfig(RobertaConfig):
    pretrained_config_archive_map = CAMEMBERT_PRETRAINED_CONFIG_ARCHIVE_MAP
    model_type = 'camembert'
