import logging
from .configuration_xlm_roberta import XLMRobertaConfig
from .file_utils import add_start_docstrings
from .modeling_roberta import RobertaForMaskedLM, RobertaForMultipleChoice, RobertaForSequenceClassification, RobertaForTokenClassification, RobertaModel
logger = logging.getLogger(__name__)
XLM_ROBERTA_PRETRAINED_MODEL_ARCHIVE_MAP = {'xlm-roberta-base': 'https://s3.amazonaws.com/models.huggingface.co/bert/xlm-roberta-base-pytorch_model.bin', 'xlm-roberta-large': 'https://s3.amazonaws.com/models.huggingface.co/bert/xlm-roberta-large-pytorch_model.bin', 'xlm-roberta-large-finetuned-conll02-dutch': 'https://s3.amazonaws.com/models.huggingface.co/bert/xlm-roberta-large-finetuned-conll02-dutch-pytorch_model.bin', 'xlm-roberta-large-finetuned-conll02-spanish': 'https://s3.amazonaws.com/models.huggingface.co/bert/xlm-roberta-large-finetuned-conll02-spanish-pytorch_model.bin', 'xlm-roberta-large-finetuned-conll03-english': 'https://s3.amazonaws.com/models.huggingface.co/bert/xlm-roberta-large-finetuned-conll03-english-pytorch_model.bin', 'xlm-roberta-large-finetuned-conll03-german': 'https://s3.amazonaws.com/models.huggingface.co/bert/xlm-roberta-large-finetuned-conll03-german-pytorch_model.bin'}
XLM_ROBERTA_START_DOCSTRING = '\n\n    This model is a PyTorch `torch.nn.Module <https://pytorch.org/docs/stable/nn.html#torch.nn.Module>`_ sub-class.\n    Use it as a regular PyTorch Module and refer to the PyTorch documentation for all matter related to general\n    usage and behavior.\n\n    Parameters:\n        config (:class:`~transformers.XLMRobertaConfig`): Model configuration class with all the parameters of the\n            model. Initializing with a config file does not load the weights associated with the model, only the configuration.\n            Check out the :meth:`~transformers.PreTrainedModel.from_pretrained` method to load the model weights.\n'

@add_start_docstrings('The bare XLM-RoBERTa Model transformer outputting raw hidden-states without any specific head on top.', XLM_ROBERTA_START_DOCSTRING)
class XLMRobertaModel(RobertaModel):
    config_class = XLMRobertaConfig
    pretrained_model_archive_map = XLM_ROBERTA_PRETRAINED_MODEL_ARCHIVE_MAP

@add_start_docstrings('XLM-RoBERTa Model with a `language modeling` head on top. ', XLM_ROBERTA_START_DOCSTRING)
class XLMRobertaForMaskedLM(RobertaForMaskedLM):
    config_class = XLMRobertaConfig
    pretrained_model_archive_map = XLM_ROBERTA_PRETRAINED_MODEL_ARCHIVE_MAP

@add_start_docstrings('XLM-RoBERTa Model transformer with a sequence classification/regression head on top (a linear layer\n    on top of the pooled output) e.g. for GLUE tasks. ', XLM_ROBERTA_START_DOCSTRING)
class XLMRobertaForSequenceClassification(RobertaForSequenceClassification):
    config_class = XLMRobertaConfig
    pretrained_model_archive_map = XLM_ROBERTA_PRETRAINED_MODEL_ARCHIVE_MAP

@add_start_docstrings('XLM-RoBERTa Model with a multiple choice classification head on top (a linear layer on top of\n    the pooled output and a softmax) e.g. for RocStories/SWAG tasks. ', XLM_ROBERTA_START_DOCSTRING)
class XLMRobertaForMultipleChoice(RobertaForMultipleChoice):
    config_class = XLMRobertaConfig
    pretrained_model_archive_map = XLM_ROBERTA_PRETRAINED_MODEL_ARCHIVE_MAP

@add_start_docstrings('XLM-RoBERTa Model with a token classification head on top (a linear layer on top of\n    the hidden-states output) e.g. for Named-Entity-Recognition (NER) tasks. ', XLM_ROBERTA_START_DOCSTRING)
class XLMRobertaForTokenClassification(RobertaForTokenClassification):
    config_class = XLMRobertaConfig
    pretrained_model_archive_map = XLM_ROBERTA_PRETRAINED_MODEL_ARCHIVE_MAP
