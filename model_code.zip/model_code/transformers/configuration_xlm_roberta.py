import logging
from .configuration_roberta import RobertaConfig
logger = logging.getLogger(__name__)
XLM_ROBERTA_PRETRAINED_CONFIG_ARCHIVE_MAP = {'xlm-roberta-base': 'https://s3.amazonaws.com/models.huggingface.co/bert/xlm-roberta-base-config.json', 'xlm-roberta-large': 'https://s3.amazonaws.com/models.huggingface.co/bert/xlm-roberta-large-config.json', 'xlm-roberta-large-finetuned-conll02-dutch': 'https://s3.amazonaws.com/models.huggingface.co/bert/xlm-roberta-large-finetuned-conll02-dutch-config.json', 'xlm-roberta-large-finetuned-conll02-spanish': 'https://s3.amazonaws.com/models.huggingface.co/bert/xlm-roberta-large-finetuned-conll02-spanish-config.json', 'xlm-roberta-large-finetuned-conll03-english': 'https://s3.amazonaws.com/models.huggingface.co/bert/xlm-roberta-large-finetuned-conll03-english-config.json', 'xlm-roberta-large-finetuned-conll03-german': 'https://s3.amazonaws.com/models.huggingface.co/bert/xlm-roberta-large-finetuned-conll03-german-config.json'}

class XLMRobertaConfig(RobertaConfig):
    pretrained_config_archive_map = XLM_ROBERTA_PRETRAINED_CONFIG_ARCHIVE_MAP
    model_type = 'xlm-roberta'
