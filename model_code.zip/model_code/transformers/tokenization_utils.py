import copy
import itertools
import json
import logging
import os
import re
from collections import defaultdict
from contextlib import contextmanager
from tokenizers.implementations import BaseTokenizer
from .file_utils import cached_path, hf_bucket_url, is_remote_url, is_tf_available, is_torch_available
if is_tf_available():
    import tensorflow as tf
if is_torch_available():
    import torch
logger = logging.getLogger(__name__)
SPECIAL_TOKENS_MAP_FILE = 'special_tokens_map.json'
ADDED_TOKENS_FILE = 'added_tokens.json'
TOKENIZER_CONFIG_FILE = 'tokenizer_config.json'

@contextmanager
def truncate_and_pad(tokenizer: BaseTokenizer, max_length: int, stride: int, strategy: str, pad_to_max_length: bool, padding_side: str, pad_token_id: int, pad_token_type_id: int, pad_token: str):
    if max_length is not None:
        tokenizer.enable_truncation(max_length, stride=stride, strategy=strategy)
    if pad_to_max_length and (pad_token and pad_token_id >= 0):
        tokenizer.enable_padding(max_length=None, direction=padding_side, pad_id=pad_token_id, pad_type_id=pad_token_type_id, pad_token=pad_token)
    elif pad_to_max_length:
        logger.warning("Disabled padding because no padding token set (pad_token: {}, pad_token_id: {}).\nTo remove this error, you can add a new pad token and then resize model embedding:\n\ttokenizer.pad_token = '<PAD>'\n\tmodel.resize_token_embeddings(len(tokenizer))".format(pad_token, pad_token_id))
    yield
    if max_length is not None:
        tokenizer.no_truncation()
    if pad_to_max_length and (pad_token and pad_token_id >= 0):
        tokenizer.no_padding()

class PreTrainedTokenizer(object):
    vocab_files_names = {}
    pretrained_vocab_files_map = {}
    pretrained_init_configuration = {}
    max_model_input_sizes = {}
    SPECIAL_TOKENS_ATTRIBUTES = ['bos_token', 'eos_token', 'unk_token', 'sep_token', 'pad_token', 'cls_token', 'mask_token', 'additional_special_tokens']
    padding_side = 'right'

    @property
    def bos_token(self):
        if self._bos_token is None:
            logger.error('Using bos_token, but it is not set yet.')
        return self._bos_token

    @property
    def eos_token(self):
        if self._eos_token is None:
            logger.error('Using eos_token, but it is not set yet.')
        return self._eos_token

    @property
    def unk_token(self):
        if self._unk_token is None:
            logger.error('Using unk_token, but it is not set yet.')
        return self._unk_token

    @property
    def sep_token(self):
        if self._sep_token is None:
            logger.error('Using sep_token, but it is not set yet.')
        return self._sep_token

    @property
    def pad_token(self):
        if self._pad_token is None:
            logger.error('Using pad_token, but it is not set yet.')
        return self._pad_token

    @property
    def cls_token(self):
        if self._cls_token is None:
            logger.error('Using cls_token, but it is not set yet.')
        return self._cls_token

    @property
    def mask_token(self):
        if self._mask_token is None:
            logger.error('Using mask_token, but it is not set yet.')
        return self._mask_token

    @property
    def additional_special_tokens(self):
        if self._additional_special_tokens is None:
            logger.error('Using additional_special_tokens, but it is not set yet.')
        return self._additional_special_tokens

    @bos_token.setter
    def bos_token(self, value):
        self._bos_token = value

    @eos_token.setter
    def eos_token(self, value):
        self._eos_token = value

    @unk_token.setter
    def unk_token(self, value):
        self._unk_token = value

    @sep_token.setter
    def sep_token(self, value):
        self._sep_token = value

    @pad_token.setter
    def pad_token(self, value):
        self._pad_token = value

    @cls_token.setter
    def cls_token(self, value):
        self._cls_token = value

    @mask_token.setter
    def mask_token(self, value):
        self._mask_token = value

    @additional_special_tokens.setter
    def additional_special_tokens(self, value):
        self._additional_special_tokens = value

    @property
    def bos_token_id(self):
        return self.convert_tokens_to_ids(self.bos_token)

    @property
    def eos_token_id(self):
        return self.convert_tokens_to_ids(self.eos_token)

    @property
    def unk_token_id(self):
        return self.convert_tokens_to_ids(self.unk_token)

    @property
    def sep_token_id(self):
        return self.convert_tokens_to_ids(self.sep_token)

    @property
    def pad_token_id(self):
        return self.convert_tokens_to_ids(self.pad_token)

    @property
    def pad_token_type_id(self):
        return self._pad_token_type_id

    @property
    def cls_token_id(self):
        return self.convert_tokens_to_ids(self.cls_token)

    @property
    def mask_token_id(self):
        return self.convert_tokens_to_ids(self.mask_token)

    @property
    def additional_special_tokens_ids(self):
        return self.convert_tokens_to_ids(self.additional_special_tokens)

    def __init__(self, max_len=None, **kwargs):
        self._bos_token = None
        self._eos_token = None
        self._unk_token = None
        self._sep_token = None
        self._pad_token = None
        self._cls_token = None
        self._mask_token = None
        self._pad_token_type_id = 0
        self._additional_special_tokens = []
        self.max_len = max_len if max_len is not None else int(1000000000000.0)
        self.padding_side = kwargs.pop('padding_side', self.padding_side)
        self.added_tokens_encoder = {}
        self.unique_added_tokens_encoder = set()
        self.added_tokens_decoder = {}
        self.init_inputs = ()
        self.init_kwargs = {}
        for key, value in kwargs.items():
            if key in self.SPECIAL_TOKENS_ATTRIBUTES:
                if key == 'additional_special_tokens':
                    assert isinstance(value, (list, tuple)) and all((isinstance(t, str) for t in value))
                else:
                    assert isinstance(value, str)
                setattr(self, key, value)

    @classmethod
    def from_pretrained(cls, *inputs, **kwargs):
        print('=' * 60)
        print(cls)
        return cls._from_pretrained(*inputs, **kwargs)

    @classmethod
    def _from_pretrained(cls, pretrained_model_name_or_path, *init_inputs, **kwargs):
        cache_dir = kwargs.pop('cache_dir', None)
        force_download = kwargs.pop('force_download', False)
        resume_download = kwargs.pop('resume_download', False)
        proxies = kwargs.pop('proxies', None)
        s3_models = list(cls.max_model_input_sizes.keys())
        vocab_files = {}
        init_configuration = {}
        if pretrained_model_name_or_path in s3_models:
            for file_id, map_list in cls.pretrained_vocab_files_map.items():
                vocab_files[file_id] = map_list[pretrained_model_name_or_path]
            if cls.pretrained_init_configuration and pretrained_model_name_or_path in cls.pretrained_init_configuration:
                init_configuration = cls.pretrained_init_configuration[pretrained_model_name_or_path].copy()
        else:
            logger.info("Model name '{}' not found in model shortcut name list ({}). Assuming '{}' is a path, a model identifier, or url to a directory containing tokenizer files.".format(pretrained_model_name_or_path, ', '.join(s3_models), pretrained_model_name_or_path))
            if os.path.isfile(pretrained_model_name_or_path) or is_remote_url(pretrained_model_name_or_path):
                if len(cls.vocab_files_names) > 1:
                    raise ValueError('Calling {}.from_pretrained() with the path to a single file or url is not supported.Use a model identifier or the path to a directory instead.'.format(cls.__name__))
                logger.warning('Calling {}.from_pretrained() with the path to a single file or url is deprecated'.format(cls.__name__))
                file_id = list(cls.vocab_files_names.keys())[0]
                vocab_files[file_id] = pretrained_model_name_or_path
            else:
                additional_files_names = {'added_tokens_file': ADDED_TOKENS_FILE, 'special_tokens_map_file': SPECIAL_TOKENS_MAP_FILE, 'tokenizer_config_file': TOKENIZER_CONFIG_FILE}
                for file_id, file_name in {**cls.vocab_files_names, **additional_files_names}.items():
                    if os.path.isdir(pretrained_model_name_or_path):
                        full_file_name = os.path.join(pretrained_model_name_or_path, file_name)
                        if not os.path.exists(full_file_name):
                            logger.info("Didn't find file {}. We won't load it.".format(full_file_name))
                            full_file_name = None
                    else:
                        full_file_name = hf_bucket_url(pretrained_model_name_or_path, postfix=file_name)
                    vocab_files[file_id] = full_file_name
        try:
            resolved_vocab_files = {}
            for file_id, file_path in vocab_files.items():
                if file_path is None:
                    resolved_vocab_files[file_id] = None
                else:
                    resolved_vocab_files[file_id] = cached_path(file_path, cache_dir=cache_dir, force_download=force_download, proxies=proxies, resume_download=resume_download)
        except EnvironmentError:
            if pretrained_model_name_or_path in s3_models:
                msg = "Couldn't reach server at '{}' to download vocabulary files."
            else:
                msg = "Model name '{}' was not found in tokenizers model name list ({}). We assumed '{}' was a path or url to a directory containing vocabulary files named {}, but couldn't find such vocabulary files at this path or url.".format(pretrained_model_name_or_path, ', '.join(s3_models), pretrained_model_name_or_path, list(cls.vocab_files_names.values()))
            raise EnvironmentError(msg)
        if all((full_file_name is None for full_file_name in resolved_vocab_files.values())):
            raise EnvironmentError("Model name '{}' was not found in tokenizers model name list ({}). We assumed '{}' was a path, a model identifier, or url to a directory containing vocabulary files named {} but couldn't find such vocabulary files at this path or url.".format(pretrained_model_name_or_path, ', '.join(s3_models), pretrained_model_name_or_path, list(cls.vocab_files_names.values())))
        for file_id, file_path in vocab_files.items():
            if file_path == resolved_vocab_files[file_id]:
                logger.info('loading file {}'.format(file_path))
            else:
                logger.info('loading file {} from cache at {}'.format(file_path, resolved_vocab_files[file_id]))
        tokenizer_config_file = resolved_vocab_files.pop('tokenizer_config_file', None)
        if tokenizer_config_file is not None:
            with open(tokenizer_config_file, encoding='utf-8') as tokenizer_config_handle:
                init_kwargs = json.load(tokenizer_config_handle)
            saved_init_inputs = init_kwargs.pop('init_inputs', ())
            if not init_inputs:
                init_inputs = saved_init_inputs
        else:
            init_kwargs = init_configuration
        init_kwargs.update(kwargs)
        if pretrained_model_name_or_path in cls.max_model_input_sizes:
            max_len = cls.max_model_input_sizes[pretrained_model_name_or_path]
            if max_len is not None and isinstance(max_len, (int, float)):
                init_kwargs['max_len'] = min(init_kwargs.get('max_len', int(1000000000000.0)), max_len)
        added_tokens_file = resolved_vocab_files.pop('added_tokens_file', None)
        special_tokens_map_file = resolved_vocab_files.pop('special_tokens_map_file', None)
        for args_name, file_path in resolved_vocab_files.items():
            if args_name not in init_kwargs:
                init_kwargs[args_name] = file_path
        if special_tokens_map_file is not None:
            with open(special_tokens_map_file, encoding='utf-8') as special_tokens_map_handle:
                special_tokens_map = json.load(special_tokens_map_handle)
            for key, value in special_tokens_map.items():
                if key not in init_kwargs:
                    init_kwargs[key] = value
        try:
            tokenizer = cls(*init_inputs, **init_kwargs)
        except OSError:
            raise OSError('Unable to load vocabulary from file. Please check that the provided vocabulary is accessible and not corrupted.')
        tokenizer.init_inputs = init_inputs
        tokenizer.init_kwargs = init_kwargs
        tokenizer.unique_added_tokens_encoder.update(set(tokenizer.all_special_tokens))
        if added_tokens_file is not None:
            with open(added_tokens_file, encoding='utf-8') as added_tokens_handle:
                added_tok_encoder = json.load(added_tokens_handle)
            added_tok_decoder = {v: k for k, v in added_tok_encoder.items()}
            tokenizer.added_tokens_encoder.update(added_tok_encoder)
            tokenizer.added_tokens_decoder.update(added_tok_decoder)
            tokenizer.unique_added_tokens_encoder.update(set(tokenizer.added_tokens_encoder.keys()))
        return tokenizer

    def save_pretrained(self, save_directory):
        if not os.path.isdir(save_directory):
            logger.error('Saving directory ({}) should be a directory'.format(save_directory))
            return
        special_tokens_map_file = os.path.join(save_directory, SPECIAL_TOKENS_MAP_FILE)
        added_tokens_file = os.path.join(save_directory, ADDED_TOKENS_FILE)
        tokenizer_config_file = os.path.join(save_directory, TOKENIZER_CONFIG_FILE)
        tokenizer_config = copy.deepcopy(self.init_kwargs)
        if len(self.init_inputs) > 0:
            tokenizer_config['init_inputs'] = copy.deepcopy(self.init_inputs)
        for file_id in self.vocab_files_names.keys():
            tokenizer_config.pop(file_id, None)
        with open(tokenizer_config_file, 'w', encoding='utf-8') as f:
            f.write(json.dumps(tokenizer_config, ensure_ascii=False))
        with open(special_tokens_map_file, 'w', encoding='utf-8') as f:
            f.write(json.dumps(self.special_tokens_map, ensure_ascii=False))
        if len(self.added_tokens_encoder) > 0:
            with open(added_tokens_file, 'w', encoding='utf-8') as f:
                out_str = json.dumps(self.added_tokens_encoder, ensure_ascii=False)
                f.write(out_str)
        vocab_files = self.save_vocabulary(save_directory)
        return vocab_files + (special_tokens_map_file, added_tokens_file)

    def save_vocabulary(self, save_directory):
        raise NotImplementedError

    def vocab_size(self):
        raise NotImplementedError

    def __len__(self):
        return self.vocab_size + len(self.added_tokens_encoder)

    def add_tokens(self, new_tokens):
        if not new_tokens:
            return 0
        if not isinstance(new_tokens, list):
            new_tokens = [new_tokens]
        to_add_tokens = []
        for token in new_tokens:
            assert isinstance(token, str)
            if self.init_kwargs.get('do_lower_case', False) and token not in self.all_special_tokens:
                token = token.lower()
            if token != self.unk_token and self.convert_tokens_to_ids(token) == self.convert_tokens_to_ids(self.unk_token) and (token not in to_add_tokens):
                to_add_tokens.append(token)
                logger.info('Adding %s to the vocabulary', token)
        added_tok_encoder = dict(((tok, len(self) + i) for i, tok in enumerate(to_add_tokens)))
        added_tok_decoder = {v: k for k, v in added_tok_encoder.items()}
        self.added_tokens_encoder.update(added_tok_encoder)
        self.unique_added_tokens_encoder = set(self.added_tokens_encoder.keys()).union(set(self.all_special_tokens))
        self.added_tokens_decoder.update(added_tok_decoder)
        return len(to_add_tokens)

    def num_added_tokens(self, pair=False):
        token_ids_0 = []
        token_ids_1 = []
        return len(self.build_inputs_with_special_tokens(token_ids_0, token_ids_1 if pair else None))

    def add_special_tokens(self, special_tokens_dict):
        if not special_tokens_dict:
            return 0
        added_tokens = 0
        for key, value in special_tokens_dict.items():
            assert key in self.SPECIAL_TOKENS_ATTRIBUTES
            if key == 'additional_special_tokens':
                assert isinstance(value, (list, tuple)) and all((isinstance(t, str) for t in value))
                added_tokens += self.add_tokens(value)
            else:
                assert isinstance(value, str)
                added_tokens += self.add_tokens([value])
            logger.info('Assigning %s to the %s key of the tokenizer', value, key)
            setattr(self, key, value)
        return added_tokens

    def tokenize(self, text, **kwargs):
        all_special_tokens = self.all_special_tokens
        text = self.prepare_for_tokenization(text, **kwargs)

        def lowercase_text(t):
            escaped_special_toks = [re.escape(s_tok) for s_tok in all_special_tokens]
            pattern = '(' + '|'.join(escaped_special_toks) + ')|' + '(.+?)'
            return re.sub(pattern, lambda m: m.groups()[0] or m.groups()[1].lower(), t)
        if self.init_kwargs.get('do_lower_case', False):
            text = lowercase_text(text)

        def split_on_token(tok, text):
            result = []
            split_text = text.split(tok)
            for i, sub_text in enumerate(split_text):
                sub_text = sub_text.rstrip()
                if i == 0 and (not sub_text):
                    result += [tok]
                elif i == len(split_text) - 1:
                    if sub_text:
                        result += [sub_text]
                    else:
                        pass
                else:
                    if sub_text:
                        result += [sub_text]
                    result += [tok]
            return result

        def split_on_tokens(tok_list, text):
            if not text.strip():
                return []
            if not tok_list:
                return self._tokenize(text)
            tokenized_text = []
            text_list = [text]
            for tok in tok_list:
                tokenized_text = []
                for sub_text in text_list:
                    if sub_text not in self.unique_added_tokens_encoder:
                        tokenized_text += split_on_token(tok, sub_text)
                    else:
                        tokenized_text += [sub_text]
                text_list = tokenized_text
            return list(itertools.chain.from_iterable((self._tokenize(token) if token not in self.unique_added_tokens_encoder else [token] for token in tokenized_text)))
        added_tokens = self.unique_added_tokens_encoder
        tokenized_text = split_on_tokens(added_tokens, text)
        return tokenized_text

    def _tokenize(self, text, **kwargs):
        raise NotImplementedError

    def convert_tokens_to_ids(self, tokens):
        if tokens is None:
            return None
        if isinstance(tokens, str):
            return self._convert_token_to_id_with_added_voc(tokens)
        ids = []
        for token in tokens:
            ids.append(self._convert_token_to_id_with_added_voc(token))
        return ids

    def _convert_token_to_id_with_added_voc(self, token):
        if token is None:
            return None
        if token in self.added_tokens_encoder:
            return self.added_tokens_encoder[token]
        return self._convert_token_to_id(token)

    def _convert_token_to_id(self, token):
        raise NotImplementedError

    def encode(self, text, text_pair=None, add_special_tokens=True, max_length=None, stride=0, truncation_strategy='longest_first', pad_to_max_length=False, return_tensors=None, **kwargs):
        encoded_inputs = self.encode_plus(text, text_pair=text_pair, max_length=max_length, add_special_tokens=add_special_tokens, stride=stride, truncation_strategy=truncation_strategy, pad_to_max_length=pad_to_max_length, return_tensors=return_tensors, **kwargs)
        return encoded_inputs['input_ids']

    def encode_plus(self, text, text_pair=None, add_special_tokens=True, max_length=None, stride=0, truncation_strategy='longest_first', pad_to_max_length=False, return_tensors=None, return_token_type_ids=True, return_attention_mask=True, return_overflowing_tokens=False, return_special_tokens_mask=False, return_offsets_mapping=False, **kwargs):

        def get_input_ids(text):
            if isinstance(text, str):
                tokens = self.tokenize(text, add_special_tokens=add_special_tokens, **kwargs)
                return self.convert_tokens_to_ids(tokens)
            elif isinstance(text, (list, tuple)) and len(text) > 0 and isinstance(text[0], str):
                return self.convert_tokens_to_ids(text)
            elif isinstance(text, (list, tuple)) and len(text) > 0 and isinstance(text[0], int):
                return text
            else:
                raise ValueError('Input is not valid. Should be a string, a list/tuple of strings or a list/tuple of integers.')
        if return_offsets_mapping:
            raise NotImplementedError('return_offset_mapping is not available when using Python tokenizers.To use this feature, change your tokenizer to one deriving from transformers.PreTrainedTokenizerFast.More information on available tokenizers at https://github.com/huggingface/transformers/pull/2674')
        first_ids = get_input_ids(text)
        second_ids = get_input_ids(text_pair) if text_pair is not None else None
        return self.prepare_for_model(first_ids, pair_ids=second_ids, max_length=max_length, pad_to_max_length=pad_to_max_length, add_special_tokens=add_special_tokens, stride=stride, truncation_strategy=truncation_strategy, return_tensors=return_tensors, return_attention_mask=return_attention_mask, return_token_type_ids=return_token_type_ids, return_overflowing_tokens=return_overflowing_tokens, return_special_tokens_mask=return_special_tokens_mask)

    def batch_encode_plus(self, batch_text_or_text_pairs=None, add_special_tokens=False, max_length=None, stride=0, truncation_strategy='longest_first', return_tensors=None, return_input_lengths=False, return_attention_masks=False, return_offsets_mapping=False, **kwargs):
        if return_offsets_mapping:
            raise NotImplementedError('return_offset_mapping is not available when using Python tokenizers.To use this feature, change your tokenizer to one deriving from transformers.PreTrainedTokenizerFast.More information on available tokenizers at https://github.com/huggingface/transformers/pull/2674')
        batch_outputs = {}
        for ids_or_pair_ids in batch_text_or_text_pairs:
            if isinstance(ids_or_pair_ids, (list, tuple)):
                assert len(ids_or_pair_ids) == 2
                ids, pair_ids = ids_or_pair_ids
            else:
                ids, pair_ids = (ids_or_pair_ids, None)
            outputs = self.encode_plus(ids, pair_ids, add_special_tokens=add_special_tokens, max_length=max_length, stride=stride, truncation_strategy=truncation_strategy, return_tensors=None)
            if return_input_lengths:
                outputs['input_len'] = len(outputs['input_ids'])
            for key, value in outputs.items():
                if key not in batch_outputs:
                    batch_outputs[key] = []
                batch_outputs[key].append(value)
        max_seq_len = max(map(len, batch_outputs['input_ids']))
        if return_attention_masks:
            batch_outputs['attention_mask'] = [[0] * len(v) for v in batch_outputs['input_ids']]
        if return_tensors is not None:
            for key, value in batch_outputs.items():
                padded_value = value
                if key != 'input_len' and self._pad_token is not None:
                    padded_value = [v + [self.pad_token_id if key == 'input_ids' else 1] * (max_seq_len - len(v)) for v in padded_value]
                if return_tensors == 'tf' and is_tf_available():
                    batch_outputs[key] = tf.constant(padded_value)
                elif return_tensors == 'pt' and is_torch_available():
                    batch_outputs[key] = torch.tensor(padded_value)
                elif return_tensors is not None:
                    logger.warning('Unable to convert output to tensors format {}, PyTorch or TensorFlow is not available.'.format(return_tensors))
        if return_attention_masks:
            if is_tf_available():
                batch_outputs['attention_mask'] = tf.abs(batch_outputs['attention_mask'] - 1)
            else:
                batch_outputs['attention_mask'] = torch.abs(batch_outputs['attention_mask'] - 1)
        return batch_outputs

    def prepare_for_model(self, ids, pair_ids=None, max_length=None, add_special_tokens=True, stride=0, truncation_strategy='longest_first', pad_to_max_length=False, return_tensors=None, return_token_type_ids=True, return_attention_mask=True, return_overflowing_tokens=False, return_special_tokens_mask=False):
        pair = bool(pair_ids is not None)
        len_ids = len(ids)
        len_pair_ids = len(pair_ids) if pair else 0
        encoded_inputs = {}
        total_len = len_ids + len_pair_ids + (self.num_added_tokens(pair=pair) if add_special_tokens else 0)
        if max_length and total_len > max_length:
            ids, pair_ids, overflowing_tokens = self.truncate_sequences(ids, pair_ids=pair_ids, num_tokens_to_remove=total_len - max_length, truncation_strategy=truncation_strategy, stride=stride)
            if return_overflowing_tokens:
                encoded_inputs['overflowing_tokens'] = overflowing_tokens
                encoded_inputs['num_truncated_tokens'] = total_len - max_length
        if add_special_tokens:
            sequence = self.build_inputs_with_special_tokens(ids, pair_ids)
            token_type_ids = self.create_token_type_ids_from_sequences(ids, pair_ids)
        else:
            sequence = ids + pair_ids if pair else ids
            token_type_ids = [0] * len(ids) + ([1] * len(pair_ids) if pair else [])
        if return_special_tokens_mask:
            encoded_inputs['special_tokens_mask'] = self.get_special_tokens_mask(ids, pair_ids)
        encoded_inputs['input_ids'] = sequence
        if return_token_type_ids:
            encoded_inputs['token_type_ids'] = token_type_ids
        if max_length and len(encoded_inputs['input_ids']) > max_length:
            encoded_inputs['input_ids'] = encoded_inputs['input_ids'][:max_length]
            if return_token_type_ids:
                encoded_inputs['token_type_ids'] = encoded_inputs['token_type_ids'][:max_length]
            if return_special_tokens_mask:
                encoded_inputs['special_tokens_mask'] = encoded_inputs['special_tokens_mask'][:max_length]
        if max_length is None and len(encoded_inputs['input_ids']) > self.max_len:
            logger.warning('Token indices sequence length is longer than the specified maximum sequence length for this model ({} > {}). Running this sequence through the model will result in indexing errors'.format(len(ids), self.max_len))
        needs_to_be_padded = pad_to_max_length and (max_length and len(encoded_inputs['input_ids']) < max_length or (max_length is None and len(encoded_inputs['input_ids']) < self.max_len and (self.max_len <= 10000)))
        if pad_to_max_length and max_length is None and (self.max_len > 10000):
            logger.warning("Sequence can't be padded as no maximum length is specified and the model maximum length is too high.")
        if needs_to_be_padded:
            difference = (max_length if max_length is not None else self.max_len) - len(encoded_inputs['input_ids'])
            if self.padding_side == 'right':
                if return_attention_mask:
                    encoded_inputs['attention_mask'] = [1] * len(encoded_inputs['input_ids']) + [0] * difference
                if return_token_type_ids:
                    encoded_inputs['token_type_ids'] = encoded_inputs['token_type_ids'] + [self.pad_token_type_id] * difference
                if return_special_tokens_mask:
                    encoded_inputs['special_tokens_mask'] = encoded_inputs['special_tokens_mask'] + [1] * difference
                encoded_inputs['input_ids'] = encoded_inputs['input_ids'] + [self.pad_token_id] * difference
            elif self.padding_side == 'left':
                if return_attention_mask:
                    encoded_inputs['attention_mask'] = [0] * difference + [1] * len(encoded_inputs['input_ids'])
                if return_token_type_ids:
                    encoded_inputs['token_type_ids'] = [self.pad_token_type_id] * difference + encoded_inputs['token_type_ids']
                if return_special_tokens_mask:
                    encoded_inputs['special_tokens_mask'] = [1] * difference + encoded_inputs['special_tokens_mask']
                encoded_inputs['input_ids'] = [self.pad_token_id] * difference + encoded_inputs['input_ids']
            else:
                raise ValueError('Invalid padding strategy:' + str(self.padding_side))
        elif return_attention_mask:
            encoded_inputs['attention_mask'] = [1] * len(encoded_inputs['input_ids'])
        if return_tensors == 'tf' and is_tf_available():
            encoded_inputs['input_ids'] = tf.constant([encoded_inputs['input_ids']])
            if 'token_type_ids' in encoded_inputs:
                encoded_inputs['token_type_ids'] = tf.constant([encoded_inputs['token_type_ids']])
            if 'attention_mask' in encoded_inputs:
                encoded_inputs['attention_mask'] = tf.constant([encoded_inputs['attention_mask']])
        elif return_tensors == 'pt' and is_torch_available():
            encoded_inputs['input_ids'] = torch.tensor([encoded_inputs['input_ids']])
            if 'token_type_ids' in encoded_inputs:
                encoded_inputs['token_type_ids'] = torch.tensor([encoded_inputs['token_type_ids']])
            if 'attention_mask' in encoded_inputs:
                encoded_inputs['attention_mask'] = torch.tensor([encoded_inputs['attention_mask']])
        elif return_tensors is not None:
            logger.warning('Unable to convert output to tensors format {}, PyTorch or TensorFlow is not available.'.format(return_tensors))
        return encoded_inputs

    def prepare_for_tokenization(self, text, **kwargs):
        return text

    def truncate_sequences(self, ids, pair_ids=None, num_tokens_to_remove=0, truncation_strategy='longest_first', stride=0):
        if num_tokens_to_remove <= 0:
            return (ids, pair_ids, [])
        if truncation_strategy == 'longest_first':
            overflowing_tokens = []
            for _ in range(num_tokens_to_remove):
                if pair_ids is None or len(ids) > len(pair_ids):
                    overflowing_tokens = [ids[-1]] + overflowing_tokens
                    ids = ids[:-1]
                else:
                    pair_ids = pair_ids[:-1]
            window_len = min(len(ids), stride)
            if window_len > 0:
                overflowing_tokens = ids[-window_len:] + overflowing_tokens
        elif truncation_strategy == 'only_first':
            assert len(ids) > num_tokens_to_remove
            window_len = min(len(ids), stride + num_tokens_to_remove)
            overflowing_tokens = ids[-window_len:]
            ids = ids[:-num_tokens_to_remove]
        elif truncation_strategy == 'only_second':
            assert pair_ids is not None and len(pair_ids) > num_tokens_to_remove
            window_len = min(len(pair_ids), stride + num_tokens_to_remove)
            overflowing_tokens = pair_ids[-window_len:]
            pair_ids = pair_ids[:-num_tokens_to_remove]
        elif truncation_strategy == 'do_not_truncate':
            raise ValueError('Input sequence are too long for max_length. Please select a truncation strategy.')
        else:
            raise ValueError("Truncation_strategy should be selected in ['longest_first', 'only_first', 'only_second', 'do_not_truncate']")
        return (ids, pair_ids, overflowing_tokens)

    def create_token_type_ids_from_sequences(self, token_ids_0, token_ids_1=None):
        if token_ids_1 is None:
            return len(token_ids_0) * [0]
        return [0] * len(token_ids_0) + [1] * len(token_ids_1)

    def build_inputs_with_special_tokens(self, token_ids_0, token_ids_1=None):
        if token_ids_1 is None:
            return token_ids_0
        return token_ids_0 + token_ids_1

    def get_special_tokens_mask(self, token_ids_0, token_ids_1=None, already_has_special_tokens=False):
        return [0] * ((len(token_ids_1) if token_ids_1 else 0) + len(token_ids_0))

    def convert_ids_to_tokens(self, ids, skip_special_tokens=False):
        if isinstance(ids, int):
            if ids in self.added_tokens_decoder:
                return self.added_tokens_decoder[ids]
            else:
                return self._convert_id_to_token(ids)
        tokens = []
        for index in ids:
            index = int(index)
            if skip_special_tokens and index in self.all_special_ids:
                continue
            if index in self.added_tokens_decoder:
                tokens.append(self.added_tokens_decoder[index])
            else:
                tokens.append(self._convert_id_to_token(index))
        return tokens

    def _convert_id_to_token(self, index):
        raise NotImplementedError

    def convert_tokens_to_string(self, tokens):
        return ' '.join(self.convert_ids_to_tokens(tokens))

    def decode(self, token_ids, skip_special_tokens=False, clean_up_tokenization_spaces=True):
        filtered_tokens = self.convert_ids_to_tokens(token_ids, skip_special_tokens=skip_special_tokens)
        sub_texts = []
        current_sub_text = []
        for token in filtered_tokens:
            if skip_special_tokens and token in self.all_special_ids:
                continue
            if token in self.added_tokens_encoder:
                if current_sub_text:
                    sub_texts.append(self.convert_tokens_to_string(current_sub_text))
                    current_sub_text = []
                sub_texts.append(token)
            else:
                current_sub_text.append(token)
        if current_sub_text:
            sub_texts.append(self.convert_tokens_to_string(current_sub_text))
        text = ' '.join(sub_texts)
        if clean_up_tokenization_spaces:
            clean_text = self.clean_up_tokenization(text)
            return clean_text
        else:
            return text

    @property
    def special_tokens_map(self):
        set_attr = {}
        for attr in self.SPECIAL_TOKENS_ATTRIBUTES:
            attr_value = getattr(self, '_' + attr)
            if attr_value:
                set_attr[attr] = attr_value
        return set_attr

    @property
    def all_special_tokens(self):
        all_toks = []
        set_attr = self.special_tokens_map
        for attr_value in set_attr.values():
            all_toks = all_toks + (list(attr_value) if isinstance(attr_value, (list, tuple)) else [attr_value])
        all_toks = list(set(all_toks))
        return all_toks

    @property
    def all_special_ids(self):
        all_toks = self.all_special_tokens
        all_ids = self.convert_tokens_to_ids(all_toks)
        return all_ids

    @staticmethod
    def clean_up_tokenization(out_string):
        out_string = out_string.replace(' .', '.').replace(' ?', '?').replace(' !', '!').replace(' ,', ',').replace(" ' ", "'").replace(" n't", "n't").replace(" 'm", "'m").replace(' do not', " don't").replace(" 's", "'s").replace(" 've", "'ve").replace(" 're", "'re")
        return out_string

class PreTrainedTokenizerFast(PreTrainedTokenizer):

    def __init__(self, tokenizer: BaseTokenizer, **kwargs):
        if tokenizer is None:
            raise ValueError('Provided tokenizer cannot be None')
        self._tokenizer = tokenizer
        super().__init__(**kwargs)
        self.max_len_single_sentence = self.max_len - self.num_added_tokens(False)
        self.max_len_sentences_pair = self.max_len - self.num_added_tokens(True)

    @property
    def tokenizer(self):
        return self._tokenizer

    @property
    def decoder(self):
        return self._tokenizer._tokenizer.decoder

    @property
    def vocab_size(self):
        return self._tokenizer.get_vocab_size(with_added_tokens=False)

    def __len__(self):
        return self._tokenizer.get_vocab_size(with_added_tokens=True)

    @PreTrainedTokenizer.bos_token.setter
    def bos_token(self, value):
        self._bos_token = value
        self._update_special_tokens()

    @PreTrainedTokenizer.eos_token.setter
    def eos_token(self, value):
        self._eos_token = value
        self._update_special_tokens()

    @PreTrainedTokenizer.unk_token.setter
    def unk_token(self, value):
        self._unk_token = value
        self._update_special_tokens()

    @PreTrainedTokenizer.sep_token.setter
    def sep_token(self, value):
        self._sep_token = value
        self._update_special_tokens()

    @PreTrainedTokenizer.pad_token.setter
    def pad_token(self, value):
        self._pad_token = value
        self._update_special_tokens()

    @PreTrainedTokenizer.cls_token.setter
    def cls_token(self, value):
        self._cls_token = value
        self._update_special_tokens()

    @PreTrainedTokenizer.mask_token.setter
    def mask_token(self, value):
        self._mask_token = value
        self._update_special_tokens()

    @PreTrainedTokenizer.additional_special_tokens.setter
    def additional_special_tokens(self, value):
        self._additional_special_tokens = value
        self._update_special_tokens()

    def _update_special_tokens(self):
        if self._tokenizer is not None:
            self._tokenizer.add_special_tokens(self.all_special_tokens)

    @staticmethod
    def _convert_encoding(encoding, return_tensors=None, return_token_type_ids=True, return_attention_mask=True, return_overflowing_tokens=False, return_special_tokens_mask=False, return_offsets_mapping=False):
        if return_overflowing_tokens and encoding.overflowing is not None:
            encodings = [encoding] + encoding.overflowing
        else:
            encodings = [encoding]
        encoding_dict = defaultdict(list)
        for e in encodings:
            encoding_dict['input_ids'].append(e.ids)
            if return_token_type_ids:
                encoding_dict['token_type_ids'].append(e.type_ids)
            if return_attention_mask:
                encoding_dict['attention_mask'].append(e.attention_mask)
            if return_special_tokens_mask:
                encoding_dict['special_tokens_mask'].append(e.special_tokens_mask)
            if return_offsets_mapping:
                encoding_dict['offset_mapping'].append([e.original_str.offsets(o) for o in e.offsets])
        if return_tensors == 'tf' and is_tf_available():
            encoding_dict['input_ids'] = tf.constant(encoding_dict['input_ids'])
            if 'token_type_ids' in encoding_dict:
                encoding_dict['token_type_ids'] = tf.constant(encoding_dict['token_type_ids'])
            if 'attention_mask' in encoding_dict:
                encoding_dict['attention_mask'] = tf.constant(encoding_dict['attention_mask'])
        elif return_tensors == 'pt' and is_torch_available():
            encoding_dict['input_ids'] = torch.tensor(encoding_dict['input_ids'])
            if 'token_type_ids' in encoding_dict:
                encoding_dict['token_type_ids'] = torch.tensor(encoding_dict['token_type_ids'])
            if 'attention_mask' in encoding_dict:
                encoding_dict['attention_mask'] = torch.tensor(encoding_dict['attention_mask'])
        elif return_tensors is not None:
            logger.warning('Unable to convert output to tensors format {}, PyTorch or TensorFlow is not available.'.format(return_tensors))
        return encoding_dict

    def _convert_token_to_id_with_added_voc(self, token):
        id = self._tokenizer.token_to_id(token)
        if id is None:
            return self.unk_token_id
        return id

    def _convert_id_to_token(self, index):
        return self._tokenizer.id_to_token(int(index))

    def convert_tokens_to_string(self, tokens):
        return self._tokenizer.decode(tokens)

    def add_tokens(self, new_tokens):
        if isinstance(new_tokens, str):
            new_tokens = [new_tokens]
        return self._tokenizer.add_tokens(new_tokens)

    def add_special_tokens(self, special_tokens_dict):
        added = super().add_special_tokens(special_tokens_dict)
        self._update_special_tokens()
        return added

    def build_inputs_with_special_tokens(self, token_ids_0, token_ids_1=None):
        if token_ids_1 is None:
            return token_ids_0
        else:
            return token_ids_0 + token_ids_1

    def num_added_tokens(self, pair=False):
        return self.tokenizer.num_special_tokens_to_add(pair)

    def tokenize(self, text, **kwargs):
        return self.tokenizer.encode(text).tokens

    def batch_encode_plus(self, batch_text_or_text_pairs=None, add_special_tokens=True, max_length=None, stride=0, truncation_strategy='longest_first', pad_to_max_length=False, return_tensors=None, return_token_type_ids=True, return_attention_mask=True, return_overflowing_tokens=False, return_special_tokens_mask=False, return_offsets_mapping=False, **kwargs):
        pad_to_max_length = pad_to_max_length or return_tensors is not None
        if pad_to_max_length and self.pad_token_id is None:
            raise ValueError('Unable to set proper padding strategy as the tokenizer does have padding token')
        with truncate_and_pad(tokenizer=self._tokenizer, max_length=max_length, stride=stride, strategy=truncation_strategy, pad_to_max_length=pad_to_max_length, padding_side=self.padding_side, pad_token_id=self.pad_token_id, pad_token_type_id=self.pad_token_type_id, pad_token=self._pad_token):
            if not isinstance(batch_text_or_text_pairs, list):
                raise TypeError('batch_text_or_text_pairs has to be a list (got {})'.format(type(batch_text_or_text_pairs)))
            if len(batch_text_or_text_pairs) == 1:
                if isinstance(batch_text_or_text_pairs[0], (tuple, list)):
                    tokens = self._tokenizer.encode(*batch_text_or_text_pairs[0])
                else:
                    tokens = self._tokenizer.encode(batch_text_or_text_pairs[0])
                tokens = [tokens]
            else:
                tokens = self._tokenizer.encode_batch(batch_text_or_text_pairs)
        tokens = [self._convert_encoding(encoding=encoding, return_tensors=return_tensors, return_token_type_ids=return_token_type_ids, return_attention_mask=return_attention_mask, return_overflowing_tokens=return_overflowing_tokens, return_special_tokens_mask=return_special_tokens_mask, return_offsets_mapping=return_offsets_mapping) for encoding in tokens]
        sanitized = {}
        for key in tokens[0].keys():
            stack = [e for item in tokens for e in item[key]]
            if return_tensors == 'tf':
                stack = tf.stack(stack, axis=0)
            elif return_tensors == 'pt':
                stack = torch.stack(stack, dim=0)
            elif not return_tensors and len(stack) == 1:
                stack = stack[0]
            sanitized[key] = stack
        if return_overflowing_tokens:
            overflow_to_sample_mapping = [i if len(item['input_ids']) == 1 else [i] * len(item['input_ids']) for i, item in enumerate(tokens)]
            sanitized['overflow_to_sample_mapping'] = overflow_to_sample_mapping
        return sanitized

    def encode_plus(self, text, text_pair=None, add_special_tokens=False, max_length=None, pad_to_max_length=False, stride=0, truncation_strategy='longest_first', return_tensors=None, return_token_type_ids=True, return_attention_mask=True, return_overflowing_tokens=False, return_special_tokens_mask=False, return_offsets_mapping=False, **kwargs):
        batched_input = [(text, text_pair)] if text_pair else [text]
        batched_output = self.batch_encode_plus(batched_input, add_special_tokens=add_special_tokens, max_length=max_length, stride=stride, truncation_strategy=truncation_strategy, return_tensors=return_tensors, return_token_type_ids=return_token_type_ids, return_attention_mask=return_attention_mask, return_overflowing_tokens=return_overflowing_tokens, return_special_tokens_mask=return_special_tokens_mask, return_offsets_mapping=return_offsets_mapping, pad_to_max_length=pad_to_max_length, **kwargs)
        if not return_tensors:
            return {key: value[0] if isinstance(value[0], list) else value for key, value in batched_output.items()}
        else:
            return batched_output

    def decode(self, token_ids, skip_special_tokens=False, clean_up_tokenization_spaces=True):
        text = self.tokenizer.decode(token_ids, skip_special_tokens)
        if clean_up_tokenization_spaces:
            clean_text = self.clean_up_tokenization(text)
            return clean_text
        else:
            return text

    def save_vocabulary(self, save_directory):
        if os.path.isdir(save_directory):
            folder, file = (save_directory, self.vocab_files_names['vocab_file'])
        else:
            folder, file = os.path.split(os.path.abspath(save_directory))
        return tuple(self._tokenizer.save(folder, file))
