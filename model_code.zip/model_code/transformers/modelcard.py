import copy
import json
import logging
import os
from .configuration_auto import ALL_PRETRAINED_CONFIG_ARCHIVE_MAP
from .file_utils import CONFIG_NAME, MODEL_CARD_NAME, TF2_WEIGHTS_NAME, WEIGHTS_NAME, cached_path, hf_bucket_url, is_remote_url
logger = logging.getLogger(__name__)

class ModelCard(object):

    def __init__(self, **kwargs):
        self.model_details = kwargs.pop('model_details', {})
        self.intended_use = kwargs.pop('intended_use', {})
        self.factors = kwargs.pop('factors', {})
        self.metrics = kwargs.pop('metrics', {})
        self.evaluation_data = kwargs.pop('evaluation_data', {})
        self.training_data = kwargs.pop('training_data', {})
        self.quantitative_analyses = kwargs.pop('quantitative_analyses', {})
        self.ethical_considerations = kwargs.pop('ethical_considerations', {})
        self.caveats_and_recommendations = kwargs.pop('caveats_and_recommendations', {})
        for key, value in kwargs.items():
            try:
                setattr(self, key, value)
            except AttributeError as err:
                logger.error("Can't set {} with value {} for {}".format(key, value, self))
                raise err

    def save_pretrained(self, save_directory_or_file):
        if os.path.isdir(save_directory_or_file):
            output_model_card_file = os.path.join(save_directory_or_file, MODEL_CARD_NAME)
        else:
            output_model_card_file = save_directory_or_file
        self.to_json_file(output_model_card_file)
        logger.info('Model card saved in {}'.format(output_model_card_file))

    @classmethod
    def from_pretrained(cls, pretrained_model_name_or_path, **kwargs):
        cache_dir = kwargs.pop('cache_dir', None)
        proxies = kwargs.pop('proxies', None)
        find_from_standard_name = kwargs.pop('find_from_standard_name', True)
        return_unused_kwargs = kwargs.pop('return_unused_kwargs', False)
        if pretrained_model_name_or_path in ALL_PRETRAINED_CONFIG_ARCHIVE_MAP:
            model_card_file = ALL_PRETRAINED_CONFIG_ARCHIVE_MAP[pretrained_model_name_or_path]
        elif os.path.isdir(pretrained_model_name_or_path):
            model_card_file = os.path.join(pretrained_model_name_or_path, MODEL_CARD_NAME)
        elif os.path.isfile(pretrained_model_name_or_path) or is_remote_url(pretrained_model_name_or_path):
            model_card_file = pretrained_model_name_or_path
        else:
            model_card_file = hf_bucket_url(pretrained_model_name_or_path, postfix=MODEL_CARD_NAME)
        if find_from_standard_name or pretrained_model_name_or_path in ALL_PRETRAINED_CONFIG_ARCHIVE_MAP:
            model_card_file = model_card_file.replace(CONFIG_NAME, MODEL_CARD_NAME)
            model_card_file = model_card_file.replace(WEIGHTS_NAME, MODEL_CARD_NAME)
            model_card_file = model_card_file.replace(TF2_WEIGHTS_NAME, MODEL_CARD_NAME)
        try:
            resolved_model_card_file = cached_path(model_card_file, cache_dir=cache_dir, force_download=True, proxies=proxies, resume_download=False)
            if resolved_model_card_file is None:
                raise EnvironmentError
            if resolved_model_card_file == model_card_file:
                logger.info('loading model card file {}'.format(model_card_file))
            else:
                logger.info('loading model card file {} from cache at {}'.format(model_card_file, resolved_model_card_file))
            modelcard = cls.from_json_file(resolved_model_card_file)
        except EnvironmentError:
            if pretrained_model_name_or_path in ALL_PRETRAINED_CONFIG_ARCHIVE_MAP:
                logger.warning("Couldn't reach server at '{}' to download model card file.".format(model_card_file))
            else:
                logger.warning("Model name '{}' was not found in model name list ({}). We assumed '{}' was a path or url to a model card file named {} or a directory containing such a file but couldn't find any such file at this path or url.".format(pretrained_model_name_or_path, ', '.join(ALL_PRETRAINED_CONFIG_ARCHIVE_MAP.keys()), model_card_file, MODEL_CARD_NAME))
            logger.warning('Creating an empty model card.')
            modelcard = cls()
        except json.JSONDecodeError:
            logger.warning("Couldn't reach server at '{}' to download model card file or model card file is not a valid JSON file. Please check network or file content here: {}.".format(model_card_file, resolved_model_card_file))
            logger.warning('Creating an empty model card.')
            modelcard = cls()
        to_remove = []
        for key, value in kwargs.items():
            if hasattr(modelcard, key):
                setattr(modelcard, key, value)
                to_remove.append(key)
        for key in to_remove:
            kwargs.pop(key, None)
        logger.info('Model card: %s', str(modelcard))
        if return_unused_kwargs:
            return (modelcard, kwargs)
        else:
            return modelcard

    @classmethod
    def from_dict(cls, json_object):
        return cls(**json_object)

    @classmethod
    def from_json_file(cls, json_file):
        with open(json_file, 'r', encoding='utf-8') as reader:
            text = reader.read()
        dict_obj = json.loads(text)
        return cls(**dict_obj)

    def __eq__(self, other):
        return self.__dict__ == other.__dict__

    def __repr__(self):
        return str(self.to_json_string())

    def to_dict(self):
        output = copy.deepcopy(self.__dict__)
        return output

    def to_json_string(self):
        return json.dumps(self.to_dict(), indent=2, sort_keys=True) + '\n'

    def to_json_file(self, json_file_path):
        with open(json_file_path, 'w', encoding='utf-8') as writer:
            writer.write(self.to_json_string())
