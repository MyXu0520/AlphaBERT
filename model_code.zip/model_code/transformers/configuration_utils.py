import copy
import json
import logging
import os
from typing import Dict, Optional, Tuple
from .file_utils import CONFIG_NAME, cached_path, hf_bucket_url, is_remote_url
logger = logging.getLogger(__name__)

class PretrainedConfig(object):
    pretrained_config_archive_map = {}
    model_type = ''

    def __init__(self, **kwargs):
        self.output_attentions = kwargs.pop('output_attentions', False)
        self.output_hidden_states = kwargs.pop('output_hidden_states', False)
        self.output_past = kwargs.pop('output_past', True)
        self.torchscript = kwargs.pop('torchscript', False)
        self.use_bfloat16 = kwargs.pop('use_bfloat16', False)
        self.pruned_heads = kwargs.pop('pruned_heads', {})
        self.is_decoder = kwargs.pop('is_decoder', False)
        self.max_length = kwargs.pop('max_length', 20)
        self.do_sample = kwargs.pop('do_sample', False)
        self.num_beams = kwargs.pop('num_beams', 1)
        self.temperature = kwargs.pop('temperature', 1.0)
        self.top_k = kwargs.pop('top_k', 50)
        self.top_p = kwargs.pop('top_p', 1.0)
        self.repetition_penalty = kwargs.pop('repetition_penalty', 1.0)
        self.bos_token_id = kwargs.pop('bos_token_id', 0)
        self.pad_token_id = kwargs.pop('pad_token_id', 0)
        self.eos_token_ids = kwargs.pop('eos_token_ids', 0)
        self.length_penalty = kwargs.pop('length_penalty', 1.0)
        self.num_return_sequences = kwargs.pop('num_return_sequences', 1)
        self.architectures = kwargs.pop('architectures', None)
        self.finetuning_task = kwargs.pop('finetuning_task', None)
        self.num_labels = kwargs.pop('num_labels', 2)
        self.id2label = kwargs.pop('id2label', {i: 'LABEL_{}'.format(i) for i in range(self.num_labels)})
        self.id2label = dict(((int(key), value) for key, value in self.id2label.items()))
        self.label2id = kwargs.pop('label2id', dict(zip(self.id2label.values(), self.id2label.keys())))
        self.label2id = dict(((key, int(value)) for key, value in self.label2id.items()))
        for key, value in kwargs.items():
            try:
                setattr(self, key, value)
            except AttributeError as err:
                logger.error("Can't set {} with value {} for {}".format(key, value, self))
                raise err

    def save_pretrained(self, save_directory):
        assert os.path.isdir(save_directory), 'Saving path should be a directory where the model and configuration can be saved'
        output_config_file = os.path.join(save_directory, CONFIG_NAME)
        self.to_json_file(output_config_file)
        logger.info('Configuration saved in {}'.format(output_config_file))

    @classmethod
    def from_pretrained(cls, pretrained_model_name_or_path, **kwargs) -> 'PretrainedConfig':
        config_dict, kwargs = cls.get_config_dict(pretrained_model_name_or_path, **kwargs)
        return cls.from_dict(config_dict, **kwargs)

    @classmethod
    def get_config_dict(cls, pretrained_model_name_or_path: str, pretrained_config_archive_map: Optional[Dict]=None, **kwargs) -> Tuple[Dict, Dict]:
        cache_dir = kwargs.pop('cache_dir', None)
        force_download = kwargs.pop('force_download', False)
        resume_download = kwargs.pop('resume_download', False)
        proxies = kwargs.pop('proxies', None)
        if pretrained_config_archive_map is None:
            pretrained_config_archive_map = cls.pretrained_config_archive_map
        if pretrained_model_name_or_path in pretrained_config_archive_map:
            config_file = pretrained_config_archive_map[pretrained_model_name_or_path]
        elif os.path.isdir(pretrained_model_name_or_path):
            config_file = os.path.join(pretrained_model_name_or_path, CONFIG_NAME)
        elif os.path.isfile(pretrained_model_name_or_path) or is_remote_url(pretrained_model_name_or_path):
            config_file = pretrained_model_name_or_path
        else:
            config_file = hf_bucket_url(pretrained_model_name_or_path, postfix=CONFIG_NAME)
        try:
            resolved_config_file = cached_path(config_file, cache_dir=cache_dir, force_download=force_download, proxies=proxies, resume_download=resume_download)
            if resolved_config_file is None:
                raise EnvironmentError
            config_dict = cls._dict_from_json_file(resolved_config_file)
        except EnvironmentError:
            if pretrained_model_name_or_path in pretrained_config_archive_map:
                msg = "Couldn't reach server at '{}' to download pretrained model configuration file.".format(config_file)
            else:
                msg = "Model name '{}' was not found in model name list. We assumed '{}' was a path, a model identifier, or url to a configuration file named {} or a directory containing such a file but couldn't find any such file at this path or url.".format(pretrained_model_name_or_path, config_file, CONFIG_NAME)
            raise EnvironmentError(msg)
        except json.JSONDecodeError:
            msg = "Couldn't reach server at '{}' to download configuration file or configuration file is not a valid JSON file. Please check network or file content here: {}.".format(config_file, resolved_config_file)
            raise EnvironmentError(msg)
        if resolved_config_file == config_file:
            logger.info('loading configuration file {}'.format(config_file))
        else:
            logger.info('loading configuration file {} from cache at {}'.format(config_file, resolved_config_file))
        return (config_dict, kwargs)

    @classmethod
    def from_dict(cls, config_dict: Dict, **kwargs) -> 'PretrainedConfig':
        return_unused_kwargs = kwargs.pop('return_unused_kwargs', False)
        config = cls(**config_dict)
        if hasattr(config, 'pruned_heads'):
            config.pruned_heads = dict(((int(key), value) for key, value in config.pruned_heads.items()))
        to_remove = []
        for key, value in kwargs.items():
            if hasattr(config, key):
                setattr(config, key, value)
                to_remove.append(key)
        for key in to_remove:
            kwargs.pop(key, None)
        logger.info('Model config %s', str(config))
        if return_unused_kwargs:
            return (config, kwargs)
        else:
            return config

    @classmethod
    def from_json_file(cls, json_file: str) -> 'PretrainedConfig':
        config_dict = cls._dict_from_json_file(json_file)
        return cls(**config_dict)

    @classmethod
    def _dict_from_json_file(cls, json_file: str):
        with open(json_file, 'r', encoding='utf-8') as reader:
            text = reader.read()
        return json.loads(text)

    def __eq__(self, other):
        return self.__dict__ == other.__dict__

    def __repr__(self):
        return '{} {}'.format(self.__class__.__name__, self.to_json_string())

    def to_dict(self):
        output = copy.deepcopy(self.__dict__)
        if hasattr(self.__class__, 'model_type'):
            output['model_type'] = self.__class__.model_type
        return output

    def to_json_string(self):
        return json.dumps(self.to_dict(), indent=2, sort_keys=True) + '\n'

    def to_json_file(self, json_file_path):
        with open(json_file_path, 'w', encoding='utf-8') as writer:
            writer.write(self.to_json_string())
