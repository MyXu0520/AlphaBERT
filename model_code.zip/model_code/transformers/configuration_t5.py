import logging
from .configuration_utils import PretrainedConfig
logger = logging.getLogger(__name__)
T5_PRETRAINED_CONFIG_ARCHIVE_MAP = {'t5-small': 'https://s3.amazonaws.com/models.huggingface.co/bert/t5-small-config.json', 't5-base': 'https://s3.amazonaws.com/models.huggingface.co/bert/t5-base-config.json', 't5-large': 'https://s3.amazonaws.com/models.huggingface.co/bert/t5-large-config.json', 't5-3b': 'https://s3.amazonaws.com/models.huggingface.co/bert/t5-3b-config.json', 't5-11b': 'https://s3.amazonaws.com/models.huggingface.co/bert/t5-11b-config.json'}

class T5Config(PretrainedConfig):
    pretrained_config_archive_map = T5_PRETRAINED_CONFIG_ARCHIVE_MAP
    model_type = 't5'

    def __init__(self, vocab_size=32128, n_positions=512, d_model=512, d_kv=64, d_ff=2048, num_layers=6, num_heads=8, relative_attention_num_buckets=32, dropout_rate=0.1, layer_norm_epsilon=1e-06, initializer_factor=1.0, **kwargs):
        super().__init__(**kwargs)
        self.vocab_size = vocab_size
        self.n_positions = n_positions
        self.d_model = d_model
        self.d_kv = d_kv
        self.d_ff = d_ff
        self.num_layers = num_layers
        self.num_heads = num_heads
        self.relative_attention_num_buckets = relative_attention_num_buckets
        self.dropout_rate = dropout_rate
        self.layer_norm_epsilon = layer_norm_epsilon
        self.initializer_factor = initializer_factor

    @property
    def max_position_embeddings(self):
        return self.n_positions

    @property
    def hidden_size(self):
        return self.d_model

    @property
    def num_attention_heads(self):
        return self.num_heads

    @property
    def num_hidden_layers(self):
        return self.num_layers
