import copy
import itertools
import logging
import math
import tensorflow as tf
from .configuration_t5 import T5Config
from .file_utils import DUMMY_INPUTS, DUMMY_MASK, add_start_docstrings
from .modeling_tf_utils import TFPreTrainedModel, TFSharedEmbeddings, shape_list
logger = logging.getLogger(__name__)
TF_T5_PRETRAINED_MODEL_ARCHIVE_MAP = {'t5-small': 'https://s3.amazonaws.com/models.huggingface.co/bert/t5-small-tf_model.h5', 't5-base': 'https://s3.amazonaws.com/models.huggingface.co/bert/t5-base-tf_model.h5', 't5-large': 'https://s3.amazonaws.com/models.huggingface.co/bert/t5-large-tf_model.h5', 't5-3b': 'https://s3.amazonaws.com/models.huggingface.co/bert/t5-3b-tf_model.h5', 't5-11b': 'https://s3.amazonaws.com/models.huggingface.co/bert/t5-11b-tf_model.h5'}

class TFT5LayerNorm(tf.keras.layers.Layer):

    def __init__(self, epsilon=1e-06, **kwargs):
        super().__init__(**kwargs)
        self.variance_epsilon = epsilon

    def build(self, input_shape):
        self.weight = self.add_weight('weight', shape=(input_shape[-1],), initializer='ones')
        super().build(input_shape)

    def call(self, x):
        variance = tf.math.reduce_mean(tf.math.square(x), axis=-1, keepdims=True)
        x = x * tf.math.rsqrt(variance + self.variance_epsilon)
        return self.weight * x

class TFT5DenseReluDense(tf.keras.layers.Layer):

    def __init__(self, config, **kwargs):
        super().__init__(**kwargs)
        self.wi = tf.keras.layers.Dense(config.d_ff, use_bias=False, name='wi')
        self.wo = tf.keras.layers.Dense(config.d_model, use_bias=False, name='wo')
        self.dropout = tf.keras.layers.Dropout(config.dropout_rate)
        self.act = tf.keras.activations.relu

    def call(self, hidden_states, training=False):
        h = self.wi(hidden_states)
        h = self.act(h)
        h = self.dropout(h, training=training)
        h = self.wo(h)
        return h

class TFT5LayerFF(tf.keras.layers.Layer):

    def __init__(self, config, **kwargs):
        super().__init__(**kwargs)
        self.DenseReluDense = TFT5DenseReluDense(config, name='DenseReluDense')
        self.layer_norm = TFT5LayerNorm(epsilon=config.layer_norm_epsilon, name='layer_norm')
        self.dropout = tf.keras.layers.Dropout(config.dropout_rate)

    def call(self, hidden_states, training=False):
        norm_x = self.layer_norm(hidden_states)
        y = self.DenseReluDense(norm_x, training=training)
        layer_output = hidden_states + self.dropout(y, training=training)
        return layer_output

class TFT5Attention(tf.keras.layers.Layer):
    NEW_ID = itertools.count()

    def __init__(self, config, has_relative_attention_bias=False, **kwargs):
        super().__init__(**kwargs)
        self.layer_id = next(TFT5Attention.NEW_ID)
        self.is_decoder = config.is_decoder
        self.has_relative_attention_bias = has_relative_attention_bias
        self.output_attentions = config.output_attentions
        self.relative_attention_num_buckets = config.relative_attention_num_buckets
        self.d_model = config.d_model
        self.d_kv = config.d_kv
        self.n_heads = config.num_heads
        self.inner_dim = self.n_heads * self.d_kv
        self.q = tf.keras.layers.Dense(self.inner_dim, use_bias=False, name='q')
        self.k = tf.keras.layers.Dense(self.inner_dim, use_bias=False, name='k')
        self.v = tf.keras.layers.Dense(self.inner_dim, use_bias=False, name='v')
        self.o = tf.keras.layers.Dense(self.d_model, use_bias=False, name='o')
        self.dropout = tf.keras.layers.Dropout(config.dropout_rate)
        if self.has_relative_attention_bias:
            self.relative_attention_bias = tf.keras.layers.Embedding(self.relative_attention_num_buckets, self.n_heads, name='relative_attention_bias')
        self.pruned_heads = set()

    def prune_heads(self, heads):
        raise NotImplementedError

    @staticmethod
    def _relative_position_bucket(relative_position, bidirectional=True, num_buckets=32, max_distance=128):
        ret = 0
        n = -relative_position
        if bidirectional:
            num_buckets //= 2
            ret += tf.dtypes.cast(tf.math.less(n, 0), tf.int32) * num_buckets
            n = tf.math.abs(n)
        else:
            n = tf.math.maximum(n, 0)
        max_exact = num_buckets // 2
        is_small = tf.math.less(n, max_exact)
        val_if_large = max_exact + tf.dtypes.cast(tf.math.log(tf.dtypes.cast(n, tf.float32) / max_exact) / math.log(max_distance / max_exact) * (num_buckets - max_exact), tf.int32)
        val_if_large = tf.math.minimum(val_if_large, num_buckets - 1)
        ret += tf.where(is_small, n, val_if_large)
        return ret

    def compute_bias(self, qlen, klen):
        context_position = tf.range(qlen)[:, None]
        memory_position = tf.range(klen)[None, :]
        relative_position = memory_position - context_position
        rp_bucket = self._relative_position_bucket(relative_position, bidirectional=not self.is_decoder, num_buckets=self.relative_attention_num_buckets)
        values = self.relative_attention_bias(rp_bucket)
        values = tf.expand_dims(tf.transpose(values, [2, 0, 1]), axis=0)
        return values

    def call(self, input, mask=None, kv=None, position_bias=None, cache=None, head_mask=None, training=False):
        bs, qlen, dim = shape_list(input)
        if kv is None:
            klen = qlen if cache is None else cache['slen'] + qlen
        else:
            klen = shape_list(kv)[1]

        def shape(x):
            return tf.transpose(tf.reshape(x, (bs, -1, self.n_heads, self.d_kv)), perm=(0, 2, 1, 3))

        def unshape(x):
            return tf.reshape(tf.transpose(x, perm=(0, 2, 1, 3)), (bs, -1, self.inner_dim))
        q = shape(self.q(input))
        if kv is None:
            k = shape(self.k(input))
            v = shape(self.v(input))
        elif cache is None or self.layer_id not in cache:
            k = v = kv
            k = shape(self.k(k))
            v = shape(self.v(v))
        if cache is not None:
            if self.layer_id in cache:
                if kv is None:
                    k_, v_ = cache[self.layer_id]
                    k = tf.concat([k_, k], axis=2)
                    v = tf.concat([v_, v], axis=2)
                else:
                    k, v = cache[self.layer_id]
            cache[self.layer_id] = (k, v)
        scores = tf.einsum('bnqd,bnkd->bnqk', q, k)
        if position_bias is None:
            if not self.has_relative_attention_bias:
                raise ValueError('No position_bias provided and no weights to compute position_bias')
            position_bias = self.compute_bias(qlen, klen)
            if mask is not None:
                position_bias = position_bias + mask
        scores += position_bias
        weights = tf.nn.softmax(scores, axis=-1)
        weights = self.dropout(weights, training=training)
        if head_mask is not None:
            weights = weights * head_mask
        context = tf.matmul(weights, v)
        context = unshape(context)
        context = self.o(context)
        outputs = (context,)
        if self.output_attentions:
            outputs = outputs + (weights,)
        if self.has_relative_attention_bias:
            outputs = outputs + (position_bias,)
        return outputs

class TFT5LayerSelfAttention(tf.keras.layers.Layer):

    def __init__(self, config, has_relative_attention_bias=False, **kwargs):
        super().__init__(**kwargs)
        self.SelfAttention = TFT5Attention(config, has_relative_attention_bias=has_relative_attention_bias, name='SelfAttention')
        self.layer_norm = TFT5LayerNorm(epsilon=config.layer_norm_epsilon, name='layer_norm')
        self.dropout = tf.keras.layers.Dropout(config.dropout_rate)

    def call(self, hidden_states, attention_mask=None, position_bias=None, head_mask=None, training=False):
        norm_x = self.layer_norm(hidden_states)
        attention_output = self.SelfAttention(norm_x, mask=attention_mask, position_bias=position_bias, head_mask=head_mask, training=training)
        y = attention_output[0]
        layer_output = hidden_states + self.dropout(y, training=training)
        outputs = (layer_output,) + attention_output[1:]
        return outputs

class TFT5LayerCrossAttention(tf.keras.layers.Layer):

    def __init__(self, config, has_relative_attention_bias=False, **kwargs):
        super().__init__(**kwargs)
        self.EncDecAttention = TFT5Attention(config, has_relative_attention_bias=has_relative_attention_bias, name='EncDecAttention')
        self.layer_norm = TFT5LayerNorm(epsilon=config.layer_norm_epsilon, name='layer_norm')
        self.dropout = tf.keras.layers.Dropout(config.dropout_rate)

    def call(self, hidden_states, kv, attention_mask=None, position_bias=None, head_mask=None, training=False):
        norm_x = self.layer_norm(hidden_states)
        attention_output = self.EncDecAttention(norm_x, mask=attention_mask, kv=kv, position_bias=position_bias, head_mask=head_mask, training=training)
        y = attention_output[0]
        layer_output = hidden_states + self.dropout(y, training=training)
        outputs = (layer_output,) + attention_output[1:]
        return outputs

class TFT5Block(tf.keras.layers.Layer):

    def __init__(self, config, has_relative_attention_bias=False, **kwargs):
        super().__init__(**kwargs)
        self.is_decoder = config.is_decoder
        self.layer = []
        self.layer.append(TFT5LayerSelfAttention(config, has_relative_attention_bias=has_relative_attention_bias, name='layer_._0'))
        if self.is_decoder:
            self.layer.append(TFT5LayerCrossAttention(config, has_relative_attention_bias=has_relative_attention_bias, name='layer_._1'))
            self.layer.append(TFT5LayerFF(config, name='layer_._2'))
        else:
            self.layer.append(TFT5LayerFF(config, name='layer_._1'))

    def call(self, hidden_states, attention_mask=None, position_bias=None, encoder_hidden_states=None, encoder_attention_mask=None, encoder_decoder_position_bias=None, head_mask=None, training=False):
        self_attention_outputs = self.layer[0](hidden_states, attention_mask=attention_mask, position_bias=position_bias, head_mask=head_mask, training=training)
        hidden_states = self_attention_outputs[0]
        outputs = self_attention_outputs[1:]
        if not self.is_decoder:
            hidden_states = self.layer[1](hidden_states, training=training)
        else:
            cross_attention_outputs = self.layer[1](hidden_states, kv=encoder_hidden_states, attention_mask=encoder_attention_mask, position_bias=encoder_decoder_position_bias, head_mask=head_mask, training=training)
            hidden_states = cross_attention_outputs[0]
            outputs = outputs + cross_attention_outputs[1:]
            hidden_states = self.layer[2](hidden_states, training=training)
        outputs = (hidden_states,) + outputs
        return outputs

class TFT5MainLayer(tf.keras.layers.Layer):

    def __init__(self, config, **kwargs):
        super().__init__(**kwargs)
        self.output_attentions = config.output_attentions
        self.output_hidden_states = config.output_hidden_states
        self.is_decoder = config.is_decoder
        self.config = config
        self.num_hidden_layers = config.num_layers
        self.block = [TFT5Block(config, has_relative_attention_bias=bool(i == 0), name='block_._{}'.format(i)) for i in range(config.num_layers)]
        self.final_layer_norm = TFT5LayerNorm(epsilon=config.layer_norm_epsilon, name='final_layer_norm')
        self.dropout = tf.keras.layers.Dropout(config.dropout_rate)

    def _resize_token_embeddings(self, new_num_tokens):
        raise NotImplementedError

    def _prune_heads(self, heads_to_prune):
        raise NotImplementedError

    def call(self, hidden_states, attention_mask=None, encoder_hidden_states=None, encoder_attention_mask=None, head_mask=None, training=False):
        batch_size, seq_length = shape_list(hidden_states)[:2]
        if attention_mask is None:
            attention_mask = tf.fill((batch_size, seq_length), 1)
        if self.is_decoder and encoder_attention_mask is None:
            encoder_seq_length = encoder_hidden_states.shape[1]
            encoder_attention_mask = tf.fill((batch_size, encoder_seq_length), 1)
        attention_mask = tf.cast(attention_mask, dtype=tf.float32)
        num_dims_attention_mask = len(shape_list(attention_mask))
        if num_dims_attention_mask == 3:
            extended_attention_mask = attention_mask[:, None, :, :]
        elif num_dims_attention_mask == 2:
            if self.config.is_decoder:
                seq_ids = tf.range(seq_length)
                causal_mask = tf.less_equal(tf.tile(seq_ids[None, None, :], (batch_size, seq_length, 1)), seq_ids[None, :, None])
                causal_mask = tf.cast(causal_mask, dtype=tf.float32)
                extended_attention_mask = causal_mask[:, None, :, :] * attention_mask[:, None, None, :]
            else:
                extended_attention_mask = attention_mask[:, None, None, :]
        extended_attention_mask = (1.0 - extended_attention_mask) * -1000000000.0
        if self.is_decoder:
            encoder_attention_mask = tf.cast(encoder_attention_mask, dtype=tf.float32)
            num_dims_encoder_attention_mask = len(shape_list(encoder_attention_mask))
            if num_dims_encoder_attention_mask == 3:
                encoder_extended_attention_mask = encoder_attention_mask[:, None, :, :]
            if num_dims_encoder_attention_mask == 2:
                encoder_extended_attention_mask = encoder_attention_mask[:, None, None, :]
            encoder_extended_attention_mask = (1.0 - encoder_extended_attention_mask) * -1000000000.0
        else:
            encoder_extended_attention_mask = None
        if head_mask is not None:
            raise NotImplementedError
        else:
            head_mask = [None] * self.num_hidden_layers
        all_hidden_states = ()
        all_attentions = ()
        position_bias = None
        encoder_decoder_position_bias = None
        for i, layer_module in enumerate(self.block):
            if self.output_hidden_states:
                all_hidden_states = all_hidden_states + (hidden_states,)
            layer_outputs = layer_module(hidden_states, attention_mask=extended_attention_mask, position_bias=position_bias, encoder_hidden_states=encoder_hidden_states, encoder_attention_mask=encoder_extended_attention_mask, encoder_decoder_position_bias=encoder_decoder_position_bias, head_mask=head_mask[i], training=training)
            hidden_states = layer_outputs[0]
            if i == 0:
                position_bias = layer_outputs[2 if self.output_attentions else 1]
                if self.is_decoder:
                    encoder_decoder_position_bias = layer_outputs[4 if self.output_attentions else 2]
            if self.output_attentions:
                all_attentions = all_attentions + (layer_outputs[1],)
        hidden_states = self.final_layer_norm(hidden_states)
        hidden_states = self.dropout(hidden_states, training=training)
        if self.output_hidden_states:
            all_hidden_states = all_hidden_states + (hidden_states,)
        outputs = (hidden_states,)
        if self.output_hidden_states:
            outputs = outputs + (all_hidden_states,)
        if self.output_attentions:
            outputs = outputs + (all_attentions,)
        return outputs

class TFT5PreTrainedModel(TFPreTrainedModel):
    config_class = T5Config
    pretrained_model_archive_map = TF_T5_PRETRAINED_MODEL_ARCHIVE_MAP
    base_model_prefix = 'transformer'

    @property
    def dummy_inputs(self):
        input_ids = tf.constant(DUMMY_INPUTS)
        input_mask = tf.constant(DUMMY_MASK)
        dummy_inputs = {'decoder_input_ids': input_ids, 'encoder_input_ids': input_ids, 'decoder_attention_mask': input_mask}
        return dummy_inputs
T5_START_DOCSTRING = "    The T5 model was proposed in\n    `Exploring the Limits of Transfer Learning with a Unified Text-to-Text Transformer`_\n    by Colin Raffel, Noam Shazeer, Adam Roberts, Katherine Lee, Sharan Narang, Michael Matena, Yanqi Zhou, Wei Li, Peter J. Liu.\n    It's an encoder decoder transformer pre-trained in a text-to-text denoising generative setting.\n\n    This model is a tf.keras.Model `tf.keras.Model`_ sub-class. Use it as a regular TF 2.0 Keras Model and\n    refer to the TF 2.0 documentation for all matter related to general usage and behavior.\n\n    .. _`Exploring the Limits of Transfer Learning with a Unified Text-to-Text Transformer`:\n        https://arxiv.org/abs/1910.10683\n\n    .. _`tf.keras.Model`:\n        https://www.tensorflow.org/versions/r2.0/api_docs/python/tf/keras/Model\n\n    Note on the model inputs:\n        TF 2.0 models accepts two formats as inputs:\n\n            - having all inputs as keyword arguments (like PyTorch models), or\n            - having all inputs as a list, tuple or dict in the first positional arguments.\n\n        This second option is usefull when using `tf.keras.Model.fit()` method which currently requires having all the tensors in the first argument of the model call function: `model(inputs)`.\n\n        If you choose this second option, there are three possibilities you can use to gather all the input Tensors in the first positional argument :\n\n        - a single Tensor with input_ids only and nothing else: `model(inputs_ids)\n        - a list of varying length with one or several input Tensors IN THE ORDER given in the docstring:\n            `model([input_ids, attention_mask])` or `model([input_ids, attention_mask, token_type_ids])`\n        - a dictionary with one or several input Tensors associaed to the input names given in the docstring:\n            `model({'input_ids': input_ids, 'token_type_ids': token_type_ids})`\n\n    Parameters:\n        config (:class:`~transformers.T5Config`): Model configuration class with all the parameters of the model.\n            Initializing with a config file does not load the weights associated with the model, only the configuration.\n            Check out the :meth:`~transformers.PreTrainedModel.from_pretrained` method to load the model weights.\n"
T5_INPUTS_DOCSTRING = '\n    Inputs:\n        **input_ids**: ``Numpy array`` or ``tf.Tensor`` of shape ``(batch_size, sequence_length)``:\n            Indices of input sequence tokens in the vocabulary.\n            To match pre-training, T5 input sequence should be formatted with [CLS] and [SEP] tokens as follows:\n\n            (a) For sequence pairs:\n\n                ``tokens:         [CLS] is this jack ##son ##ville ? [SEP] no it is not . [SEP]``\n\n            (b) For single sequences:\n\n                ``tokens:         [CLS] the dog is hairy . [SEP]``\n\n\n            T5 is a model with relative position embeddings so you should be able to pad the inputs on\n            the right or the left.\n\n            Indices can be obtained using :class:`transformers.T5Tokenizer`.\n            See :func:`transformers.PreTrainedTokenizer.encode` and\n            :func:`transformers.PreTrainedTokenizer.convert_tokens_to_ids` for details.\n        **attention_mask**: (`optional`) ``Numpy array`` or ``tf.Tensor`` of shape ``(batch_size, sequence_length)``:\n            Mask to avoid performing attention on padding token indices.\n            Mask values selected in ``[0, 1]``:\n            ``1`` for tokens that are NOT MASKED, ``0`` for MASKED tokens.\n        **head_mask**: (`optional`) ``Numpy array`` or ``tf.Tensor`` of shape ``(num_heads,)`` or ``(num_layers, num_heads)``:\n            Mask to nullify selected heads of the self-attention modules.\n            Mask values selected in ``[0, 1]``:\n            ``1`` indicates the head is **not masked**, ``0`` indicates the head is **masked**.\n'

@add_start_docstrings('The bare T5 Model transformer outputting raw hidden-stateswithout any specific head on top.', T5_START_DOCSTRING, T5_INPUTS_DOCSTRING)
class TFT5Model(TFT5PreTrainedModel):

    def __init__(self, config, *inputs, **kwargs):
        super().__init__(config, *inputs, **kwargs)
        self.shared = TFSharedEmbeddings(config.vocab_size, config.d_model, name='shared')
        encoder_config = copy.deepcopy(config)
        self.encoder = TFT5MainLayer(encoder_config, name='encoder')
        decoder_config = copy.deepcopy(config)
        decoder_config.is_decoder = True
        self.decoder = TFT5MainLayer(decoder_config, name='decoder')

    def get_input_embeddings(self):
        return self.shared

    def get_output_embeddings(self):
        return self.shared

    def call(self, decoder_input_ids, **kwargs):
        if isinstance(decoder_input_ids, dict):
            kwargs.update(decoder_input_ids)
        else:
            kwargs['decoder_input_ids'] = decoder_input_ids
        kwargs_common = dict(((k, v) for k, v in kwargs.items() if not k.startswith('encoder_') and (not k.startswith('decoder_'))))
        kwargs_encoder = kwargs_common.copy()
        kwargs_decoder = kwargs_common.copy()
        kwargs_encoder.update(dict(((k[len('encoder_'):], v) for k, v in kwargs.items() if k.startswith('encoder_'))))
        kwargs_decoder.update(dict(((k[len('decoder_'):], v) for k, v in kwargs.items() if k.startswith('decoder_'))))
        encoder_hidden_states = kwargs_encoder.pop('hidden_states', None)
        if encoder_hidden_states is None:
            hidden_states = kwargs_encoder.pop('inputs_embeds', None)
            if hidden_states is None:
                encoder_inputs_ids = kwargs_encoder.pop('input_ids')
                hidden_states = self.shared(encoder_inputs_ids)
            encoder_outputs = self.encoder(hidden_states, **kwargs_encoder)
            encoder_hidden_states = encoder_outputs[0]
        else:
            encoder_outputs = ()
        hidden_states = kwargs_decoder.pop('inputs_embeds', None)
        if hidden_states is None:
            decoder_inputs_ids = kwargs_decoder.pop('input_ids')
            hidden_states = self.shared(decoder_inputs_ids)
        kwargs_decoder['encoder_hidden_states'] = encoder_hidden_states
        kwargs_decoder['encoder_attention_mask'] = kwargs_encoder.get('attention_mask', None)
        decoder_outputs = self.decoder(hidden_states, **kwargs_decoder)
        return decoder_outputs + encoder_outputs

@add_start_docstrings('T5 Model with a `language modeling` head on top. ', T5_START_DOCSTRING, T5_INPUTS_DOCSTRING)
class TFT5WithLMHeadModel(TFT5PreTrainedModel):

    def __init__(self, config, *inputs, **kwargs):
        super().__init__(config, *inputs, **kwargs)
        self.model_dim = config.d_model
        self.shared = TFSharedEmbeddings(config.vocab_size, config.d_model, name='shared')
        encoder_config = copy.deepcopy(config)
        self.encoder = TFT5MainLayer(encoder_config, name='encoder')
        decoder_config = copy.deepcopy(config)
        decoder_config.is_decoder = True
        self.decoder = TFT5MainLayer(decoder_config, name='decoder')

    def get_input_embeddings(self):
        return self.shared

    def get_output_embeddings(self):
        return self.shared

    def call(self, decoder_input_ids, **kwargs):
        if isinstance(decoder_input_ids, dict):
            kwargs.update(decoder_input_ids)
        else:
            kwargs['decoder_input_ids'] = decoder_input_ids
        kwargs_common = dict(((k, v) for k, v in kwargs.items() if not k.startswith('encoder_') and (not k.startswith('decoder_'))))
        kwargs_encoder = kwargs_common.copy()
        kwargs_decoder = kwargs_common.copy()
        kwargs_encoder.update(dict(((k[len('encoder_'):], v) for k, v in kwargs.items() if k.startswith('encoder_'))))
        kwargs_decoder.update(dict(((k[len('decoder_'):], v) for k, v in kwargs.items() if k.startswith('decoder_'))))
        encoder_hidden_states = kwargs_encoder.pop('hidden_states', None)
        if encoder_hidden_states is None:
            hidden_states = kwargs_encoder.pop('inputs_embeds', None)
            if hidden_states is None:
                encoder_inputs_ids = kwargs_encoder.pop('input_ids')
                hidden_states = self.shared(encoder_inputs_ids)
            encoder_outputs = self.encoder(hidden_states, **kwargs_encoder)
            encoder_hidden_states = encoder_outputs[0]
        else:
            encoder_outputs = ()
        hidden_states = kwargs_decoder.pop('inputs_embeds', None)
        if hidden_states is None:
            decoder_inputs_ids = kwargs_decoder.pop('input_ids')
            hidden_states = self.shared(decoder_inputs_ids)
        kwargs_decoder['encoder_hidden_states'] = encoder_hidden_states
        kwargs_decoder['encoder_attention_mask'] = kwargs_encoder.get('attention_mask', None)
        decoder_outputs = self.decoder(hidden_states, **kwargs_decoder)
        sequence_output = decoder_outputs[0] * self.model_dim ** (-0.5)
        lm_logits = self.shared(sequence_output, mode='linear')
        decoder_outputs = (lm_logits,) + decoder_outputs[1:]
        return decoder_outputs + encoder_outputs
