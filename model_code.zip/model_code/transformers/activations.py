import math
import torch
import torch.nn.functional as F

def swish(x):
    return x * torch.sigmoid(x)

def _gelu_python(x):
    return x * 0.5 * (1.0 + torch.erf(x / math.sqrt(2.0)))
gelu = getattr(F, 'gelu', _gelu_python)

def gelu_new(x):
    return 0.5 * x * (1 + torch.tanh(math.sqrt(2 / math.pi) * (x + 0.044715 * torch.pow(x, 3))))
ACT2FN = {'relu': F.relu, 'swish': swish, 'gelu': gelu, 'tanh': F.tanh, 'gelu_new': gelu_new}

def get_activation(activation_string):
    if activation_string in ACT2FN:
        return ACT2FN[activation_string]
    else:
        raise KeyError('function {} not found in ACT2FN mapping {} or torch.nn.functional'.format(activation_string, list(ACT2FN.keys())))
