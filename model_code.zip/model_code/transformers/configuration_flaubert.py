import logging
from .configuration_xlm import XLMConfig
logger = logging.getLogger(__name__)
FLAUBERT_PRETRAINED_CONFIG_ARCHIVE_MAP = {'flaubert-small-cased': 'https://s3.amazonaws.com/models.huggingface.co/bert/flaubert/flaubert_small_cased/config.json', 'flaubert-base-uncased': 'https://s3.amazonaws.com/models.huggingface.co/bert/flaubert/flaubert_base_uncased/config.json', 'flaubert-base-cased': 'https://s3.amazonaws.com/models.huggingface.co/bert/flaubert/flaubert_base_cased/config.json', 'flaubert-large-cased': 'https://s3.amazonaws.com/models.huggingface.co/bert/flaubert/flaubert_large_cased/config.json'}

class FlaubertConfig(XLMConfig):
    pretrained_config_archive_map = FLAUBERT_PRETRAINED_CONFIG_ARCHIVE_MAP
    model_type = 'flaubert'

    def __init__(self, layerdrop=0.0, pre_norm=False, **kwargs):
        super().__init__(**kwargs)
        self.layerdrop = layerdrop
        self.pre_norm = pre_norm
