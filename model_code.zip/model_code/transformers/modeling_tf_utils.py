import logging
import os
import h5py
import numpy as np
import tensorflow as tf
from tensorflow.python.keras.saving import hdf5_format
from .configuration_utils import PretrainedConfig
from .file_utils import DUMMY_INPUTS, TF2_WEIGHTS_NAME, WEIGHTS_NAME, cached_path, hf_bucket_url, is_remote_url
from .modeling_tf_pytorch_utils import load_pytorch_checkpoint_in_tf2_model
logger = logging.getLogger(__name__)

class TFModelUtilsMixin:

    def num_parameters(self, only_trainable: bool=False) -> int:
        if only_trainable:
            return int(sum((np.prod(w.shape.as_list()) for w in self.trainable_variables)))
        else:
            return self.count_params()

class TFPreTrainedModel(tf.keras.Model, TFModelUtilsMixin):
    config_class = None
    pretrained_model_archive_map = {}
    base_model_prefix = ''

    @property
    def dummy_inputs(self):
        return {'input_ids': tf.constant(DUMMY_INPUTS)}

    def __init__(self, config, *inputs, **kwargs):
        super().__init__(*inputs, **kwargs)
        if not isinstance(config, PretrainedConfig):
            raise ValueError('Parameter config in `{}(config)` should be an instance of class `PretrainedConfig`. To create a model from a pretrained model use `model = {}.from_pretrained(PRETRAINED_MODEL_NAME)`'.format(self.__class__.__name__, self.__class__.__name__))
        self.config = config

    def get_input_embeddings(self):
        base_model = getattr(self, self.base_model_prefix, self)
        if base_model is not self:
            return base_model.get_input_embeddings()
        else:
            raise NotImplementedError

    def get_output_embeddings(self):
        return None

    def _get_resized_embeddings(self, old_embeddings, new_num_tokens=None):
        pass

    def resize_token_embeddings(self, new_num_tokens=None):
        raise NotImplementedError

    def prune_heads(self, heads_to_prune):
        raise NotImplementedError

    def save_pretrained(self, save_directory):
        assert os.path.isdir(save_directory), 'Saving path should be a directory where the model and configuration can be saved'
        self.config.save_pretrained(save_directory)
        output_model_file = os.path.join(save_directory, TF2_WEIGHTS_NAME)
        self.save_weights(output_model_file)
        logger.info('Model weights saved in {}'.format(output_model_file))

    @classmethod
    def from_pretrained(cls, pretrained_model_name_or_path, *model_args, **kwargs):
        config = kwargs.pop('config', None)
        cache_dir = kwargs.pop('cache_dir', None)
        from_pt = kwargs.pop('from_pt', False)
        force_download = kwargs.pop('force_download', False)
        resume_download = kwargs.pop('resume_download', False)
        proxies = kwargs.pop('proxies', None)
        output_loading_info = kwargs.pop('output_loading_info', False)
        if not isinstance(config, PretrainedConfig):
            config_path = config if config is not None else pretrained_model_name_or_path
            config, model_kwargs = cls.config_class.from_pretrained(config_path, *model_args, cache_dir=cache_dir, return_unused_kwargs=True, force_download=force_download, resume_download=resume_download, **kwargs)
        else:
            model_kwargs = kwargs
        if pretrained_model_name_or_path is not None:
            if pretrained_model_name_or_path in cls.pretrained_model_archive_map:
                archive_file = cls.pretrained_model_archive_map[pretrained_model_name_or_path]
            elif os.path.isdir(pretrained_model_name_or_path):
                if os.path.isfile(os.path.join(pretrained_model_name_or_path, TF2_WEIGHTS_NAME)):
                    archive_file = os.path.join(pretrained_model_name_or_path, TF2_WEIGHTS_NAME)
                elif from_pt and os.path.isfile(os.path.join(pretrained_model_name_or_path, WEIGHTS_NAME)):
                    archive_file = os.path.join(pretrained_model_name_or_path, WEIGHTS_NAME)
                else:
                    raise EnvironmentError('Error no file named {} found in directory {} or `from_pt` set to False'.format([WEIGHTS_NAME, TF2_WEIGHTS_NAME], pretrained_model_name_or_path))
            elif os.path.isfile(pretrained_model_name_or_path) or is_remote_url(pretrained_model_name_or_path):
                archive_file = pretrained_model_name_or_path
            elif os.path.isfile(pretrained_model_name_or_path + '.index'):
                archive_file = pretrained_model_name_or_path + '.index'
            else:
                archive_file = hf_bucket_url(pretrained_model_name_or_path, postfix=WEIGHTS_NAME if from_pt else TF2_WEIGHTS_NAME)
            try:
                resolved_archive_file = cached_path(archive_file, cache_dir=cache_dir, force_download=force_download, resume_download=resume_download, proxies=proxies)
            except EnvironmentError as e:
                if pretrained_model_name_or_path in cls.pretrained_model_archive_map:
                    logger.error("Couldn't reach server at '{}' to download pretrained weights.".format(archive_file))
                else:
                    logger.error("Model name '{}' was not found in model name list ({}). We assumed '{}' was a path or url but couldn't find any file associated to this path or url.".format(pretrained_model_name_or_path, ', '.join(cls.pretrained_model_archive_map.keys()), archive_file))
                raise e
            if resolved_archive_file == archive_file:
                logger.info('loading weights file {}'.format(archive_file))
            else:
                logger.info('loading weights file {} from cache at {}'.format(archive_file, resolved_archive_file))
        else:
            resolved_archive_file = None
        model = cls(config, *model_args, **model_kwargs)
        if from_pt:
            return load_pytorch_checkpoint_in_tf2_model(model, resolved_archive_file, allow_missing_keys=True)
        model(model.dummy_inputs, training=False)
        assert os.path.isfile(resolved_archive_file), 'Error retrieving file {}'.format(resolved_archive_file)
        try:
            model.load_weights(resolved_archive_file, by_name=True)
        except OSError:
            raise OSError('Unable to load weights from h5 file. If you tried to load a TF 2.0 model from a PyTorch checkpoint, please set from_pt=True. ')
        model(model.dummy_inputs, training=False)
        with h5py.File(resolved_archive_file, 'r') as f:
            if 'layer_names' not in f.attrs and 'model_weights' in f:
                f = f['model_weights']
            hdf5_layer_names = set(hdf5_format.load_attributes_from_hdf5_group(f, 'layer_names'))
        model_layer_names = set((layer.name for layer in model.layers))
        missing_keys = list(model_layer_names - hdf5_layer_names)
        unexpected_keys = list(hdf5_layer_names - model_layer_names)
        error_msgs = []
        if len(missing_keys) > 0:
            logger.info('Layers of {} not initialized from pretrained model: {}'.format(model.__class__.__name__, missing_keys))
        if len(unexpected_keys) > 0:
            logger.info('Layers from pretrained model not used in {}: {}'.format(model.__class__.__name__, unexpected_keys))
        if len(error_msgs) > 0:
            raise RuntimeError('Error(s) in loading weights for {}:\n\t{}'.format(model.__class__.__name__, '\n\t'.join(error_msgs)))
        if output_loading_info:
            loading_info = {'missing_keys': missing_keys, 'unexpected_keys': unexpected_keys, 'error_msgs': error_msgs}
            return (model, loading_info)
        return model

class TFConv1D(tf.keras.layers.Layer):

    def __init__(self, nf, nx, initializer_range=0.02, **kwargs):
        super().__init__(**kwargs)
        self.nf = nf
        self.nx = nx
        self.initializer_range = initializer_range

    def build(self, input_shape):
        self.weight = self.add_weight('weight', shape=[self.nx, self.nf], initializer=get_initializer(self.initializer_range))
        self.bias = self.add_weight('bias', shape=[1, self.nf], initializer=tf.zeros_initializer())

    def call(self, x):
        bz, sl = shape_list(x)[:2]
        x = tf.reshape(x, [-1, self.nx])
        x = tf.matmul(x, self.weight) + self.bias
        x = tf.reshape(x, [bz, sl, self.nf])
        return x

class TFSharedEmbeddings(tf.keras.layers.Layer):

    def __init__(self, vocab_size, hidden_size, initializer_range=None, **kwargs):
        super().__init__(**kwargs)
        self.vocab_size = vocab_size
        self.hidden_size = hidden_size
        self.initializer_range = hidden_size ** (-0.5) if initializer_range is None else initializer_range

    def build(self, input_shape):
        self.weight = self.add_weight('weight', shape=[self.vocab_size, self.hidden_size], initializer=get_initializer(self.initializer_range))
        super().build(input_shape)

    def call(self, inputs, mode='embedding'):
        if mode == 'embedding':
            return self._embedding(inputs)
        elif mode == 'linear':
            return self._linear(inputs)
        else:
            raise ValueError('mode {} is not valid.'.format(mode))

    def _embedding(self, input_ids):
        return tf.gather(self.weight, input_ids)

    def _linear(self, inputs):
        first_dims = shape_list(inputs)[:-1]
        x = tf.reshape(inputs, [-1, self.hidden_size])
        logits = tf.matmul(x, self.weight, transpose_b=True)
        return tf.reshape(logits, first_dims + [self.vocab_size])

class TFSequenceSummary(tf.keras.layers.Layer):

    def __init__(self, config, initializer_range=0.02, **kwargs):
        super().__init__(**kwargs)
        self.summary_type = config.summary_type if hasattr(config, 'summary_use_proj') else 'last'
        if self.summary_type == 'attn':
            raise NotImplementedError
        self.has_summary = hasattr(config, 'summary_use_proj') and config.summary_use_proj
        if self.has_summary:
            if hasattr(config, 'summary_proj_to_labels') and config.summary_proj_to_labels and (config.num_labels > 0):
                num_classes = config.num_labels
            else:
                num_classes = config.hidden_size
            self.summary = tf.keras.layers.Dense(num_classes, kernel_initializer=get_initializer(initializer_range), name='summary')
        self.has_activation = hasattr(config, 'summary_activation') and config.summary_activation == 'tanh'
        if self.has_activation:
            self.activation = tf.keras.activations.tanh
        self.has_first_dropout = hasattr(config, 'summary_first_dropout') and config.summary_first_dropout > 0
        if self.has_first_dropout:
            self.first_dropout = tf.keras.layers.Dropout(config.summary_first_dropout)
        self.has_last_dropout = hasattr(config, 'summary_last_dropout') and config.summary_last_dropout > 0
        if self.has_last_dropout:
            self.last_dropout = tf.keras.layers.Dropout(config.summary_last_dropout)

    def call(self, inputs, training=False):
        if not isinstance(inputs, (dict, tuple, list)):
            hidden_states = inputs
            cls_index = None
        elif isinstance(inputs, (tuple, list)):
            hidden_states = inputs[0]
            cls_index = inputs[1] if len(inputs) > 1 else None
            assert len(inputs) <= 2, 'Too many inputs.'
        else:
            hidden_states = inputs.get('hidden_states')
            cls_index = inputs.get('cls_index', None)
        if self.summary_type == 'last':
            output = hidden_states[:, -1]
        elif self.summary_type == 'first':
            output = hidden_states[:, 0]
        elif self.summary_type == 'mean':
            output = tf.reduce_mean(hidden_states, axis=1)
        elif self.summary_type == 'cls_index':
            hidden_shape = shape_list(hidden_states)
            if cls_index is None:
                cls_index = tf.fill(hidden_shape[:-2], hidden_shape[-2] - 1)
            cls_shape = shape_list(cls_index)
            if len(cls_shape) <= len(hidden_shape) - 2:
                cls_index = cls_index[..., tf.newaxis]
            output = tf.gather(hidden_states, cls_index, batch_dims=len(hidden_shape) - 2)
            output = tf.squeeze(output, axis=len(hidden_shape) - 2)
        elif self.summary_type == 'attn':
            raise NotImplementedError
        if self.has_first_dropout:
            output = self.first_dropout(output, training=training)
        if self.has_summary:
            output = self.summary(output)
        if self.has_activation:
            output = self.activation(output)
        if self.has_last_dropout:
            output = self.last_dropout(output, training=training)
        return output

def shape_list(x):
    static = x.shape.as_list()
    dynamic = tf.shape(x)
    return [dynamic[i] if s is None else s for i, s in enumerate(static)]

def get_initializer(initializer_range=0.02):
    return tf.keras.initializers.TruncatedNormal(stddev=initializer_range)
