import logging
import os
import torch
from torch import nn
from .modeling_auto import AutoModel, AutoModelWithLMHead
logger = logging.getLogger(__name__)

class PreTrainedEncoderDecoder(nn.Module):

    def __init__(self, encoder, decoder):
        super().__init__()
        self.encoder = encoder
        self.decoder = decoder

    @classmethod
    def from_pretrained(cls, encoder_pretrained_model_name_or_path=None, decoder_pretrained_model_name_or_path=None, *model_args, **kwargs):
        kwargs_common = {argument: value for argument, value in kwargs.items() if not argument.startswith('encoder_') and (not argument.startswith('decoder_'))}
        kwargs_decoder = kwargs_common.copy()
        kwargs_encoder = kwargs_common.copy()
        kwargs_encoder.update({argument[len('encoder_'):]: value for argument, value in kwargs.items() if argument.startswith('encoder_')})
        kwargs_decoder.update({argument[len('decoder_'):]: value for argument, value in kwargs.items() if argument.startswith('decoder_')})
        encoder = kwargs_encoder.pop('model', None)
        if encoder is None:
            encoder = AutoModel.from_pretrained(encoder_pretrained_model_name_or_path, *model_args, **kwargs_encoder)
        encoder.config.is_decoder = False
        decoder = kwargs_decoder.pop('model', None)
        if decoder is None:
            decoder = AutoModelWithLMHead.from_pretrained(decoder_pretrained_model_name_or_path, **kwargs_decoder)
        decoder.config.is_decoder = True
        model = cls(encoder, decoder)
        return model

    def save_pretrained(self, save_directory):
        if not os.path.exists(save_directory):
            os.mkdir(save_directory)
        sub_directories = [directory for directory in os.listdir(save_directory) if os.path.isdir(os.path.join(save_directory, directory))]
        if len(sub_directories) > 0:
            if 'encoder' in sub_directories and 'decoder' in sub_directories:
                print('WARNING: there is an older version of encoder-decoder saved in' + ' the output directory. The default behaviour is to overwrite them.')
            for directory_to_remove in sub_directories:
                files_to_remove = os.listdir(os.path.join(save_directory, directory_to_remove))
                for file_to_remove in files_to_remove:
                    os.remove(os.path.join(save_directory, directory_to_remove, file_to_remove))
                os.rmdir(os.path.join(save_directory, directory_to_remove))
            assert len(os.listdir(save_directory)) == 0
        if not os.path.exists(os.path.join(save_directory, 'encoder')):
            os.mkdir(os.path.join(save_directory, 'encoder'))
        self.encoder.save_pretrained(os.path.join(save_directory, 'encoder'))
        if not os.path.exists(os.path.join(save_directory, 'decoder')):
            os.mkdir(os.path.join(save_directory, 'decoder'))
        self.decoder.save_pretrained(os.path.join(save_directory, 'decoder'))

    def forward(self, encoder_input_ids, decoder_input_ids, **kwargs):
        kwargs_encoder, kwargs_decoder = self.prepare_model_kwargs(**kwargs)
        encoder_hidden_states = kwargs_encoder.pop('hidden_states', None)
        if encoder_hidden_states is None:
            encoder_outputs = self.encoder(encoder_input_ids, **kwargs_encoder)
            encoder_hidden_states = encoder_outputs[0]
        else:
            encoder_outputs = ()
        kwargs_decoder['encoder_hidden_states'] = encoder_hidden_states
        decoder_outputs = self.decoder(decoder_input_ids, **kwargs_decoder)
        return decoder_outputs + encoder_outputs

class Model2Model(PreTrainedEncoderDecoder):

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.tie_weights()

    def tie_weights(self):
        pass

    @classmethod
    def from_pretrained(cls, pretrained_model_name_or_path, *args, **kwargs):
        if 'bert' not in pretrained_model_name_or_path or 'roberta' in pretrained_model_name_or_path or 'distilbert' in pretrained_model_name_or_path:
            raise ValueError('Only the Bert model is currently supported.')
        model = super().from_pretrained(*args, encoder_pretrained_model_name_or_path=pretrained_model_name_or_path, decoder_pretrained_model_name_or_path=pretrained_model_name_or_path, **kwargs)
        return model

class Model2LSTM(PreTrainedEncoderDecoder):

    @classmethod
    def from_pretrained(cls, *args, **kwargs):
        if kwargs.get('decoder_model', None) is None:
            if 'decoder_config' not in kwargs:
                raise ValueError("To load an LSTM in Encoder-Decoder model, please supply either:     - a torch.nn.LSTM model as `decoder_model` parameter (`decoder_model=lstm_model`), or    - a dictionary of configuration parameters that will be used to initialize a      torch.nn.LSTM model as `decoder_config` keyword argument.       E.g. `decoder_config={'input_size': 768, 'hidden_size': 768, 'num_layers': 2}`")
            kwargs['decoder_model'] = torch.nn.LSTM(kwargs.pop('decoder_config'))
        model = super().from_pretrained(*args, **kwargs)
        return model
