import collections
import logging
import os
import unicodedata
from .tokenization_bert import BasicTokenizer, BertTokenizer, WordpieceTokenizer, load_vocab
logger = logging.getLogger(__name__)
VOCAB_FILES_NAMES = {'vocab_file': 'vocab.txt'}
PRETRAINED_VOCAB_FILES_MAP = {'vocab_file': {'bert-base-japanese': 'https://s3.amazonaws.com/models.huggingface.co/bert/cl-tohoku/bert-base-japanese-vocab.txt', 'bert-base-japanese-whole-word-masking': 'https://s3.amazonaws.com/models.huggingface.co/bert/cl-tohoku/bert-base-japanese-whole-word-masking-vocab.txt', 'bert-base-japanese-char': 'https://s3.amazonaws.com/models.huggingface.co/bert/cl-tohoku/bert-base-japanese-char-vocab.txt', 'bert-base-japanese-char-whole-word-masking': 'https://s3.amazonaws.com/models.huggingface.co/bert/cl-tohoku/bert-base-japanese-char-whole-word-masking-vocab.txt'}}
PRETRAINED_POSITIONAL_EMBEDDINGS_SIZES = {'bert-base-japanese': 512, 'bert-base-japanese-whole-word-masking': 512, 'bert-base-japanese-char': 512, 'bert-base-japanese-char-whole-word-masking': 512}
PRETRAINED_INIT_CONFIGURATION = {'bert-base-japanese': {'do_lower_case': False, 'word_tokenizer_type': 'mecab', 'subword_tokenizer_type': 'wordpiece'}, 'bert-base-japanese-whole-word-masking': {'do_lower_case': False, 'word_tokenizer_type': 'mecab', 'subword_tokenizer_type': 'wordpiece'}, 'bert-base-japanese-char': {'do_lower_case': False, 'word_tokenizer_type': 'mecab', 'subword_tokenizer_type': 'character'}, 'bert-base-japanese-char-whole-word-masking': {'do_lower_case': False, 'word_tokenizer_type': 'mecab', 'subword_tokenizer_type': 'character'}}

class BertJapaneseTokenizer(BertTokenizer):
    vocab_files_names = VOCAB_FILES_NAMES
    pretrained_vocab_files_map = PRETRAINED_VOCAB_FILES_MAP
    pretrained_init_configuration = PRETRAINED_INIT_CONFIGURATION
    max_model_input_sizes = PRETRAINED_POSITIONAL_EMBEDDINGS_SIZES

    def __init__(self, vocab_file, do_lower_case=False, do_word_tokenize=True, do_subword_tokenize=True, word_tokenizer_type='basic', subword_tokenizer_type='wordpiece', never_split=None, unk_token='[UNK]', sep_token='[SEP]', pad_token='[PAD]', cls_token='[CLS]', mask_token='[MASK]', **kwargs):
        super(BertTokenizer, self).__init__(unk_token=unk_token, sep_token=sep_token, pad_token=pad_token, cls_token=cls_token, mask_token=mask_token, **kwargs)
        self.max_len_single_sentence = self.max_len - 2
        self.max_len_sentences_pair = self.max_len - 3
        if not os.path.isfile(vocab_file):
            raise ValueError("Can't find a vocabulary file at path '{}'. To load the vocabulary from a Google pretrained model use `tokenizer = BertTokenizer.from_pretrained(PRETRAINED_MODEL_NAME)`".format(vocab_file))
        self.vocab = load_vocab(vocab_file)
        self.ids_to_tokens = collections.OrderedDict([(ids, tok) for tok, ids in self.vocab.items()])
        self.do_word_tokenize = do_word_tokenize
        if do_word_tokenize:
            if word_tokenizer_type == 'basic':
                self.word_tokenizer = BasicTokenizer(do_lower_case=do_lower_case, never_split=never_split, tokenize_chinese_chars=False)
            elif word_tokenizer_type == 'mecab':
                self.word_tokenizer = MecabTokenizer(do_lower_case=do_lower_case, never_split=never_split)
            else:
                raise ValueError("Invalid word_tokenizer_type '{}' is specified.".format(word_tokenizer_type))
        self.do_subword_tokenize = do_subword_tokenize
        if do_subword_tokenize:
            if subword_tokenizer_type == 'wordpiece':
                self.subword_tokenizer = WordpieceTokenizer(vocab=self.vocab, unk_token=self.unk_token)
            elif subword_tokenizer_type == 'character':
                self.subword_tokenizer = CharacterTokenizer(vocab=self.vocab, unk_token=self.unk_token)
            else:
                raise ValueError("Invalid subword_tokenizer_type '{}' is specified.".format(subword_tokenizer_type))

    def _tokenize(self, text):
        if self.do_word_tokenize:
            tokens = self.word_tokenizer.tokenize(text, never_split=self.all_special_tokens)
        else:
            tokens = [text]
        if self.do_subword_tokenize:
            split_tokens = [sub_token for token in tokens for sub_token in self.subword_tokenizer.tokenize(token)]
        else:
            split_tokens = tokens
        return split_tokens

class MecabTokenizer(object):

    def __init__(self, do_lower_case=False, never_split=None, normalize_text=True):
        self.do_lower_case = do_lower_case
        self.never_split = never_split if never_split is not None else []
        self.normalize_text = normalize_text
        import MeCab
        self.mecab = MeCab.Tagger()

    def tokenize(self, text, never_split=None, **kwargs):
        if self.normalize_text:
            text = unicodedata.normalize('NFKC', text)
        never_split = self.never_split + (never_split if never_split is not None else [])
        tokens = []
        mecab_output = self.mecab.parse(text)
        cursor = 0
        for line in mecab_output.split('\n'):
            if line == 'EOS':
                break
            token, _ = line.split('\t')
            token_start = text.index(token, cursor)
            token_end = token_start + len(token)
            if self.do_lower_case and token not in never_split:
                token = token.lower()
            tokens.append(token)
            cursor = token_end
        return tokens

class CharacterTokenizer(object):

    def __init__(self, vocab, unk_token, normalize_text=True):
        self.vocab = vocab
        self.unk_token = unk_token
        self.normalize_text = normalize_text

    def tokenize(self, text):
        if self.normalize_text:
            text = unicodedata.normalize('NFKC', text)
        output_tokens = []
        for i, char in enumerate(text):
            if char not in self.vocab:
                output_tokens.append(self.unk_token)
                continue
            output_tokens.append(char)
        return output_tokens
