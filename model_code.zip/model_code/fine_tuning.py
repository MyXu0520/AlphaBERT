import sys as _sys
from pathlib import Path as _Path
_sys.path.insert(0, str(_Path(__file__).resolve().parents[1]))
from AlphaBERT_runtime import data_path, apply_config
import glob
import json
import logging
import os
import math
import re
import shutil
import random
import itertools
from multiprocessing import Pool
from typing import Dict, List, Tuple
from copy import deepcopy
import time
import pandas as pd
import numpy as np
import torch
import torch.nn as nn
from torch.utils.data import DataLoader, RandomSampler, SequentialSampler, TensorDataset
from torch.utils.data.distributed import DistributedSampler
from tqdm import tqdm, trange
import argparse
from transformers.data.processors.utils import DataProcessor
from sklearn.metrics import confusion_matrix, f1_score
from torch.cuda.amp import autocast, GradScaler
from transformers import WEIGHTS_NAME, AdamW, BertConfig, BertForSequenceClassification, DNATokenizer, get_linear_schedule_with_warmup
from transformers import glue_convert_examples_to_features as convert_examples_to_features
from transformers import glue_output_modes as output_modes
from transformers import glue_processors as processors
from transformers.data.processors.utils import InputExample
try:
    from torch.utils.tensorboard import SummaryWriter
except ImportError:
    from tensorboardX import SummaryWriter
bases = ['A', 'C', 'G', 'T', 'M', 'L']
VALID_KMERS = {''.join(p) for p in itertools.product(bases, repeat=5)}
logger = logging.getLogger(__name__)
logging.basicConfig(format='%(asctime)s - %(levelname)s - %(name)s - %(message)s', datefmt='%m/%d/%Y %H:%M:%S', level=logging.INFO)
logger = logging.getLogger(__name__)
MODEL_CLASSES = {'dna': (BertConfig, BertForSequenceClassification, DNATokenizer)}
TOKEN_ID_GROUP = ['bert', 'dnalong', 'dnalongcat', 'xlnet', 'albert']

class FocalLoss(nn.Module):

    def __init__(self, alpha=0.25, gamma=2.0):
        super(FocalLoss, self).__init__()
        self.alpha = alpha
        self.gamma = gamma

    def forward(self, inputs, targets):
        ce_loss = nn.functional.cross_entropy(inputs, targets, reduction='none')
        pt = torch.exp(-ce_loss)
        loss = self.alpha * (1 - pt) ** self.gamma * ce_loss
        return loss.mean()

def compute_dnaprom_metrics(preds, labels):
    preds = np.array(preds, dtype=int)
    labels = np.array(labels, dtype=int)
    cm = confusion_matrix(labels, preds)
    if cm.size == 1:
        tn = fp = fn = tp = 0
        if labels[0] == 0:
            tn = cm[0, 0]
        else:
            tp = cm[0, 0]
    else:
        tn, fp, fn, tp = cm.ravel()
    total = tp + tn + fp + fn
    acc = (tp + tn) / total if total > 0 else 0.0
    spec = tn / (tn + fp) if tn + fp > 0 else 0.0
    sens = tp / (tp + fn) if tp + fn > 0 else 0.0
    prec = tp / (tp + fp) if tp + fp > 0 else 0.0
    f1 = 2 * (prec * sens) / (prec + sens) if prec + sens > 0 else 0.0
    f1_macro = f1_score(labels, preds, average='macro')
    f1_weighted = f1_score(labels, preds, average='weighted')
    return {'acc': acc, 'spec': spec, 'sens': sens, 'prec': prec, 'f1': f1, 'f1_macro': f1_macro, 'f1_weighted': f1_weighted, 'tp': tp, 'tn': tn, 'fp': fp, 'fn': fn}

class DNAPromProcessor(DataProcessor):

    def get_example_from_tensor_dict(self, tensor_dict):
        return InputExample(tensor_dict['idx'].numpy(), tensor_dict['sentence'].numpy().decode('utf-8'), None, str(tensor_dict['label'].numpy()))

    def get_train_examples(self, data_dir):
        return self._create_examples(os.path.join(data_dir, 'train.tsv'), 'train')

    def get_dev_examples(self, data_dir):
        return self._create_examples(os.path.join(data_dir, 'dev.tsv'), 'dev')

    def get_test_examples(self, data_dir):
        return self._create_examples(os.path.join(data_dir, 'test.tsv'), 'test')

    def get_labels(self):
        return ['0', '1']

    def _create_examples(self, file_path, set_type):
        examples = []
        invalid_lines = 0
        invalid_labels = 0
        invalid_kmers = 0
        with open(file_path, 'r', encoding='utf-8') as f:
            lines = f.readlines()
            start_index = 0
            if lines and (lines[0].startswith('sequence') or lines[0].startswith('label')):
                start_index = 1
                logger.info(f'跳过标题行: {lines[0].strip()}')
            for i, line in enumerate(lines[start_index:], start=start_index):
                line = line.strip()
                if not line:
                    continue
                parts = line.split('\t')
                if len(parts) < 2:
                    invalid_lines += 1
                    logger.debug(f"跳过格式错误行 {i + 1}: 列数不足 - '{line[:50]}...'")
                    continue
                label = parts[-1].strip()
                if label not in ['0', '1']:
                    invalid_labels += 1
                    logger.debug(f"行 {i + 1}: 无效标签 '{label}' - '{line[:50]}...'")
                    continue
                kmer_sequence = ' '.join(parts[:-1]).strip()
                kmers = kmer_sequence.split()
                if not kmers:
                    invalid_kmers += 1
                    logger.debug(f"行 {i + 1}: 空序列 - '{line[:50]}...'")
                    continue
                invalid_found = False
                for kmer in kmers:
                    if kmer not in VALID_KMERS:
                        invalid_kmers += 1
                        logger.debug(f"行 {i + 1}: 无效5-mer '{kmer}' - '{line[:50]}...'")
                        invalid_found = True
                        break
                if invalid_found:
                    continue
                guid = f'{set_type}-{i}'
                examples.append(InputExample(guid=guid, text_a=kmer_sequence, text_b=None, label=label))
        if set_type == 'train' and examples:
            positive_examples = [ex for ex in examples if ex.label == '1']
            negative_examples = [ex for ex in examples if ex.label == '0']
            target_count = len(negative_examples)
            needed_positives = max(0, target_count - len(positive_examples))
            if needed_positives > 0 and positive_examples:
                duplicated = random.choices(positive_examples, k=needed_positives)
                new_examples = [InputExample(guid=f'{ex.guid}-dup-{i}', text_a=ex.text_a, text_b=ex.text_b, label=ex.label) for i, ex in enumerate(duplicated)]
                examples.extend(new_examples)
                logger.info(f'过采样: 新增 {needed_positives} 阳性样本，阳性样本数: {len(positive_examples) + needed_positives}，阴性样本数: {len(negative_examples)}')
        logger.info(f'加载 {len(examples)} 个样本 (跳过 {invalid_lines} 无效行, {invalid_labels} 无效标签, {invalid_kmers} 无效5-mer)')
        if examples:
            label_counts = pd.Series([ex.label for ex in examples]).value_counts()
            logger.info(f'标签分布:\n{label_counts}')
        else:
            logger.warning('未加载任何有效样本!')
        return examples
processors['dnaprom'] = DNAPromProcessor

class Config(object):

    def __init__(self):
        self.data_dir = data_path('finetune')
        self.model_type = 'dna'
        self.n_process = 1
        self.should_continue = False
        self.model_name_or_path = data_path('models/pretrain')
        self.task_name = 'dnaprom'
        self.output_dir = data_path('models/finetune')
        self.visualize_data_dir = data_path('fineTune9/vis')
        self.result_dir = ''
        self.config_name = ''
        self.tokenizer_name = ''
        self.cache_dir = ''
        self.predict_dir = ''
        self.max_seq_length = 200
        self.do_train = True
        self.do_eval = True
        self.do_predict = False
        self.do_visualize = False
        self.visualize_train = True
        self.do_ensemble_pred = False
        self.evaluate_during_training = True
        self.do_lower_case = False
        self.per_gpu_train_batch_size = 32
        self.per_gpu_eval_batch_size = 64
        self.per_gpu_pred_batch_size = 32
        self.early_stop = 5
        self.predict_scan_size = 1
        self.gradient_accumulation_steps = 4
        self.learning_rate = 2e-05
        self.weight = [1.0, 5.0]
        self.weight_decay = 0.01
        self.adam_epsilon = 1e-08
        self.beta1 = 0.9
        self.beta2 = 0.999
        self.max_grad_norm = 0.5
        self.attention_probs_dropout_prob = 0.3
        self.hidden_dropout_prob = 0.3
        self.rnn_dropout = 0.3
        self.rnn = 'lstm'
        self.num_rnn_layer = 2
        self.rnn_hidden = 768
        self.num_train_epochs = 10.0
        self.max_steps = -1
        self.warmup_steps = 1000
        self.warmup_percent = 0.1
        self.logging_steps = 500
        self.save_steps = 1000
        self.save_total_limit = 2
        self.eval_all_checkpoints = False
        self.no_cuda = False
        self.overwrite_output_dir = True
        self.overwrite_cache = True
        self.visualize_models = True
        self.seed = 42
        self.fp16 = False
        self.local_rank = -1
        self.server_ip = ''
        self.server_port = ''
        self.n_gpu = 1
        self.use_focal_loss = True
        self.focal_alpha = 0.9
        self.focal_gamma = 2.0
        apply_config(self, 'finetune')

def set_seed(args):
    random.seed(args.seed)
    np.random.seed(args.seed)
    torch.manual_seed(args.seed)
    if args.n_gpu > 0:
        torch.cuda.manual_seed_all(args.seed)

def _sorted_checkpoints(args, checkpoint_prefix='checkpoint', use_mtime=False) -> List[str]:
    ordering_and_checkpoint_path = []
    glob_checkpoints = glob.glob(os.path.join(args.output_dir, '{}-*'.format(checkpoint_prefix)))
    for path in glob_checkpoints:
        if use_mtime:
            ordering_and_checkpoint_path.append((os.path.getmtime(path), path))
        else:
            regex_match = re.match('.*{}-(?:epoch)?([0-9]+)$'.format(checkpoint_prefix), path)
            if regex_match and regex_match.groups():
                ordering_and_checkpoint_path.append((int(regex_match.groups()[0]), path))
    checkpoints_sorted = sorted(ordering_and_checkpoint_path)
    checkpoints_sorted = [checkpoint[1] for checkpoint in checkpoints_sorted]
    return checkpoints_sorted

def _rotate_checkpoints(args, checkpoint_prefix='checkpoint', use_mtime=False) -> None:
    if not args.save_total_limit:
        return
    if args.save_total_limit <= 0:
        return
    checkpoints_sorted = _sorted_checkpoints(args, checkpoint_prefix, use_mtime)
    if len(checkpoints_sorted) <= args.save_total_limit:
        return
    number_of_checkpoints_to_delete = max(0, len(checkpoints_sorted) - args.save_total_limit)
    checkpoints_to_be_deleted = checkpoints_sorted[:number_of_checkpoints_to_delete]
    for checkpoint in checkpoints_to_be_deleted:
        try:
            shutil.rmtree(checkpoint)
        except Exception as e:
            logger.warning(f'Error deleting checkpoint {checkpoint}: {e}')

def inspect_data(data_path):
    with open(data_path, 'r') as f:
        lines = f.readlines()
    logger.info(f'检查数据文件: {data_path}, 总行数: {len(lines)}')
    valid_count = 0
    invalid_lines = 0
    invalid_labels = 0
    invalid_kmers = 0
    positive_count = 0
    negative_count = 0
    start_index = 0
    if lines and (lines[0].startswith('sequence') or lines[0].startswith('label')):
        start_index = 1
        logger.info(f'检测到标题行: {lines[0].strip()}')
    for i, line in enumerate(lines[start_index:], start=start_index):
        line = line.strip()
        if not line:
            continue
        parts = line.split('\t')
        if len(parts) < 2:
            invalid_lines += 1
            logger.debug(f"行 {i + 1}: 列数不足 ({len(parts)}列) - '{line[:50]}...'")
            continue
        label = parts[-1].strip()
        if label not in ['0', '1']:
            invalid_labels += 1
            logger.debug(f"行 {i + 1}: 无效标签 '{label}' - '{line[:50]}...'")
            continue
        kmer_sequence = ' '.join(parts[:-1]).strip()
        kmers = kmer_sequence.split()
        if not kmers:
            invalid_kmers += 1
            logger.debug(f"行 {i + 1}: 空序列 - '{line[:50]}...'")
            continue
        valid_kmer = True
        for kmer in kmers:
            if kmer not in VALID_KMERS:
                invalid_kmers += 1
                logger.debug(f"行 {i + 1}: 无效5-mer '{kmer}' - '{line[:50]}...'")
                valid_kmer = False
                break
        if not valid_kmer:
            continue
        if label == '1':
            positive_count += 1
        else:
            negative_count += 1
        valid_count += 1
    logger.info(f'有效样本: {valid_count}/{len(lines) - start_index} ({valid_count / (len(lines) - start_index):.2%})')
    logger.info(f'阳性样本: {positive_count}, 阴性样本: {negative_count}')
    logger.info(f'阳性比例: {positive_count / (positive_count + negative_count):.2%}')
    logger.info(f'问题统计: {invalid_lines} 无效行, {invalid_labels} 无效标签, {invalid_kmers} 无效5-mer')
    return valid_count

def check_data_leakage(train_file, dev_file):
    logger.info('***** 检查数据泄露 *****')

    def read_sequences(file_path):
        sequences = set()
        with open(file_path, 'r') as f:
            lines = f.readlines()
            start_index = 1 if lines and (lines[0].startswith('sequence') or lines[0].startswith('label')) else 0
            for line in lines[start_index:]:
                parts = re.split('\\t+', line.strip())
                if len(parts) >= 2:
                    sequence = ' '.join(parts[:-1]).strip()
                    sequences.add(sequence)
        return sequences
    train_sequences = read_sequences(train_file)
    dev_sequences = read_sequences(dev_file)
    common_sequences = train_sequences & dev_sequences
    common_count = len(common_sequences)
    if common_count > 0:
        logger.warning(f'发现 {common_count} 个重复序列在训练集和验证集之间!')
        leak_file = os.path.join(os.path.dirname(train_file), 'data_leakage.txt')
        with open(leak_file, 'w') as f:
            f.write('重复序列:\n')
            for seq in list(common_sequences)[:100]:
                f.write(f'{seq}\n')
        logger.warning(f'保存前100个泄露样本到: {leak_file}')
    else:
        logger.info('未发现数据泄露问题')
    return common_count

def train(args, train_dataset, model, tokenizer, eval_dataset=None):
    if args.local_rank in [-1, 0]:
        tb_writer = SummaryWriter(log_dir=args.output_dir)
    args.train_batch_size = args.per_gpu_train_batch_size
    if len(train_dataset) == 0:
        raise ValueError('训练数据为空')
    train_sampler = RandomSampler(train_dataset) if args.local_rank == -1 else DistributedSampler(train_dataset)
    train_dataloader = DataLoader(train_dataset, sampler=train_sampler, batch_size=args.train_batch_size)
    if eval_dataset is None:
        eval_dataset = load_and_cache_examples(args, args.task_name, tokenizer, evaluate=True)
    if args.max_steps > 0:
        t_total = args.max_steps
        args.num_train_epochs = args.max_steps // max(1, math.ceil(len(train_dataloader) / args.gradient_accumulation_steps)) + 1
    else:
        t_total = max(1, math.ceil(len(train_dataloader) / args.gradient_accumulation_steps)) * args.num_train_epochs
    scaler = GradScaler(enabled=args.fp16)
    no_decay = ['bias', 'LayerNorm.weight']
    optimizer_grouped_parameters = [{'params': [p for n, p in model.named_parameters() if not any((nd in n for nd in no_decay))], 'weight_decay': args.weight_decay}, {'params': [p for n, p in model.named_parameters() if any((nd in n for nd in no_decay))], 'weight_decay': 0.0}]
    warmup_steps = args.warmup_steps if args.warmup_percent == 0 else int(args.warmup_percent * t_total)
    ignored_params = list(map(id, model.classifier.parameters()))
    base_params = list(filter(lambda p: id(p) not in ignored_params, model.parameters()))
    optimizer = AdamW([{'params': base_params, 'lr': args.learning_rate / 10}, {'params': model.classifier.parameters(), 'lr': args.learning_rate}], eps=args.adam_epsilon, betas=(args.beta1, args.beta2))
    scheduler = get_linear_schedule_with_warmup(optimizer, num_warmup_steps=warmup_steps, num_training_steps=t_total)
    focal_loss = None
    if args.use_focal_loss:
        focal_loss = FocalLoss(alpha=args.focal_alpha, gamma=args.focal_gamma)
        logger.info(f'使用Focal Loss (alpha={args.focal_alpha}, gamma={args.focal_gamma})')
    if args.n_gpu > 1:
        model = torch.nn.DataParallel(model)
    if args.local_rank != -1:
        model = torch.nn.parallel.DistributedDataParallel(model, device_ids=[args.local_rank], output_device=args.local_rank, find_unused_parameters=True)
    logger.info('***** 训练前数据验证 *****')
    sample = train_dataset[0]
    logger.info(f'样本示例: input_ids={sample[0]}, label={sample[3]}')
    logger.info(f'解码序列: {tokenizer.decode(sample[0].tolist())}')
    labels = [sample[3].item() for sample in train_dataset]
    label_counts = pd.Series(labels).value_counts()
    logger.info(f'训练集标签分布:\n{label_counts}')
    logger.info('***** 开始训练 *****')
    logger.info('  样本数 = %d', len(train_dataset))
    logger.info('  训练轮数 = %d', args.num_train_epochs)
    logger.info('  每GPU批大小 = %d', args.per_gpu_train_batch_size)
    logger.info('  总优化步数 = %d', t_total)
    logger.info('  梯度累积步数 = %d', args.gradient_accumulation_steps)
    logger.info('  混合精度训练 = %s', args.fp16)
    logger.info('  类别权重 = %s', args.weight)
    global_step = 0
    tr_loss, logging_loss = (0.0, 0.0)
    epoch_loss = 0.0
    model.zero_grad()
    train_iterator = trange(int(args.num_train_epochs), desc='训练轮次')
    set_seed(args)
    best_f1 = -1.0
    best_acc = 0
    best_acc_sens = 0
    best_acc_spec = 0
    best_eval_loss = float('inf')
    stop_count = 0
    for epoch in train_iterator:
        epoch_loss = 0.0
        epoch_iterator = tqdm(train_dataloader, desc=f'轮次 {epoch + 1}/{int(args.num_train_epochs)}', position=0, leave=True)
        for step, batch in enumerate(epoch_iterator):
            if args.max_steps > 0 and global_step >= args.max_steps:
                break
            model.train()
            batch = tuple((t.to(args.device) for t in batch))
            with autocast(enabled=args.fp16):
                inputs = {'input_ids': batch[0], 'attention_mask': batch[1], 'labels': batch[3]}
                if args.model_type != 'distilbert':
                    inputs['token_type_ids'] = batch[2] if args.model_type in TOKEN_ID_GROUP else None
                outputs = model(**inputs)
                if args.use_focal_loss:
                    logits = outputs[1]
                    loss = focal_loss(logits.view(-1, logits.shape[-1]), inputs['labels'].view(-1))
                else:
                    loss = outputs[0]
            if args.n_gpu > 1:
                loss = loss.mean()
            if args.gradient_accumulation_steps > 1:
                loss = loss / min(args.gradient_accumulation_steps, len(train_dataloader) - step // args.gradient_accumulation_steps * args.gradient_accumulation_steps)
            scaler.scale(loss).backward()
            tr_loss += loss.item()
            epoch_loss += loss.item()
            if (step + 1) % args.gradient_accumulation_steps == 0 or step + 1 == len(train_dataloader):
                scaler.unscale_(optimizer)
                torch.nn.utils.clip_grad_norm_(model.parameters(), args.max_grad_norm)
                scaler.step(optimizer)
                scaler.update()
                scheduler.step()
                model.zero_grad()
                global_step += 1
                if args.logging_steps > 0 and global_step % args.logging_steps == 0:
                    logs = {}
                    loss_scalar = (tr_loss - logging_loss) / args.logging_steps
                    learning_rate_scalar = scheduler.get_last_lr()[0]
                    logs['learning_rate'] = learning_rate_scalar
                    logs['loss'] = loss_scalar
                    logging_loss = tr_loss
                    if args.local_rank in [-1, 0]:
                        for key, value in logs.items():
                            tb_writer.add_scalar(key, value, global_step)
                        logger.info(f'全局步数: {global_step}, 学习率: {learning_rate_scalar:.7f}, 平均损失: {loss_scalar:.4f}')
        epoch_loss = epoch_loss / len(train_dataloader)
        logger.info(f'轮次 {epoch + 1} 结束，训练平均损失: {epoch_loss:.4f}')
        eval_results = evaluate(args, model, tokenizer, prefix=f'epoch{epoch + 1}', eval_dataset=eval_dataset)
        current_f1 = eval_results.get('f1', 0)
        current_acc = eval_results.get('acc', 0)
        current_sens = eval_results.get('sens', 0)
        current_eval_loss = eval_results.get('eval_loss', float('inf'))
        if args.local_rank in [-1, 0]:
            tb_writer.add_scalar('eval_loss', current_eval_loss, epoch + 1)
            tb_writer.add_scalar('eval_f1', current_f1, epoch + 1)
            tb_writer.add_scalar('eval_acc', current_acc, epoch + 1)
            tb_writer.add_scalar('eval_sens', current_sens, epoch + 1)
        save_model = False
        if current_f1 > best_f1:
            best_f1 = current_f1
            best_acc = current_acc
            best_acc_sens = current_sens
            best_acc_spec = eval_results.get('spec', 0)
            best_eval_loss = current_eval_loss
            save_model = True
            logger.info(f'发现新的最佳F1: {best_f1:.4f}')
        if args.local_rank in [-1, 0]:
            checkpoint_prefix = 'checkpoint'
            output_dir = os.path.join(args.output_dir, f'{checkpoint_prefix}-epoch{epoch + 1}')
            os.makedirs(output_dir, exist_ok=True)
            model_to_save = model.module if hasattr(model, 'module') else model
            model_to_save.save_pretrained(output_dir)
            tokenizer.save_pretrained(output_dir)
            torch.save(args, os.path.join(output_dir, 'training_args.bin'))
            logger.info(f'保存模型检查点到 {output_dir}')
            output_eval_file = os.path.join(output_dir, 'eval_results.txt')
            with open(output_eval_file, 'w') as writer:
                for key, value in eval_results.items():
                    writer.write(f'{key} = {value}\n')
                writer.write(f'epoch = {epoch + 1}\n')
            _rotate_checkpoints(args, checkpoint_prefix)
        if save_model and args.local_rank in [-1, 0]:
            best_model_dir = os.path.join(args.output_dir, 'best_model')
            os.makedirs(best_model_dir, exist_ok=True)
            if os.path.exists(best_model_dir):
                try:
                    shutil.rmtree(best_model_dir)
                except Exception as e:
                    logger.warning(f'删除旧最佳模型失败: {e}')
            os.makedirs(best_model_dir, exist_ok=True)
            model_to_save = model.module if hasattr(model, 'module') else model
            model_to_save.save_pretrained(best_model_dir)
            tokenizer.save_pretrained(best_model_dir)
            logger.info(f'保存新的最佳模型! F1: {best_f1:.4f}, 准确率: {best_acc:.4f}, 敏感性: {best_acc_sens:.4f}')
            output_eval_file = os.path.join(best_model_dir, 'eval_results.txt')
            with open(output_eval_file, 'a') as writer:
                writer.write(f'最佳F1: {best_f1:.4f}\n')
                writer.write(f'最佳准确率: {best_acc:.4f}\n')
                writer.write(f'最佳敏感性: {best_acc_sens:.4f}\n')
                writer.write(f'最佳特异性: {best_acc_spec:.4f}\n')
                writer.write(f'验证损失: {best_eval_loss:.6f}\n')
                for key, value in eval_results.items():
                    writer.write(f'{key}: {value}\n')
            stop_count = 0
        else:
            stop_count += 1
            logger.info(f'早停计数器: {stop_count}/{args.early_stop} (当前F1: {current_f1:.4f}, 最佳F1: {best_f1:.4f}, 当前损失: {current_eval_loss:.6f}, 最佳损失: {best_eval_loss:.6f})')
        if args.early_stop > 0 and stop_count >= args.early_stop:
            logger.info(f'早停触发! 连续 {args.early_stop} 轮次评估指标未提升')
            train_iterator.close()
            break
    if args.local_rank in [-1, 0]:
        tb_writer.close()
    logger.info(f'训练完成! 最终全局步数: {global_step}, 平均损失: {tr_loss / max(1, global_step):.4f}')
    final_model_dir = os.path.join(args.output_dir, 'final_model')
    os.makedirs(final_model_dir, exist_ok=True)
    model_to_save = model.module if hasattr(model, 'module') else model
    model_to_save.save_pretrained(final_model_dir)
    tokenizer.save_pretrained(final_model_dir)
    logger.info(f'最终模型保存在: {final_model_dir}')
    return (global_step, tr_loss / max(1, global_step))

def evaluate(args, model, tokenizer, prefix='', evaluate=True, eval_dataset=None):
    if eval_dataset is None:
        eval_dataset = load_and_cache_examples(args, args.task_name, tokenizer, evaluate=evaluate)
    if len(eval_dataset) == 0:
        logger.error('评估数据集为空!')
        return {'error': '评估数据集为空'}
    args.eval_batch_size = args.per_gpu_eval_batch_size
    eval_sampler = SequentialSampler(eval_dataset)
    eval_dataloader = DataLoader(eval_dataset, sampler=eval_sampler, batch_size=args.eval_batch_size)
    if args.n_gpu > 1 and (not isinstance(model, torch.nn.DataParallel)):
        model = torch.nn.DataParallel(model)
    logger.info(f'***** 开始评估: {prefix} *****')
    logger.info('  样本数 = %d', len(eval_dataset))
    logger.info('  批大小 = %d', args.eval_batch_size)
    eval_loss = 0.0
    nb_eval_steps = 0
    preds = None
    out_label_ids = None
    model.eval()
    for batch in tqdm(eval_dataloader, desc=f'{prefix}评估中', position=0, leave=True):
        batch = tuple((t.to(args.device) for t in batch))
        with torch.no_grad():
            inputs = {'input_ids': batch[0], 'attention_mask': batch[1], 'labels': batch[3]}
            if args.model_type != 'distilbert':
                inputs['token_type_ids'] = batch[2] if args.model_type in TOKEN_ID_GROUP else None
            outputs = model(**inputs)
            tmp_eval_loss, logits = outputs[:2]
            eval_loss += tmp_eval_loss.mean().item()
        nb_eval_steps += 1
        if preds is None:
            preds = logits.detach().cpu().numpy()
            out_label_ids = inputs['labels'].detach().cpu().numpy()
        else:
            preds = np.append(preds, logits.detach().cpu().numpy(), axis=0)
            out_label_ids = np.append(out_label_ids, inputs['labels'].detach().cpu().numpy(), axis=0)
    eval_loss = eval_loss / nb_eval_steps
    if args.output_mode == 'classification':
        preds = np.argmax(preds, axis=1)
    result = compute_dnaprom_metrics(preds, out_label_ids)
    result['eval_loss'] = eval_loss
    error_indices = np.where(preds != out_label_ids)[0]
    if error_indices.size > 0:
        error_log = os.path.join(args.output_dir, f'{prefix}_error_samples.txt')
        with open(error_log, 'w') as f:
            f.write('预测标签\t真实标签\t输入序列\n')
            for idx in error_indices[:1000]:
                sample = eval_dataset[idx]
                input_ids = sample[0].tolist()
                sequence = tokenizer.decode(input_ids, skip_special_tokens=True)
                f.write(f'{preds[idx]}\t{out_label_ids[idx]}\t{sequence}\n')
        false_negatives = np.where((out_label_ids == 1) & (preds == 0))[0]
        if false_negatives.size > 0:
            fn_log = os.path.join(args.output_dir, f'{prefix}_false_negatives.txt')
            with open(fn_log, 'w') as f:
                f.write('假阴性样本序列:\n')
                for idx in false_negatives[:1000]:
                    sample = eval_dataset[idx]
                    input_ids = sample[0].tolist()
                    sequence = tokenizer.decode(input_ids, skip_special_tokens=True)
                    f.write(f'{sequence}\n')
        logger.info(f'保存 {min(1000, len(error_indices))} 个错误样本到 {error_log}')
        if false_negatives.size > 0:
            logger.warning(f'发现 {len(false_negatives)} 个假阴性样本，保存前1000个到 {fn_log}')
    logger.info('***** 评估结果 *****')
    for key, value in result.items():
        logger.info('  %s = %s', key, str(value))
    return result

def load_and_cache_examples(args, task, tokenizer, evaluate=False):
    processor = processors[task]()
    output_mode = output_modes[task]
    cached_features_file = os.path.join(args.data_dir, f"cached_{('dev' if evaluate else 'train')}_{args.model_type}_{args.max_seq_length}_{task}.dat")
    if os.path.exists(cached_features_file) and (not args.overwrite_cache):
        logger.info(f'从缓存文件加载特征: {cached_features_file}')
        features = torch.load(cached_features_file)
    else:
        logger.info(f'从数据集文件创建特征: {args.data_dir}')
        if evaluate:
            examples = processor.get_dev_examples(args.data_dir)
        else:
            examples = processor.get_train_examples(args.data_dir)
        if not examples:
            logger.error('未加载任何样本!')
            return TensorDataset(torch.tensor([]), torch.tensor([]), torch.tensor([]), torch.tensor([]))
        logger.info(f'加载 {len(examples)} 个样本')
        max_length = args.max_seq_length
        pad_on_left = bool(args.model_type in ['xlnet'])
        pad_token = tokenizer.convert_tokens_to_ids([tokenizer.pad_token])[0]
        pad_token_segment_id = 4 if args.model_type in ['xlnet'] else 0
        features = convert_examples_to_features(examples, tokenizer, label_list=processor.get_labels(), max_length=max_length, output_mode=output_mode, pad_on_left=pad_on_left, pad_token=pad_token, pad_token_segment_id=pad_token_segment_id)
        if args.local_rank in [-1, 0]:
            logger.info(f'保存特征到缓存文件: {cached_features_file}')
            torch.save(features, cached_features_file)
    all_input_ids = torch.tensor([f.input_ids for f in features], dtype=torch.long)
    all_attention_mask = torch.tensor([f.attention_mask for f in features], dtype=torch.long)
    all_token_type_ids = torch.tensor([f.token_type_ids for f in features], dtype=torch.long)
    if output_mode == 'classification':
        all_labels = torch.tensor([int(f.label) for f in features], dtype=torch.long)
    elif output_mode == 'regression':
        all_labels = torch.tensor([float(f.label) for f in features], dtype=torch.float)
    dataset = TensorDataset(all_input_ids, all_attention_mask, all_token_type_ids, all_labels)
    return dataset

def main():
    args = Config()
    if args.local_rank == -1 or args.no_cuda:
        device = torch.device('cuda' if torch.cuda.is_available() and (not args.no_cuda) else 'cpu')
        args.n_gpu = torch.cuda.device_count() if torch.cuda.is_available() and (not args.no_cuda) else 0
    else:
        torch.cuda.set_device(args.local_rank)
        device = torch.device('cuda', args.local_rank)
        torch.distributed.init_process_group(backend='nccl')
        args.n_gpu = 1
    args.device = device
    args.fp16 = args.fp16 and device.type == 'cuda'
    if args.gradient_accumulation_steps < 1:
        raise ValueError('梯度累积步数必须为正数')
    logger.info(f'使用设备: {device}, GPU数量: {args.n_gpu}')
    set_seed(args)
    args.task_name = args.task_name.lower()
    if args.task_name not in processors:
        raise ValueError(f'未知任务: {args.task_name}')
    processor = processors[args.task_name]()
    args.output_mode = output_modes[args.task_name]
    label_list = processor.get_labels()
    num_labels = len(label_list)
    logger.info(f'任务: {args.task_name}, 标签数: {num_labels}')
    logger.info('***** 数据质量检查 *****')
    train_file = os.path.join(args.data_dir, 'train.tsv')
    dev_file = os.path.join(args.data_dir, 'dev.tsv')
    inspect_data(train_file)
    inspect_data(dev_file)
    leaked_count = check_data_leakage(train_file, dev_file)
    if leaked_count > 0:
        logger.warning(f'发现 {leaked_count} 个泄露样本，请检查数据分割!')
    args.model_type = args.model_type.lower()
    config_class, model_class, tokenizer_class = MODEL_CLASSES[args.model_type]
    os.makedirs(args.output_dir, exist_ok=True)
    tokenizer = tokenizer_class.from_pretrained(args.tokenizer_name if args.tokenizer_name else args.model_name_or_path, do_lower_case=args.do_lower_case, cache_dir=args.cache_dir if args.cache_dir else None)
    config = config_class.from_pretrained(args.config_name if args.config_name else args.model_name_or_path, num_labels=num_labels, finetuning_task=args.task_name, cache_dir=args.cache_dir if args.cache_dir else None)
    config.hidden_dropout_prob = args.hidden_dropout_prob
    config.attention_probs_dropout_prob = args.attention_probs_dropout_prob
    config.weight = args.weight
    if args.model_type in ['dnalong', 'dnalongcat']:
        assert args.max_seq_length % 512 == 0, '最大序列长度必须是512的倍数'
        config.split = int(args.max_seq_length / 512)
    config.rnn = args.rnn
    config.num_rnn_layer = args.num_rnn_layer
    config.rnn_dropout = args.rnn_dropout
    config.rnn_hidden = args.rnn_hidden
    logger.info(f'从 {args.model_name_or_path} 加载预训练模型')
    model = model_class.from_pretrained(args.model_name_or_path, from_tf=bool('.ckpt' in args.model_name_or_path), config=config, cache_dir=args.cache_dir if args.cache_dir else None)
    model.to(args.device)
    logger.info(f'模型加载完成，参数量: {sum((p.numel() for p in model.parameters() if p.requires_grad)):,}')
    eval_dataset = None
    if args.do_eval:
        logger.info('预加载验证数据集...')
        eval_dataset = load_and_cache_examples(args, args.task_name, tokenizer, evaluate=True)
    if args.do_train:
        logger.info('*** 训练模式 ***')
        train_dataset = load_and_cache_examples(args, args.task_name, tokenizer, evaluate=False)
        logger.info(f'训练集大小: {len(train_dataset)}')
        train(args, train_dataset, model, tokenizer, eval_dataset=eval_dataset)
    if args.do_eval:
        logger.info('*** 评估模式 ***')
        best_model_dir = os.path.join(args.output_dir, 'best_model')
        if os.path.exists(best_model_dir):
            logger.info(f'加载最佳模型: {best_model_dir}')
            model = model_class.from_pretrained(best_model_dir)
            model.to(args.device)
        else:
            logger.info('使用最终模型进行评估')
            final_model_dir = os.path.join(args.output_dir, 'final_model')
            if os.path.exists(final_model_dir):
                model = model_class.from_pretrained(final_model_dir)
                model.to(args.device)
            else:
                logger.error('找不到任何模型进行评估!')
                return
        eval_results = evaluate(args, model, tokenizer, prefix='final', eval_dataset=eval_dataset)
        output_eval_file = os.path.join(args.output_dir, 'final_eval_results.txt')
        with open(output_eval_file, 'a') as writer:
            writer.write('***** 最终评估结果 *****\n')
            for key, value in eval_results.items():
                writer.write(f'{key} = {value}\n')
                logger.info(f'  {key} = {value}')
if __name__ == '__main__':
    main()
