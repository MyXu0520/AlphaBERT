from __future__ import annotations
import sys as _sys
from pathlib import Path as _Path
_sys.path.insert(0, str(_Path(__file__).resolve().parents[1]))
from AlphaBERT_runtime import data_path
import os
import sys
import re
import time
import json
import argparse
from collections import Counter, defaultdict
from typing import List, Tuple, Dict, Optional, Set
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import torch
from tqdm import tqdm
from scipy import stats
sns.set(style='whitegrid')
plt.rcParams['pdf.fonttype'] = 42
try:
    import logomaker
except Exception:
    logomaker = None
try:
    from transformers import AutoTokenizer, AutoConfig, AutoModel, BertForMaskedLM, BertForSequenceClassification
    from transformers import DNATokenizer as BertTokenizer
except Exception:
    raise ImportError('transformers library is required.')

def safe_makedirs(path: str):
    try:
        os.makedirs(path, exist_ok=True)
    except Exception as e:
        print(f'[Warn] could not create dir {path}: {e}')

def read_fasta_like_tsv(path: str) -> List[Tuple[int, str, str]]:
    if not os.path.exists(path):
        raise FileNotFoundError(f'DATA_TSV not found: {path}')
    with open(path, 'r') as f:
        first_line = f.readline().strip()
    print(f"文件第一行示例: '{first_line}'")
    df = pd.read_csv(path, sep='\t', header=None, comment='#', quoting=3, dtype=str)
    df = df.fillna('')
    seqs = []
    for idx, row in df.iterrows():
        seq = str(row[0]).strip()
        seq = re.sub('\\s+', '', seq).upper()
        label = str(row[1]).strip() if df.shape[1] > 1 else ''
        if seq and len(seq) > 0:
            seqs.append((int(idx), seq, label))
    print(f'读取了 {len(seqs)} 条序列')
    if len(seqs) > 0:
        print(f'第一条序列长度: {len(seqs[0][1])}, 序列前50个字符: {seqs[0][1][:50]}')
    return seqs

def safe_model_load(model_dir: str, device: torch.device=None):
    if device is None:
        device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    if not os.path.exists(model_dir):
        raise FileNotFoundError(f'Model directory not found: {model_dir}')
    tokenizer = None
    config = None
    try:
        tokenizer = BertTokenizer.from_pretrained(model_dir, do_lower_case=False)
    except Exception as e:
        print(f'[Warn] AutoTokenizer.from_pretrained(..., use_fast=False) failed: {e}')
        try:
            tokenizer = BertTokenizer.from_pretrained(model_dir)
        except Exception as e2:
            print(f'[Warn] BertTokenizer.from_pretrained failed: {e2}')
            try:
                tokenizer = AutoTokenizer.from_pretrained(model_dir)
            except Exception as e3:
                raise RuntimeError(f'Failed to load tokenizer for {model_dir}: {e3}')
    try:
        config = AutoConfig.from_pretrained(model_dir)
        try:
            config.output_attentions = True
        except Exception:
            pass
    except Exception:
        config = None
    model = None
    load_errors = []
    try:
        model = AutoModel.from_pretrained(model_dir, config=config) if config is not None else AutoModel.from_pretrained(model_dir)
    except Exception as e:
        load_errors.append(('AutoModel', str(e)))
        try:
            model = BertForMaskedLM.from_pretrained(model_dir)
        except Exception as e2:
            load_errors.append(('BertForMaskedLM', str(e2)))
            try:
                model = BertForSequenceClassification.from_pretrained(model_dir)
            except Exception as e3:
                load_errors.append(('BertForSequenceClassification', str(e3)))
                try:
                    model = AutoModel.from_pretrained(model_dir)
                except Exception as e4:
                    load_errors.append(('AutoModel_final', str(e4)))
                    raise RuntimeError(f'Failed to load model from {model_dir}. Errors: {load_errors}')
    try:
        model.config.output_attentions = True
    except Exception:
        pass
    model.to(device)
    model.eval()
    return (model, tokenizer)

def extract_attentions_from_outputs(outputs) -> Optional[List[np.ndarray]]:
    attentions = getattr(outputs, 'attentions', None)
    if attentions is None and isinstance(outputs, (tuple, list)):
        for c in outputs[::-1]:
            if isinstance(c, (list, tuple)) and len(c) > 0:
                try:
                    e0 = c[0]
                    if hasattr(e0, 'dim') and e0.dim() == 4:
                        attentions = c
                        break
                except Exception:
                    continue
        if attentions is None and len(outputs) >= 3:
            cand = outputs[2]
            if isinstance(cand, (list, tuple)):
                attentions = cand
    if attentions is None:
        return None
    att_np = []
    for a in attentions:
        if torch.is_tensor(a):
            att_np.append(a.detach().cpu().numpy())
        else:
            att_np.append(np.array(a))
    return att_np

def aggregate_cls_to_token_score(att_np_list: List[np.ndarray], cls_index: int=0) -> Optional[np.ndarray]:
    if not att_np_list:
        return None
    sum_matrix = None
    layer_count = 0
    for a in att_np_list:
        if a.ndim == 4:
            a_layer = a[0]
        elif a.ndim == 3:
            a_layer = a
        else:
            continue
        mean_heads = a_layer.mean(axis=0)
        if sum_matrix is None:
            sum_matrix = mean_heads
        else:
            m = min(sum_matrix.shape[0], mean_heads.shape[0])
            sum_matrix = sum_matrix[:m, :m] + mean_heads[:m, :m]
        layer_count += 1
    if layer_count == 0 or sum_matrix is None:
        return None
    avg_matrix = sum_matrix / float(layer_count)
    seq_len = avg_matrix.shape[0]
    if cls_index >= seq_len:
        cls_index = 0
    scores = avg_matrix[cls_index, :]
    return scores

def clean_token(tok: str) -> str:
    if tok is None:
        return ''
    t = str(tok)
    t = t.replace('##', '').replace('Ġ', '').replace('▁', '')
    return t

def split_into_bases(seq: str) -> List[str]:
    seq = str(seq).upper()
    bases = []
    i = 0
    while i < len(seq):
        if i + 1 < len(seq) and seq[i] == 'M' and (seq[i + 1] == 'L'):
            bases.append('ML')
            i += 2
        else:
            if seq[i] in 'ACGTML':
                bases.append(seq[i])
            i += 1
    return bases

def split_into_bases_with_spans(seq: str) -> List[Tuple[str, int, int]]:
    seq = str(seq).upper()
    out = []
    i = 0
    while i < len(seq):
        if i + 1 < len(seq) and seq[i] == 'M' and (seq[i + 1] == 'L'):
            out.append(('ML', i, 2))
            i += 2
        else:
            if seq[i] in 'ACGTML':
                out.append((seq[i], i, 1))
            i += 1
    return out

def extract_base_kmers(seq: str, k: int) -> List[str]:
    bases = split_into_bases(seq)
    kmers = []
    for i in range(len(bases) - k + 1):
        kmer_bases = bases[i:i + k]
        if len(kmer_bases) == k:
            kmers.append(''.join(kmer_bases))
    return kmers

def map_tokens_to_char_spans(tokens: List[str], raw_seq: str) -> List[Tuple[int, int]]:
    raw = raw_seq.upper()
    cleaned = [clean_token(t).upper() for t in tokens]
    spans = []
    rpos = 0
    for t in cleaned:
        if t == '':
            spans.append((rpos, 0))
            continue
        L = len(t)
        if raw[rpos:rpos + L] == t:
            spans.append((rpos, L))
            rpos += L
            continue
        found = raw.find(t, rpos)
        if found != -1:
            spans.append((found, L))
            rpos = found + L
            continue
        spans.append((rpos, 0))
    return spans

def build_char_score_array_from_tokens(tokens: List[str], token_scores: np.ndarray, raw_seq: str) -> np.ndarray:
    raw = raw_seq.upper()
    char_scores = np.zeros(len(raw), dtype=float)
    spans = map_tokens_to_char_spans(tokens, raw)
    for tok_idx, (start, length) in enumerate(spans):
        if length <= 0:
            continue
        score = float(token_scores[tok_idx]) if tok_idx < len(token_scores) else 0.0
        char_scores[start:start + length] = score
    return char_scores

def compute_kact_by_base_matching(raw_seq: str, char_scores: np.ndarray, kmer: str, k: int) -> Optional[float]:
    base_spans = split_into_bases_with_spans(raw_seq)
    km_bases = split_into_bases(kmer)
    if len(km_bases) != k:
        return np.nan
    occ_scores = []
    for i in range(0, len(base_spans) - k + 1):
        window = base_spans[i:i + k]
        window_bases = [b for b, _, _ in window]
        if window_bases == km_bases:
            chars_idx = []
            for _, start, length in window:
                chars_idx.extend(list(range(start, start + length)))
            if len(chars_idx) == 0:
                continue
            vals = char_scores[chars_idx]
            occ_scores.append(float(np.nanmean(vals)))
    if not occ_scores:
        return np.nan
    return float(np.mean(occ_scores))

def analyze_model_attention_for_sequence(model, tokenizer, sequence: str, kmer_k: int=5, device: torch.device=None, seq_idx: int=0, label: str='') -> Optional[Dict]:
    if device is None:
        device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    try:
        enc = tokenizer.encode_plus(sequence, return_tensors='pt', add_special_tokens=True, max_length=512, truncation=True if len(sequence) > 510 else False)
        enc = {k: v.to(device) for k, v in enc.items()}
        with torch.no_grad():
            outputs = model(**enc)
        att_list = extract_attentions_from_outputs(outputs)
        if att_list is None:
            return None
        token_scores = aggregate_cls_to_token_score(att_list, cls_index=0)
        if token_scores is None:
            return None
        A_all = float(np.nanmean(token_scores))
        A_max = float(np.nanmax(token_scores))
        try:
            input_ids = enc.get('input_ids')[0].detach().cpu().numpy().tolist()
            tokens = tokenizer.convert_ids_to_tokens(input_ids)
        except Exception:
            tokens = [str(t) for t in enc.get('input_ids')[0].detach().cpu().numpy().tolist()]
        token_scores_arr = np.array(token_scores)
        tokens_clean = [clean_token(t) for t in tokens]
        char_scores = build_char_score_array_from_tokens(tokens_clean, token_scores_arr, sequence)
        kmers_in_seq = extract_base_kmers(sequence, kmer_k)
        kmer_results = {}
        for kmer in kmers_in_seq:
            bases = split_into_bases(kmer)
            k = len(bases)
            kact_val = compute_kact_by_base_matching(sequence, char_scores, kmer, k=k)
            positions = []
            base_spans = split_into_bases_with_spans(sequence)
            km_bases = split_into_bases(kmer)
            for i in range(0, len(base_spans) - k + 1):
                window = base_spans[i:i + k]
                window_bases = [b for b, _, _ in window]
                if window_bases == km_bases:
                    chars_idx = []
                    for _, start, length in window:
                        chars_idx.extend(list(range(start, start + length)))
                    if chars_idx:
                        pos_attention = float(np.nanmean(char_scores[chars_idx]))
                    else:
                        pos_attention = np.nan
                    positions.append({'base_position': i, 'char_indices': chars_idx, 'attention': pos_attention})
            kmer_results[kmer] = {'kmer': kmer, 'kmer_length': k, 'contains_ml': 'ML' in kmer, 'attention': float(kact_val) if not pd.isna(kact_val) else np.nan, 'occurrence_count': len(positions), 'positions': positions, 'avg_position_attention': np.nanmean([p['attention'] for p in positions]) if positions else np.nan}
        return {'seq_index': seq_idx, 'sequence': sequence, 'sequence_length': len(sequence), 'ml_count': sequence.count('ML'), 'label': label, 'A_all': A_all, 'A_max': A_max, 'kmer_results': kmer_results}
    except Exception as e:
        print(f'[错误] 序列 {seq_idx} 分析失败: {e}')
        return None

def compare_pretrain_finetune_models(pretrain_model_dir: str, finetune_model_dir: str, data_tsv: str, output_dir: str, kmer_k: int=5, max_seqs: Optional[int]=None, device: torch.device=None, focus_on_ml: bool=True):
    if device is None:
        device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    print(f"{'=' * 60}")
    print('比较预训练和微调模型')
    print(f"{'=' * 60}")
    print(f'预训练模型: {pretrain_model_dir}')
    print(f'微调模型: {finetune_model_dir}')
    print(f'k-mer长度: {kmer_k}')
    print(f'设备: {device}')
    print(f'输出目录: {output_dir}')
    print(f"{'=' * 60}")
    safe_makedirs(output_dir)
    pretrain_dir = os.path.join(output_dir, 'pretrain')
    finetune_dir = os.path.join(output_dir, 'finetune')
    compare_dir = os.path.join(output_dir, 'compare')
    safe_makedirs(pretrain_dir)
    safe_makedirs(finetune_dir)
    safe_makedirs(compare_dir)
    seqs = read_fasta_like_tsv(data_tsv)
    if max_seqs is not None:
        seqs = seqs[:max_seqs]
    print(f'将分析 {len(seqs)} 条序列')
    print('加载预训练模型...')
    pretrain_model, pretrain_tokenizer = safe_model_load(pretrain_model_dir, device=device)
    print('加载微调模型...')
    finetune_model, finetune_tokenizer = safe_model_load(finetune_model_dir, device=device)
    all_pretrain_results = []
    all_finetune_results = []
    all_comparison_results = []
    pbar = tqdm(seqs, desc='分析序列', ncols=80)
    for idx, seq, label in pbar:
        seq_clean = re.sub('\\s+', '', str(seq).strip()).upper()
        if not seq_clean or len(seq_clean) < kmer_k:
            continue
        pretrain_result = analyze_model_attention_for_sequence(model=pretrain_model, tokenizer=pretrain_tokenizer, sequence=seq_clean, kmer_k=kmer_k, device=device, seq_idx=idx, label=label)
        finetune_result = analyze_model_attention_for_sequence(model=finetune_model, tokenizer=finetune_tokenizer, sequence=seq_clean, kmer_k=kmer_k, device=device, seq_idx=idx, label=label)
        if pretrain_result and finetune_result:
            all_pretrain_results.append(pretrain_result)
            all_finetune_results.append(finetune_result)
            comparison = compare_single_sequence_results(pretrain_result=pretrain_result, finetune_result=finetune_result, seq_idx=idx, label=label)
            all_comparison_results.append(comparison)
            if len(all_comparison_results) % 50 == 0:
                save_comparison_intermediate_results(all_comparison_results, compare_dir)
    print('\n保存最终结果...')
    save_comparison_final_results(all_pretrain_results, all_finetune_results, all_comparison_results, pretrain_dir, finetune_dir, compare_dir, focus_on_ml)
    generate_comparison_statistics(all_comparison_results, compare_dir)
    create_comparison_visualizations(all_comparison_results, compare_dir)
    print(f"\n{'=' * 60}")
    print(f'比较分析完成！')
    print(f'预训练模型结果: {pretrain_dir}')
    print(f'微调模型结果: {finetune_dir}')
    print(f'比较结果: {compare_dir}')
    print(f"{'=' * 60}")

def compare_single_sequence_results(pretrain_result: Dict, finetune_result: Dict, seq_idx: int, label: str) -> Dict:
    seq = pretrain_result['sequence']
    pretrain_kmers = set(pretrain_result['kmer_results'].keys())
    finetune_kmers = set(finetune_result['kmer_results'].keys())
    common_kmers = list(pretrain_kmers.intersection(finetune_kmers))
    kmer_comparisons = []
    for kmer in common_kmers:
        pre_att = pretrain_result['kmer_results'][kmer]['attention']
        ft_att = finetune_result['kmer_results'][kmer]['attention']
        if not pd.isna(pre_att) and (not pd.isna(ft_att)):
            att_diff = ft_att - pre_att
            att_ratio = ft_att / pre_att if pre_att != 0 else np.inf
        else:
            att_diff = np.nan
            att_ratio = np.nan
        kmer_comparisons.append({'kmer': kmer, 'contains_ml': 'ML' in kmer, 'pretrain_attention': pre_att, 'finetune_attention': ft_att, 'attention_diff': att_diff, 'attention_ratio': att_ratio, 'pretrain_occurrence': pretrain_result['kmer_results'][kmer]['occurrence_count'], 'finetune_occurrence': finetune_result['kmer_results'][kmer]['occurrence_count']})
    if kmer_comparisons:
        kmer_comparisons_sorted = sorted([k for k in kmer_comparisons if not pd.isna(k['attention_diff'])], key=lambda x: x['attention_diff'], reverse=True)
    else:
        kmer_comparisons_sorted = []
    pre_top_kmers = sorted(pretrain_result['kmer_results'].items(), key=lambda x: x[1]['attention'], reverse=True)[:5]
    ft_top_kmers = sorted(finetune_result['kmer_results'].items(), key=lambda x: x[1]['attention'], reverse=True)[:5]
    pre_top_set = {k for k, _ in pre_top_kmers}
    ft_top_set = {k for k, _ in ft_top_kmers}
    top_overlap = pre_top_set.intersection(ft_top_set)
    pre_ml_kmers = [k for k in pretrain_result['kmer_results'] if 'ML' in k]
    ft_ml_kmers = [k for k in finetune_result['kmer_results'] if 'ML' in k]
    ml_attention_changes = []
    for kmer in set(pre_ml_kmers).intersection(set(ft_ml_kmers)):
        pre_att = pretrain_result['kmer_results'][kmer]['attention']
        ft_att = finetune_result['kmer_results'][kmer]['attention']
        if not pd.isna(pre_att) and (not pd.isna(ft_att)):
            ml_attention_changes.append({'kmer': kmer, 'pretrain_attention': pre_att, 'finetune_attention': ft_att, 'attention_diff': ft_att - pre_att})
    return {'seq_index': seq_idx, 'sequence': seq, 'sequence_length': len(seq), 'ml_count': seq.count('ML'), 'label': label, 'pretrain_A_all': pretrain_result['A_all'], 'pretrain_A_max': pretrain_result['A_max'], 'finetune_A_all': finetune_result['A_all'], 'finetune_A_max': finetune_result['A_max'], 'A_all_diff': finetune_result['A_all'] - pretrain_result['A_all'], 'A_max_diff': finetune_result['A_max'] - pretrain_result['A_max'], 'common_kmers_count': len(common_kmers), 'pretrain_unique_kmers': len(pretrain_kmers - finetune_kmers), 'finetune_unique_kmers': len(finetune_kmers - pretrain_kmers), 'top_overlap_count': len(top_overlap), 'top_overlap_ratio': len(top_overlap) / 5 if pre_top_kmers else 0, 'pretrain_top_5_kmers': [(k, v['attention'], 'ML' in k) for k, v in pre_top_kmers], 'finetune_top_5_kmers': [(k, v['attention'], 'ML' in k) for k, v in ft_top_kmers], 'kmer_comparisons': kmer_comparisons, 'top_10_attention_increase': kmer_comparisons_sorted[:10] if kmer_comparisons_sorted else [], 'top_10_attention_decrease': kmer_comparisons_sorted[-10:] if kmer_comparisons_sorted else [], 'ml_attention_changes': ml_attention_changes, 'ml_attention_avg_diff': np.mean([c['attention_diff'] for c in ml_attention_changes]) if ml_attention_changes else np.nan, 'non_ml_attention_changes': [c for c in kmer_comparisons if not c['contains_ml']], 'non_ml_attention_avg_diff': np.mean([c['attention_diff'] for c in kmer_comparisons if not c['contains_ml'] and (not pd.isna(c['attention_diff']))]) if any((not c['contains_ml'] for c in kmer_comparisons)) else np.nan}

def save_comparison_intermediate_results(comparison_results: List[Dict], compare_dir: str):
    if not comparison_results:
        return
    seq_comparison_data = []
    for comp in comparison_results:
        seq_data = {'seq_index': comp['seq_index'], 'sequence_length': comp['sequence_length'], 'ml_count': comp['ml_count'], 'label': comp['label'], 'pretrain_A_all': comp['pretrain_A_all'], 'finetune_A_all': comp['finetune_A_all'], 'A_all_diff': comp['A_all_diff'], 'pretrain_A_max': comp['pretrain_A_max'], 'finetune_A_max': comp['finetune_A_max'], 'A_max_diff': comp['A_max_diff'], 'common_kmers_count': comp['common_kmers_count'], 'top_overlap_ratio': comp['top_overlap_ratio'], 'ml_attention_avg_diff': comp['ml_attention_avg_diff'], 'non_ml_attention_avg_diff': comp['non_ml_attention_avg_diff']}
        for i, (kmer, att, has_ml) in enumerate(comp['pretrain_top_5_kmers'][:3], 1):
            seq_data[f'pretrain_top_{i}_kmer'] = kmer
            seq_data[f'pretrain_top_{i}_attention'] = att
            seq_data[f'pretrain_top_{i}_has_ml'] = '是' if has_ml else '否'
        for i, (kmer, att, has_ml) in enumerate(comp['finetune_top_5_kmers'][:3], 1):
            seq_data[f'finetune_top_{i}_kmer'] = kmer
            seq_data[f'finetune_top_{i}_attention'] = att
            seq_data[f'finetune_top_{i}_has_ml'] = '是' if has_ml else '否'
        seq_comparison_data.append(seq_data)
    df_seq = pd.DataFrame(seq_comparison_data)
    intermediate_file = os.path.join(compare_dir, f'sequence_comparison_intermediate.csv')
    df_seq.to_csv(intermediate_file, index=False, encoding='utf-8-sig')
    print(f'已保存 {len(comparison_results)} 条序列的比较中间结果')

def save_comparison_final_results(pretrain_results: List[Dict], finetune_results: List[Dict], comparison_results: List[Dict], pretrain_dir: str, finetune_dir: str, compare_dir: str, focus_on_ml: bool):

    def convert_for_json(obj):
        if isinstance(obj, (np.integer, np.int64)):
            return int(obj)
        elif isinstance(obj, (np.floating, np.float64)):
            return float(obj)
        elif isinstance(obj, np.ndarray):
            return obj.tolist()
        elif isinstance(obj, dict):
            return {k: convert_for_json(v) for k, v in obj.items()}
        elif isinstance(obj, list):
            return [convert_for_json(item) for item in obj]
        else:
            return obj
    if pretrain_results:
        pretrain_file = os.path.join(pretrain_dir, 'pretrain_model_results.json')
        with open(pretrain_file, 'w') as f:
            json.dump(convert_for_json(pretrain_results), f, indent=2, ensure_ascii=False)
        print(f'预训练模型结果保存到: {pretrain_file}')
    if finetune_results:
        finetune_file = os.path.join(finetune_dir, 'finetune_model_results.json')
        with open(finetune_file, 'w') as f:
            json.dump(convert_for_json(finetune_results), f, indent=2, ensure_ascii=False)
        print(f'微调模型结果保存到: {finetune_file}')
    if comparison_results:
        comparison_file = os.path.join(compare_dir, 'model_comparison_results.json')
        with open(comparison_file, 'w') as f:
            json.dump(convert_for_json(comparison_results), f, indent=2, ensure_ascii=False)
        print(f'完整比较结果保存到: {comparison_file}')
        seq_summary_data = []
        for comp in comparison_results:
            seq_data = {'seq_index': comp['seq_index'], 'sequence_length': comp['sequence_length'], 'ml_count': comp['ml_count'], 'label': comp['label'], 'pretrain_A_all': comp['pretrain_A_all'], 'finetune_A_all': comp['finetune_A_all'], 'A_all_diff': comp['A_all_diff'], 'pretrain_A_max': comp['pretrain_A_max'], 'finetune_A_max': comp['finetune_A_max'], 'A_max_diff': comp['A_max_diff'], 'common_kmers_count': comp['common_kmers_count'], 'top_overlap_ratio': comp['top_overlap_ratio'], 'ml_attention_avg_diff': comp['ml_attention_avg_diff'], 'non_ml_attention_avg_diff': comp['non_ml_attention_avg_diff']}
            for i, (kmer, att, has_ml) in enumerate(comp['pretrain_top_5_kmers'][:3], 1):
                seq_data[f'pretrain_top_{i}_kmer'] = kmer
                seq_data[f'pretrain_top_{i}_attention'] = f'{att:.6f}'
                seq_data[f'pretrain_top_{i}_has_ml'] = '是' if has_ml else '否'
            for i, (kmer, att, has_ml) in enumerate(comp['finetune_top_5_kmers'][:3], 1):
                seq_data[f'finetune_top_{i}_kmer'] = kmer
                seq_data[f'finetune_top_{i}_attention'] = f'{att:.6f}'
                seq_data[f'finetune_top_{i}_has_ml'] = '是' if has_ml else '否'
            seq_summary_data.append(seq_data)
        df_seq_summary = pd.DataFrame(seq_summary_data)
        seq_summary_file = os.path.join(compare_dir, 'sequence_comparison_summary.csv')
        df_seq_summary.to_csv(seq_summary_file, index=False, encoding='utf-8-sig')
        print(f'序列比较摘要保存到: {seq_summary_file}')
        all_kmer_comparisons = []
        for comp in comparison_results:
            for kmer_comp in comp['kmer_comparisons']:
                if not pd.isna(kmer_comp['attention_diff']):
                    all_kmer_comparisons.append({'seq_index': comp['seq_index'], 'sequence_length': comp['sequence_length'], 'ml_count': comp['ml_count'], 'label': comp['label'], 'kmer': kmer_comp['kmer'], 'contains_ml': kmer_comp['contains_ml'], 'pretrain_attention': kmer_comp['pretrain_attention'], 'finetune_attention': kmer_comp['finetune_attention'], 'attention_diff': kmer_comp['attention_diff'], 'attention_ratio': kmer_comp['attention_ratio'], 'pretrain_occurrence': kmer_comp['pretrain_occurrence'], 'finetune_occurrence': kmer_comp['finetune_occurrence']})
        if all_kmer_comparisons:
            df_kmer_comparisons = pd.DataFrame(all_kmer_comparisons)
            kmer_comparison_file = os.path.join(compare_dir, 'kmer_level_comparison.csv')
            df_kmer_comparisons.to_csv(kmer_comparison_file, index=False, encoding='utf-8-sig')
            print(f'k-mer级别比较保存到: {kmer_comparison_file}')
            kmer_agg_data = []
            for kmer in df_kmer_comparisons['kmer'].unique():
                kmer_data = df_kmer_comparisons[df_kmer_comparisons['kmer'] == kmer]
                ml_flag = 'ML' in kmer
                kmer_agg_data.append({'kmer': kmer, 'contains_ml': '是' if ml_flag else '否', 'appearance_count': len(kmer_data), 'avg_pretrain_attention': kmer_data['pretrain_attention'].mean(), 'avg_finetune_attention': kmer_data['finetune_attention'].mean(), 'avg_attention_diff': kmer_data['attention_diff'].mean(), 'std_attention_diff': kmer_data['attention_diff'].std(), 'max_attention_diff': kmer_data['attention_diff'].max(), 'min_attention_diff': kmer_data['attention_diff'].min(), 't_statistic': stats.ttest_1samp(kmer_data['attention_diff'].dropna(), 0).statistic if len(kmer_data) > 1 else np.nan, 'p_value': stats.ttest_1samp(kmer_data['attention_diff'].dropna(), 0).pvalue if len(kmer_data) > 1 else np.nan})
            df_kmer_agg = pd.DataFrame(kmer_agg_data)
            df_kmer_agg = df_kmer_agg.sort_values('avg_attention_diff', ascending=False)
            kmer_agg_file = os.path.join(compare_dir, 'kmer_aggregated_comparison.csv')
            df_kmer_agg.to_csv(kmer_agg_file, index=False, encoding='utf-8-sig')
            print(f'k-mer聚合比较保存到: {kmer_agg_file}')
        if focus_on_ml:
            ml_changes = []
            for comp in comparison_results:
                for ml_change in comp['ml_attention_changes']:
                    ml_changes.append({'seq_index': comp['seq_index'], 'sequence_length': comp['sequence_length'], 'ml_count': comp['ml_count'], 'label': comp['label'], 'kmer': ml_change['kmer'], 'pretrain_attention': ml_change['pretrain_attention'], 'finetune_attention': ml_change['finetune_attention'], 'attention_diff': ml_change['attention_diff']})
            if ml_changes:
                df_ml_changes = pd.DataFrame(ml_changes)
                ml_changes_file = os.path.join(compare_dir, 'ml_kmer_changes.csv')
                df_ml_changes.to_csv(ml_changes_file, index=False, encoding='utf-8-sig')
                print(f'ML k-mer变化保存到: {ml_changes_file}')

def generate_comparison_statistics(comparison_results: List[Dict], compare_dir: str):
    if not comparison_results:
        print('[警告] 没有比较数据可以生成统计报告')
        return
    A_all_diffs = [comp['A_all_diff'] for comp in comparison_results]
    A_max_diffs = [comp['A_max_diff'] for comp in comparison_results]
    top_overlap_ratios = [comp['top_overlap_ratio'] for comp in comparison_results]
    all_attention_diffs = []
    ml_attention_diffs = []
    non_ml_attention_diffs = []
    for comp in comparison_results:
        for kmer_comp in comp['kmer_comparisons']:
            if not pd.isna(kmer_comp['attention_diff']):
                all_attention_diffs.append(kmer_comp['attention_diff'])
                if kmer_comp['contains_ml']:
                    ml_attention_diffs.append(kmer_comp['attention_diff'])
                else:
                    non_ml_attention_diffs.append(kmer_comp['attention_diff'])
    report_file = os.path.join(compare_dir, 'comparison_statistics_report.txt')
    with open(report_file, 'w', encoding='utf-8') as f:
        f.write(f"{'=' * 60}\n")
        f.write(f'预训练 vs 微调模型比较统计报告\n')
        f.write(f"{'=' * 60}\n\n")
        f.write(f'基本统计:\n')
        f.write(f'  分析序列总数: {len(comparison_results)}\n')
        f.write(f"  包含ML的序列数: {sum((1 for comp in comparison_results if comp['ml_count'] > 0))}\n")
        f.write(f"  平均序列长度: {np.mean([comp['sequence_length'] for comp in comparison_results]):.1f}\n\n")
        f.write(f'总体注意力变化:\n')
        f.write(f'  A_all平均变化: {np.mean(A_all_diffs):.6f}\n')
        f.write(f'  A_all变化范围: [{np.min(A_all_diffs):.6f}, {np.max(A_all_diffs):.6f}]\n')
        f.write(f'  A_max平均变化: {np.mean(A_max_diffs):.6f}\n')
        f.write(f'  A_max变化范围: [{np.min(A_max_diffs):.6f}, {np.max(A_max_diffs):.6f}]\n\n')
        f.write(f'Top k-mer一致性:\n')
        f.write(f'  Top 5 k-mer平均重叠率: {np.mean(top_overlap_ratios) * 100:.1f}%\n')
        f.write(f'  完全相同的序列数: {sum((1 for ratio in top_overlap_ratios if ratio == 1.0))}\n')
        f.write(f'  完全不同的序列数: {sum((1 for ratio in top_overlap_ratios if ratio == 0.0))}\n\n')
        f.write(f'K-mer注意力变化:\n')
        f.write(f'  总k-mer比较次数: {len(all_attention_diffs)}\n')
        f.write(f'  k-mer注意力平均变化: {np.mean(all_attention_diffs):.6f}\n')
        f.write(f'  k-mer注意力变化范围: [{np.min(all_attention_diffs):.6f}, {np.max(all_attention_diffs):.6f}]\n')
        f.write(f'  注意力增加的k-mer比例: {sum((1 for diff in all_attention_diffs if diff > 0)) / len(all_attention_diffs) * 100:.1f}%\n')
        f.write(f'  注意力减少的k-mer比例: {sum((1 for diff in all_attention_diffs if diff < 0)) / len(all_attention_diffs) * 100:.1f}%\n\n')
        f.write(f'ML vs 非ML k-mer变化比较:\n')
        if ml_attention_diffs:
            f.write(f'  ML k-mer数量: {len(ml_attention_diffs)}\n')
            f.write(f'  ML k-mer平均变化: {np.mean(ml_attention_diffs):.6f}\n')
            f.write(f'  ML k-mer变化范围: [{np.min(ml_attention_diffs):.6f}, {np.max(ml_attention_diffs):.6f}]\n')
        if non_ml_attention_diffs:
            f.write(f'  非ML k-mer数量: {len(non_ml_attention_diffs)}\n')
            f.write(f'  非ML k-mer平均变化: {np.mean(non_ml_attention_diffs):.6f}\n')
            f.write(f'  非ML k-mer变化范围: [{np.min(non_ml_attention_diffs):.6f}, {np.max(non_ml_attention_diffs):.6f}]\n')
        if ml_attention_diffs and non_ml_attention_diffs:
            ml_mean = np.mean(ml_attention_diffs)
            non_ml_mean = np.mean(non_ml_attention_diffs)
            f.write(f'\n  ML vs 非ML差异比较:\n')
            f.write(f'    ML k-mer变化均值: {ml_mean:.6f}\n')
            f.write(f'    非ML k-mer变化均值: {non_ml_mean:.6f}\n')
            f.write(f'    差异: {ml_mean - non_ml_mean:.6f}\n')
            try:
                t_stat, p_value = stats.ttest_ind(ml_attention_diffs, non_ml_attention_diffs, equal_var=False)
                f.write(f'    t检验统计量: {t_stat:.4f}\n')
                f.write(f'    p值: {p_value:.6f}\n')
                f.write(f"    显著性: {('显著' if p_value < 0.05 else '不显著')}\n")
            except:
                f.write(f'    t检验: 无法计算\n')
    print(f'比较统计报告保存到: {report_file}')

def create_comparison_visualizations(comparison_results: List[Dict], compare_dir: str):
    try:
        A_all_diffs = [comp['A_all_diff'] for comp in comparison_results]
        A_max_diffs = [comp['A_max_diff'] for comp in comparison_results]
        top_overlap_ratios = [comp['top_overlap_ratio'] for comp in comparison_results]
        all_attention_diffs = []
        ml_attention_diffs = []
        non_ml_attention_diffs = []
        for comp in comparison_results:
            for kmer_comp in comp['kmer_comparisons']:
                if not pd.isna(kmer_comp['attention_diff']):
                    all_attention_diffs.append(kmer_comp['attention_diff'])
                    if kmer_comp['contains_ml']:
                        ml_attention_diffs.append(kmer_comp['attention_diff'])
                    else:
                        non_ml_attention_diffs.append(kmer_comp['attention_diff'])
        fig, axes = plt.subplots(3, 3, figsize=(15, 12))
        axes[0, 0].hist(A_all_diffs, bins=50, alpha=0.7, color='blue')
        axes[0, 0].axvline(x=0, color='red', linestyle='--', linewidth=2)
        axes[0, 0].set_xlabel('A_all差异 (微调 - 预训练)')
        axes[0, 0].set_ylabel('频数')
        axes[0, 0].set_title('A_all差异分布')
        axes[0, 0].grid(True, alpha=0.3)
        axes[0, 1].hist(A_max_diffs, bins=50, alpha=0.7, color='green')
        axes[0, 1].axvline(x=0, color='red', linestyle='--', linewidth=2)
        axes[0, 1].set_xlabel('A_max差异 (微调 - 预训练)')
        axes[0, 1].set_ylabel('频数')
        axes[0, 1].set_title('A_max差异分布')
        axes[0, 1].grid(True, alpha=0.3)
        axes[0, 2].hist(top_overlap_ratios, bins=20, alpha=0.7, color='purple')
        axes[0, 2].set_xlabel('Top 5 k-mer重叠率')
        axes[0, 2].set_ylabel('频数')
        axes[0, 2].set_title('Top k-mer一致性分布')
        axes[0, 2].grid(True, alpha=0.3)
        axes[1, 0].hist(all_attention_diffs, bins=100, alpha=0.7, color='orange', range=(-0.2, 0.2))
        axes[1, 0].axvline(x=0, color='red', linestyle='--', linewidth=2)
        axes[1, 0].set_xlabel('K-mer注意力差异 (微调 - 预训练)')
        axes[1, 0].set_ylabel('频数')
        axes[1, 0].set_title('所有K-mer注意力差异分布')
        axes[1, 0].grid(True, alpha=0.3)
        if ml_attention_diffs and non_ml_attention_diffs:
            axes[1, 1].boxplot([non_ml_attention_diffs, ml_attention_diffs], labels=['非ML k-mer', 'ML k-mer'])
            axes[1, 1].set_ylabel('注意力差异')
            axes[1, 1].set_title('ML vs 非ML k-mer注意力差异')
            axes[1, 1].grid(True, alpha=0.3)
        else:
            axes[1, 1].text(0.5, 0.5, '无ML k-mer数据', ha='center', va='center', transform=axes[1, 1].transAxes)
        seq_lengths = [comp['sequence_length'] for comp in comparison_results]
        axes[1, 2].scatter(seq_lengths, A_all_diffs, alpha=0.5, s=20)
        axes[1, 2].set_xlabel('序列长度')
        axes[1, 2].set_ylabel('A_all差异')
        axes[1, 2].set_title('A_all差异与序列长度的关系')
        axes[1, 2].grid(True, alpha=0.3)
        ml_counts = [comp['ml_count'] for comp in comparison_results]
        ml_avg_diffs = [comp['ml_attention_avg_diff'] for comp in comparison_results]
        valid_indices = [i for i, diff in enumerate(ml_avg_diffs) if not pd.isna(diff)]
        if valid_indices:
            axes[2, 0].scatter([ml_counts[i] for i in valid_indices], [ml_avg_diffs[i] for i in valid_indices], alpha=0.5, s=20)
            axes[2, 0].set_xlabel('序列中ML数量')
            axes[2, 0].set_ylabel('ML k-mer平均差异')
            axes[2, 0].set_title('ML数量与ML k-mer注意力变化的关系')
            axes[2, 0].grid(True, alpha=0.3)
        else:
            axes[2, 0].text(0.5, 0.5, '无ML数据', ha='center', va='center', transform=axes[2, 0].transAxes)
        if all_attention_diffs:
            all_kmer_diffs = []
            for comp in comparison_results:
                for kmer_comp in comp['kmer_comparisons']:
                    if not pd.isna(kmer_comp['attention_diff']):
                        all_kmer_diffs.append({'kmer': kmer_comp['kmer'], 'diff': kmer_comp['attention_diff'], 'contains_ml': kmer_comp['contains_ml']})
            if all_kmer_diffs:
                kmer_diff_dict = defaultdict(list)
                for item in all_kmer_diffs:
                    kmer_diff_dict[item['kmer']].append(item['diff'])
                kmer_avg_diffs = []
                for kmer, diffs in kmer_diff_dict.items():
                    avg_diff = np.mean(diffs)
                    contains_ml = 'ML' in kmer
                    kmer_avg_diffs.append((kmer, avg_diff, contains_ml))
                kmer_avg_diffs.sort(key=lambda x: x[1], reverse=True)
                top_20 = kmer_avg_diffs[:20]
                if top_20:
                    kmers = [k[0] for k in top_20]
                    diffs = [k[1] for k in top_20]
                    colors = ['red' if k[2] else 'blue' for k in top_20]
                    y_pos = range(len(kmers))
                    axes[2, 1].barh(y_pos, diffs, color=colors)
                    axes[2, 1].set_yticks(y_pos)
                    axes[2, 1].set_yticklabels(kmers, fontsize=8)
                    axes[2, 1].set_xlabel('平均注意力差异')
                    axes[2, 1].set_title('注意力增加最多的k-mer (前20)')
                    axes[2, 1].grid(True, alpha=0.3, axis='x')
        if all_kmer_diffs:
            kmer_avg_diffs.sort(key=lambda x: x[1])
            bottom_20 = kmer_avg_diffs[:20]
            if bottom_20:
                kmers = [k[0] for k in bottom_20]
                diffs = [k[1] for k in bottom_20]
                colors = ['red' if k[2] else 'blue' for k in bottom_20]
                y_pos = range(len(kmers))
                axes[2, 2].barh(y_pos, diffs, color=colors)
                axes[2, 2].set_yticks(y_pos)
                axes[2, 2].set_yticklabels(kmers, fontsize=8)
                axes[2, 2].set_xlabel('平均注意力差异')
                axes[2, 2].set_title('注意力减少最多的k-mer (前20)')
                axes[2, 2].grid(True, alpha=0.3, axis='x')
        plt.tight_layout()
        plt.savefig(os.path.join(compare_dir, 'model_comparison_visualization.pdf'), dpi=300)
        plt.close()
        print(f"比较可视化图表保存到: {os.path.join(compare_dir, 'model_comparison_visualization.pdf')}")
    except Exception as e:
        print(f'[警告] 创建比较可视化失败: {e}')
        import traceback
        traceback.print_exc()

def main():
    parser = argparse.ArgumentParser(description='比较预训练和微调模型在每条序列中的k-mer注意力')
    parser.add_argument('--pretrain_model', type=str, default=data_path('preTrain/checkpoint-105000'), help='预训练模型路径')
    parser.add_argument('--finetune_model', type=str, default=data_path('best/fineTune4/best_model'), help='微调模型路径')
    parser.add_argument('--data_tsv', type=str, default=data_path('readTrace/fine_tune_data/new/percent2/dev.tsv'), help='数据文件路径')
    parser.add_argument('--output_dir', type=str, default=data_path('new_explain7'), help='输出目录')
    parser.add_argument('--kmer_k', type=int, default=5, help='k-mer长度')
    parser.add_argument('--max_seqs', type=int, default=None, help='最大序列数')
    parser.add_argument('--device', type=str, choices=['cuda', 'cpu'], help='设备')
    parser.add_argument('--focus_ml', action='store_true', default=True, help='特别关注ML k-mer（默认启用）')
    args = parser.parse_args()
    if args.device:
        device = torch.device(args.device)
    else:
        device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    compare_pretrain_finetune_models(pretrain_model_dir=args.pretrain_model, finetune_model_dir=args.finetune_model, data_tsv=args.data_tsv, output_dir=args.output_dir, kmer_k=args.kmer_k, max_seqs=args.max_seqs, device=device, focus_on_ml=args.focus_ml)
if __name__ == '__main__':
    main()
