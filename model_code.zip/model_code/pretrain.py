import argparse
import math
from pathlib import Path as _Path
import glob
import logging
import os
import pickle
import random
import re
import shutil
from typing import Dict, List, Tuple
from copy import deepcopy
from multiprocessing import Pool
import sys
import traceback
import numpy as np
import torch
from torch.nn.utils.rnn import pad_sequence
from torch.utils.data import DataLoader, Dataset, RandomSampler, SequentialSampler
from torch.utils.data.distributed import DistributedSampler
from tqdm import tqdm, trange
from torch.cuda.amp import autocast, GradScaler
from transformers import WEIGHTS_NAME, AdamW, BertConfig, BertForMaskedLM, BertTokenizer, DNATokenizer, CamembertConfig, CamembertForMaskedLM, CamembertTokenizer, DistilBertConfig, DistilBertForMaskedLM, DistilBertTokenizer, GPT2Config, GPT2LMHeadModel, GPT2Tokenizer, OpenAIGPTConfig, OpenAIGPTLMHeadModel, OpenAIGPTTokenizer, PreTrainedModel, PreTrainedTokenizer, RobertaConfig, RobertaForMaskedLM, RobertaTokenizer, get_linear_schedule_with_warmup
try:
    from torch.utils.tensorboard import SummaryWriter
except ImportError:
    from tensorboardX import SummaryWriter
logging.basicConfig(format='%(asctime)s | %(levelname)s | %(name)s | %(message)s', datefmt='%Y-%m-%d %H:%M:%S', level=os.environ.get('LOGLEVEL', 'INFO').upper(), stream=sys.stdout)
logger = logging.getLogger(__name__)
MODEL_CLASSES = {'gpt2': (GPT2Config, GPT2LMHeadModel, GPT2Tokenizer), 'openai-gpt': (OpenAIGPTConfig, OpenAIGPTLMHeadModel, OpenAIGPTTokenizer), 'dna': (BertConfig, BertForMaskedLM, DNATokenizer), 'bert': (BertConfig, BertForMaskedLM, BertTokenizer), 'roberta': (RobertaConfig, RobertaForMaskedLM, RobertaTokenizer), 'distilbert': (DistilBertConfig, DistilBertForMaskedLM, DistilBertTokenizer), 'camembert': (CamembertConfig, CamembertForMaskedLM, CamembertTokenizer)}
MASK_LIST = {'1': [0], '2': [-1], '3': [-1, 1], '4': [-1, 1, 2], '5': [-2, -1, 1, 2], '6': [-2, -1, 1, 2, 3]}

class Config(object):

    def __init__(self):
        self.model_name_or_path = None
        self.tokenizer_name = 'dna5'
        self.output_dir = ''
        self.output_dir_init = ''
        self.train_data_file = ''
        self.eval_data_file = ''
        self.config_name = './transformers/dnabert-config/bert-config-5/config.json'
        self.model_type = 'dna'
        self.n_process = 1
        self.should_continue = False
        self.cache_dir = None
        self.max_seq_length = 200
        self.line_by_line = True
        self.do_train = True
        self.block_size = 200
        self.do_eval = True
        self.evaluate_during_training = True
        self.n_gpu = 4
        self.per_gpu_train_batch_size = 16
        self.per_gpu_eval_batch_size = 16
        self.gradient_accumulation_steps = 10
        self.learning_rate = 0.0003
        self.weight_decay = 0.01
        self.adam_epsilon = 1e-08
        self.beta1 = 0.9
        self.beta2 = 0.98
        self.max_grad_norm = 1.0
        self.num_train_epochs = 50.0
        self.max_steps = -1
        self.warmup_steps = 1000
        self.warmup_percent = 0.0
        self.mlm = True
        self.mlm_probability = 0.05
        self.logging_steps = 500
        self.save_steps = 500
        self.save_total_limit = 20
        self.eval_all_checkpoints = True
        self.no_cuda = False
        self.overwrite_output_dir = True
        self.overwrite_cache = False
        self.seed = 42
        self.fp16 = True
        self.local_rank = -1
        self.server_ip = ''
        self.server_port = ''

class TextDataset(Dataset):

    def __init__(self, tokenizer: PreTrainedTokenizer, args, file_path: str, block_size=512):
        assert os.path.isfile(file_path)
        block_size = block_size - (tokenizer.max_len - tokenizer.max_len_single_sentence)
        directory, filename = os.path.split(file_path)
        cached_features_file = os.path.join(directory, args.model_type + '_cached_lm_' + str(block_size) + '_' + filename)
        if os.path.exists(cached_features_file) and (not args.overwrite_cache):
            logger.info('Loading features from cached file %s', cached_features_file)
            with open(cached_features_file, 'rb') as handle:
                self.examples = pickle.load(handle)
        else:
            logger.info('Creating features from dataset file at %s', directory)
            self.examples = []
            with open(file_path, encoding='utf-8') as f:
                text = f.read()
            tokenized_text = tokenizer.convert_tokens_to_ids(tokenizer.tokenize(text))
            for i in range(0, len(tokenized_text) - block_size + 1, block_size):
                self.examples.append(tokenizer.build_inputs_with_special_tokens(tokenized_text[i:i + block_size]))
            logger.info('Saving features into cached file %s', cached_features_file)
            with open(cached_features_file, 'wb') as handle:
                pickle.dump(self.examples, handle, protocol=pickle.HIGHEST_PROTOCOL)

    def __len__(self):
        return len(self.examples)

    def __getitem__(self, item):
        return torch.tensor(self.examples[item], dtype=torch.long)

def convert_line_to_example(tokenizer, lines, max_length, add_special_tokens=True):
    examples = tokenizer.batch_encode_plus(lines, add_special_tokens=add_special_tokens, max_length=max_length)['input_ids']
    return examples

class LineByLineTextDataset(Dataset):

    def __init__(self, tokenizer: PreTrainedTokenizer, args, file_path: str, block_size=512):
        assert os.path.isfile(file_path)
        directory, filename = os.path.split(file_path)
        cached_features_file = os.path.join(directory, args.model_type + '_cached_lm_' + str(block_size) + '_' + filename)
        if os.path.exists(cached_features_file) and (not args.overwrite_cache):
            logger.info('Loading features from cached file %s', cached_features_file)
            with open(cached_features_file, 'rb') as handle:
                self.examples = pickle.load(handle)
        else:
            logger.info('Creating features from dataset file at %s', file_path)
            with open(file_path, encoding='utf-8') as f:
                lines = [line for line in f.read().splitlines() if len(line) > 0 and (not line.isspace())]
            if args.n_process == 1:
                self.examples = tokenizer.batch_encode_plus(lines, add_special_tokens=True, max_length=block_size)['input_ids']
            else:
                n_proc = min(args.n_process, max(1, len(lines)))
                p = Pool(n_proc)
                indexes = [0]
                len_slice = int(len(lines) / n_proc)
                for i in range(1, n_proc + 1):
                    if i != n_proc:
                        indexes.append(len_slice * i)
                    else:
                        indexes.append(len(lines))
                results = []
                for i in range(n_proc):
                    results.append(p.apply_async(convert_line_to_example, [tokenizer, lines[indexes[i]:indexes[i + 1]], block_size]))
                    print(str(i) + ' start')
                p.close()
                p.join()
                self.examples = []
                for result in results:
                    ids = result.get()
                    self.examples.extend(ids)
            logger.info('Saving features into cached file %s', cached_features_file)
            with open(cached_features_file, 'wb') as handle:
                pickle.dump(self.examples, handle, protocol=pickle.HIGHEST_PROTOCOL)

    def __len__(self):
        return len(self.examples)

    def __getitem__(self, i):
        return torch.tensor(self.examples[i], dtype=torch.long)

def load_and_cache_examples(args, tokenizer, evaluate=False):
    file_path = args.eval_data_file if evaluate else args.train_data_file
    if args.line_by_line:
        return LineByLineTextDataset(tokenizer, args, file_path=file_path, block_size=args.block_size)
    else:
        return TextDataset(tokenizer, args, file_path=file_path, block_size=args.block_size)

def set_seed(args):
    random.seed(args.seed)
    np.random.seed(args.seed)
    torch.manual_seed(args.seed)
    if args.n_gpu > 0:
        torch.cuda.manual_seed_all(args.seed)

def _sorted_checkpoints(args, checkpoint_prefix='checkpoint', use_mtime=False) -> List[str]:
    ordering_and_checkpoint_path = []
    glob_checkpoints = glob.glob(os.path.join(args.output_dir, '{}-*'.format(checkpoint_prefix)))
    for path in glob_checkpoints:
        if use_mtime:
            ordering_and_checkpoint_path.append((os.path.getmtime(path), path))
        else:
            regex_match = re.match('.*{}-([0-9]+)'.format(checkpoint_prefix), path)
            if regex_match and regex_match.groups():
                ordering_and_checkpoint_path.append((int(regex_match.groups()[0]), path))
    checkpoints_sorted = sorted(ordering_and_checkpoint_path)
    checkpoints_sorted = [checkpoint[1] for checkpoint in checkpoints_sorted]
    return checkpoints_sorted

def _rotate_checkpoints(args, checkpoint_prefix='checkpoint', use_mtime=False) -> None:
    if not args.save_total_limit:
        return
    if args.save_total_limit <= 0:
        return
    checkpoints_sorted = _sorted_checkpoints(args, checkpoint_prefix, use_mtime)
    if len(checkpoints_sorted) <= args.save_total_limit:
        return
    number_of_checkpoints_to_delete = max(0, len(checkpoints_sorted) - args.save_total_limit)
    checkpoints_to_be_deleted = checkpoints_sorted[:number_of_checkpoints_to_delete]
    for checkpoint in checkpoints_to_be_deleted:
        logger.info('Deleting older checkpoint [{}] due to args.save_total_limit'.format(checkpoint))
        shutil.rmtree(checkpoint)

def get_disease_tokens_mask(disease_vocab, squence):
    disease_index = [0] * len(squence)
    for i in range(len(squence)):
        if squence[i] in disease_vocab:
            disease_index[i] = 1
    return disease_index

def mask_tokens(inputs: torch.Tensor, tokenizer: PreTrainedTokenizer, args) -> Tuple[torch.Tensor, torch.Tensor]:
    mask_list = MASK_LIST[tokenizer.kmer]
    if tokenizer.mask_token is None:
        raise ValueError('This tokenizer does not have a mask token which is necessary for masked language modeling. Remove the --mlm flag if you want to use this tokenizer.')
    inputs = inputs.clone()
    labels = inputs.clone()
    probability_matrix = torch.full(labels.shape, args.mlm_probability)
    special_tokens_mask = [tokenizer.get_special_tokens_mask(val, already_has_special_tokens=True) for val in labels.tolist()]
    disease_tokens_mask = [get_disease_tokens_mask(args.disease_vocab, val) for val in labels.tolist()]
    probability_matrix.masked_fill_(torch.tensor(special_tokens_mask, dtype=torch.bool), value=0.0)
    probability_matrix.masked_fill_(torch.tensor(disease_tokens_mask, dtype=torch.bool), value=1.0)
    if tokenizer.pad_token is not None:
        padding_mask = labels.eq(tokenizer.pad_token_id)
        probability_matrix.masked_fill_(padding_mask, value=0.0)
    masked_indices = torch.bernoulli(probability_matrix).bool()
    for row in range(labels.shape[0]):
        eligible = torch.where(probability_matrix[row] > 0)[0]
        if not masked_indices[row].any() and len(eligible):
            masked_indices[row, eligible[torch.randint(len(eligible), (1,)).item()]] = True
    masks = deepcopy(masked_indices)
    for i, masked_index in enumerate(masks):
        non_zero_indices = torch.where(probability_matrix[i] != 0)[0]
        if len(non_zero_indices) > 0:
            end = non_zero_indices.tolist()[-1]
        else:
            end = 0
        mask_centers = set(torch.where(masked_index == 1)[0].tolist())
        new_centers = deepcopy(mask_centers)
        for center in mask_centers:
            for mask_offset in mask_list:
                current_index = center + mask_offset
                if 1 <= current_index <= end:
                    new_centers.add(current_index)
        new_centers_list = list(new_centers)
        masked_indices[i, new_centers_list] = True
    labels[~masked_indices] = -100
    indices_replaced = torch.bernoulli(torch.full(labels.shape, 0.8)).bool() & masked_indices
    inputs[indices_replaced] = tokenizer.convert_tokens_to_ids(tokenizer.mask_token)
    indices_random = torch.bernoulli(torch.full(labels.shape, 0.5)).bool() & masked_indices & ~indices_replaced
    random_words = torch.randint(len(tokenizer), labels.shape, dtype=torch.long)
    inputs[indices_random] = random_words[indices_random]
    return (inputs, labels)

def train(args, train_dataset, model: PreTrainedModel, tokenizer: PreTrainedTokenizer) -> Tuple[int, float]:
    if args.local_rank in [-1, 0]:
        tb_writer = SummaryWriter()
    args.train_batch_size = args.per_gpu_train_batch_size * max(1, args.n_gpu)

    def collate(examples: List[torch.Tensor]):
        if tokenizer._pad_token is None:
            return pad_sequence(examples, batch_first=True)
        return pad_sequence(examples, batch_first=True, padding_value=tokenizer.pad_token_id)
    if len(train_dataset) == 0:
        raise ValueError('训练数据为空')
    train_sampler = RandomSampler(train_dataset) if args.local_rank == -1 else DistributedSampler(train_dataset)
    train_dataloader = DataLoader(train_dataset, sampler=train_sampler, batch_size=args.train_batch_size, collate_fn=collate)
    if args.max_steps > 0:
        t_total = args.max_steps
        args.num_train_epochs = args.max_steps // max(1, math.ceil(len(train_dataloader) / args.gradient_accumulation_steps)) + 1
    else:
        t_total = max(1, math.ceil(len(train_dataloader) / args.gradient_accumulation_steps)) * args.num_train_epochs
    no_decay = ['bias', 'LayerNorm.weight']
    optimizer_grouped_parameters = [{'params': [p for n, p in model.named_parameters() if not any((nd in n for nd in no_decay))], 'weight_decay': args.weight_decay}, {'params': [p for n, p in model.named_parameters() if any((nd in n for nd in no_decay))], 'weight_decay': 0.0}]
    optimizer = AdamW(optimizer_grouped_parameters, lr=args.learning_rate, eps=args.adam_epsilon, betas=(args.beta1, args.beta2))
    scheduler = get_linear_schedule_with_warmup(optimizer, num_warmup_steps=args.warmup_steps, num_training_steps=t_total)
    if not args.resume_from_checkpoint and args.model_name_or_path and os.path.isdir(args.model_name_or_path):
        if os.path.isfile(os.path.join(args.model_name_or_path, 'optimizer.pt')) and os.path.isfile(os.path.join(args.model_name_or_path, 'scheduler.pt')):
            optimizer.load_state_dict(torch.load(os.path.join(args.model_name_or_path, 'optimizer.pt')))
            scheduler.load_state_dict(torch.load(os.path.join(args.model_name_or_path, 'scheduler.pt')))
    scaler = GradScaler(enabled=args.fp16)
    if args.n_gpu > 1:
        model = torch.nn.DataParallel(model)
    if args.local_rank != -1:
        model = torch.nn.parallel.DistributedDataParallel(model, device_ids=[args.local_rank], output_device=args.local_rank, find_unused_parameters=True)
    logger.info('***** Running training *****')
    logger.info('  Num examples = %d', len(train_dataset))
    logger.info('  Num Epochs = %d', args.num_train_epochs)
    logger.info('  Instantaneous batch size per GPU = %d', args.per_gpu_train_batch_size)
    logger.info('  Total train batch size (w. parallel, distributed & accumulation) = %d', args.train_batch_size * args.gradient_accumulation_steps * (torch.distributed.get_world_size() if args.local_rank != -1 else 1))
    logger.info('  Gradient Accumulation steps = %d', args.gradient_accumulation_steps)
    logger.info('  Total optimization steps = %d', t_total)
    tr_loss = 0.0
    logging_loss = 0.0
    global_step = 0
    epochs_trained = 0
    steps_trained_in_current_epoch = 0
    if args.resume_from_checkpoint and os.path.exists(args.resume_from_checkpoint):
        logger.info(f'从检查点恢复训练: {args.resume_from_checkpoint}')
        model_path = os.path.join(args.resume_from_checkpoint, 'pytorch_model.bin')
        if os.path.exists(model_path):
            model_state_dict = torch.load(model_path, map_location=args.device)
            if isinstance(model, torch.nn.DataParallel):
                model.module.load_state_dict(model_state_dict)
            else:
                model.load_state_dict(model_state_dict)
            logger.info(f'模型权重已从 {model_path} 加载')
        else:
            logger.warning(f'在检查点中未找到模型权重: {model_path}')
        optimizer_path = os.path.join(args.resume_from_checkpoint, 'optimizer.pt')
        if os.path.exists(optimizer_path):
            optimizer_state_dict = torch.load(optimizer_path, map_location=args.device)
            optimizer.load_state_dict(optimizer_state_dict)
            logger.info(f'优化器状态已从 {optimizer_path} 加载')
        else:
            logger.warning(f'在检查点中未找到优化器状态: {optimizer_path}')
        scheduler_path = os.path.join(args.resume_from_checkpoint, 'scheduler.pt')
        if os.path.exists(scheduler_path):
            scheduler_state_dict = torch.load(scheduler_path, map_location=args.device)
            scheduler.load_state_dict(scheduler_state_dict)
            logger.info(f'调度器状态已从 {scheduler_path} 加载')
        else:
            logger.warning(f'在检查点中未找到调度器状态: {scheduler_path}')
        tr_loss_path = os.path.join(args.resume_from_checkpoint, 'tr_loss.pt')
        if os.path.exists(tr_loss_path):
            tr_loss = torch.load(tr_loss_path).item()
            logger.info(f'恢复训练损失: {tr_loss}')
        else:
            logger.warning(f'在检查点中未找到训练损失文件: {tr_loss_path}，初始化为0.0')
        checkpoint_name = os.path.basename(args.resume_from_checkpoint)
        if '-' in checkpoint_name:
            global_step = int(checkpoint_name.split('-')[-1])
            epochs_trained = global_step // max(1, math.ceil(len(train_dataloader) / args.gradient_accumulation_steps))
            steps_trained_in_current_epoch = global_step % max(1, math.ceil(len(train_dataloader) / args.gradient_accumulation_steps))
            logger.info(f'从全局步数 {global_step} 恢复训练')
            logger.info(f'已训练轮数: {epochs_trained}')
            logger.info(f'当前轮已训练步数: {steps_trained_in_current_epoch}')
        else:
            global_step = 0
            epochs_trained = 0
            steps_trained_in_current_epoch = 0
            logger.warning('无法从检查点路径中解析全局步数')
    else:
        if args.resume_from_checkpoint:
            logger.warning(f'指定的检查点不存在: {args.resume_from_checkpoint}, 将从零开始训练')
        global_step = 0
        epochs_trained = 0
        steps_trained_in_current_epoch = 0
    model_to_resize = model.module if hasattr(model, 'module') else model
    model_to_resize.resize_token_embeddings(len(tokenizer))
    model.zero_grad()
    train_iterator = trange(epochs_trained, int(args.num_train_epochs), desc='Epoch', disable=args.local_rank not in [-1, 0])
    set_seed(args)
    for epoch in train_iterator:
        epoch_iterator = tqdm(train_dataloader, desc='Iteration', disable=args.local_rank not in [-1, 0])
        for step, batch in enumerate(epoch_iterator):
            if args.max_steps > 0 and global_step >= args.max_steps:
                break
            if steps_trained_in_current_epoch > 0:
                steps_trained_in_current_epoch -= 1
                continue
            inputs, labels = mask_tokens(batch, tokenizer, args) if args.mlm else (batch, batch)
            inputs = inputs.to(args.device)
            labels = labels.to(args.device)
            model.train()
            if step == 0 and global_step == 0 and (not args.resume_from_checkpoint):
                checkpoint_prefix = 'checkpoint'
                output_dir_init = os.path.join(args.output_dir_init, '{}-{}'.format(checkpoint_prefix, global_step))
                os.makedirs(output_dir_init, exist_ok=True)
                model_to_save = model.module if hasattr(model, 'module') else model
                model_to_save.save_pretrained(output_dir_init)
                tokenizer.save_pretrained(output_dir_init)
                torch.save(args, os.path.join(output_dir_init, 'training_args.bin'))
                logger.info('Saving initial model checkpoint to %s', output_dir_init)
                _rotate_checkpoints(args, checkpoint_prefix)
                torch.save(optimizer.state_dict(), os.path.join(output_dir_init, 'optimizer.pt'))
                torch.save(scheduler.state_dict(), os.path.join(output_dir_init, 'scheduler.pt'))
                logger.info('Saving optimizer and scheduler states to %s', output_dir_init)
            with autocast(enabled=args.fp16):
                outputs = model(inputs, attention_mask=inputs.ne(tokenizer.pad_token_id).long(), masked_lm_labels=labels) if args.mlm else model(inputs, labels=labels)
                loss = outputs[0]
                if args.n_gpu > 1:
                    loss = loss.mean()
                if args.gradient_accumulation_steps > 1:
                    loss = loss / min(args.gradient_accumulation_steps, len(train_dataloader) - step // args.gradient_accumulation_steps * args.gradient_accumulation_steps)
            if args.fp16:
                scaler.scale(loss).backward()
            else:
                loss.backward()
            tr_loss += loss.item()
            if (step + 1) % args.gradient_accumulation_steps == 0 or step + 1 == len(train_dataloader):
                if args.fp16:
                    scaler.unscale_(optimizer)
                torch.nn.utils.clip_grad_norm_(model.parameters(), args.max_grad_norm)
                if args.fp16:
                    scaler.step(optimizer)
                    scaler.update()
                else:
                    optimizer.step()
                scheduler.step()
                model.zero_grad()
                global_step += 1
                if args.local_rank in [-1, 0] and args.logging_steps > 0 and (global_step % args.logging_steps == 0):
                    if args.local_rank in [-1, 0] and args.evaluate_during_training:
                        results = evaluate(args, model, tokenizer)
                        for key, value in results.items():
                            tb_writer.add_scalar('eval_{}'.format(key), value, global_step)
                    tb_writer.add_scalar('lr', scheduler.get_last_lr()[0], global_step)
                    tb_writer.add_scalar('loss', (tr_loss - logging_loss) / args.logging_steps, global_step)
                    logging_loss = tr_loss
                if args.local_rank in [-1, 0] and args.save_steps > 0 and (global_step % args.save_steps == 0):
                    checkpoint_prefix = 'checkpoint'
                    output_dir = os.path.join(args.output_dir, '{}-{}'.format(checkpoint_prefix, global_step))
                    os.makedirs(output_dir, exist_ok=True)
                    model_to_save = model.module if hasattr(model, 'module') else model
                    model_to_save.save_pretrained(output_dir)
                    tokenizer.save_pretrained(output_dir)
                    torch.save(args, os.path.join(output_dir, 'training_args.bin'))
                    logger.info('Saving model checkpoint to %s', output_dir)
                    _rotate_checkpoints(args, checkpoint_prefix)
                    torch.save(optimizer.state_dict(), os.path.join(output_dir, 'optimizer.pt'))
                    torch.save(scheduler.state_dict(), os.path.join(output_dir, 'scheduler.pt'))
                    logger.info('Saving optimizer and scheduler states to %s', output_dir)
            if args.max_steps > 0 and global_step >= args.max_steps:
                epoch_iterator.close()
                break
        if args.max_steps > 0 and global_step >= args.max_steps:
            train_iterator.close()
            break
    if args.local_rank in [-1, 0]:
        tb_writer.close()
    return (global_step, tr_loss / max(1, global_step))

def evaluate(args, model: PreTrainedModel, tokenizer: PreTrainedTokenizer, prefix='') -> Dict:
    eval_output_dir = args.output_dir
    eval_dataset = load_and_cache_examples(args, tokenizer, evaluate=True)
    if args.local_rank in [-1, 0]:
        os.makedirs(eval_output_dir, exist_ok=True)
    args.eval_batch_size = args.per_gpu_eval_batch_size * max(1, args.n_gpu)

    def collate(examples: List[torch.Tensor]):
        if tokenizer._pad_token is None:
            return pad_sequence(examples, batch_first=True)
        return pad_sequence(examples, batch_first=True, padding_value=tokenizer.pad_token_id)
    eval_sampler = SequentialSampler(eval_dataset)
    eval_dataloader = DataLoader(eval_dataset, sampler=eval_sampler, batch_size=args.eval_batch_size, collate_fn=collate)
    if args.n_gpu > 1 and (not isinstance(model, torch.nn.DataParallel)):
        model = torch.nn.DataParallel(model)
    logger.info('***** Running evaluation {} *****'.format(prefix))
    logger.info('  Num examples = %d', len(eval_dataset))
    logger.info('  Batch size = %d', args.eval_batch_size)
    eval_loss = 0.0
    nb_eval_steps = 0
    model.eval()
    total_m = 0.0
    correct = 0
    for batch in tqdm(eval_dataloader, desc='Evaluating'):
        inputs, labels = mask_tokens(batch, tokenizer, args) if args.mlm else (batch, batch)
        inputs = inputs.to(args.device)
        labels = labels.to(args.device)
        total_m += (labels != -100).sum().item()
        with torch.no_grad():
            outputs = model(inputs, attention_mask=inputs.ne(tokenizer.pad_token_id).long(), masked_lm_labels=labels) if args.mlm else model(inputs, labels=labels)
            correct += outputs[1].argmax(dim=-1).eq(labels).sum().item()
            lm_loss = outputs[0]
            eval_loss += lm_loss.mean().item()
        nb_eval_steps += 1
    eval_loss = eval_loss / nb_eval_steps
    perplexity = torch.exp(torch.tensor(eval_loss))
    accuracy_m = correct / max(1, total_m)
    result = {'perplexity': perplexity, 'accuracy': accuracy_m}
    output_eval_file = os.path.join(eval_output_dir, prefix, 'eval_results.txt')
    os.makedirs(os.path.dirname(output_eval_file), exist_ok=True)
    with open(output_eval_file, 'a') as writer:
        logger.info('***** Eval results {} *****'.format(prefix))
        for key in sorted(result.keys()):
            logger.info('  %s = %s', key, str(result[key]))
            writer.write('%s = %s\n' % (key, str(result[key])))
    return result

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--local_rank', type=int, default=-1, help='Local rank for distributed training')
    parser.add_argument('--output_dir', type=str, required=True, help='输出目录')
    parser.add_argument('--output_dir_init', type=str, required=True, help='初始化模型输出目录')
    parser.add_argument('--do_train', action='store_true', help='是否执行训练')
    parser.add_argument('--train_data_file', type=str, required=True, help='训练数据文件路径')
    parser.add_argument('--do_eval', action='store_true', help='是否执行评估')
    parser.add_argument('--eval_data_file', type=str, help='评估数据文件路径')
    parser.add_argument('--mlm', action='store_true', help='是否使用掩码语言模型')
    parser.add_argument('--n_gpu', type=int, default=1, help='使用的GPU数量')
    parser.add_argument('--gradient_accumulation_steps', type=int, default=1, help='梯度累积步数')
    parser.add_argument('--per_gpu_train_batch_size', type=int, default=8, help='每个GPU的训练批次大小')
    parser.add_argument('--per_gpu_eval_batch_size', type=int, default=8, help='每个GPU的评估批次大小')
    parser.add_argument('--save_steps', type=int, default=500, help='保存模型的步数间隔')
    parser.add_argument('--save_total_limit', type=int, default=20, help='最大保存的检查点数量')
    parser.add_argument('--max_steps', type=int, default=-1, help='最大训练步数')
    parser.add_argument('--evaluate_during_training', action='store_true', help='是否在训练期间进行评估')
    parser.add_argument('--logging_steps', type=int, default=500, help='日志记录的步数间隔')
    parser.add_argument('--line_by_line', action='store_true', help='是否逐行处理数据')
    parser.add_argument('--learning_rate', type=float, default=5e-05, help='学习率')
    parser.add_argument('--block_size', type=int, default=512, help='输入序列的最大长度')
    parser.add_argument('--adam_epsilon', type=float, default=1e-08, help='Adam优化器的epsilon参数')
    parser.add_argument('--weight_decay', type=float, default=0.0, help='权重衰减系数')
    parser.add_argument('--beta1', type=float, default=0.9, help='Adam的beta1参数')
    parser.add_argument('--beta2', type=float, default=0.999, help='Adam的beta2参数')
    parser.add_argument('--mlm_probability', type=float, default=0.15, help='掩码概率')
    parser.add_argument('--warmup_steps', type=int, default=0, help='预热步数')
    parser.add_argument('--overwrite_output_dir', action='store_true', help='是否覆盖输出目录')
    parser.add_argument('--model_type', type=str, default='dna', help='模型类型')
    parser.add_argument('--tokenizer_name', type=str, default='dna5', help='分词器名称')
    parser.add_argument('--config_name', type=str, default=str(_Path(__file__).resolve().parent / 'transformers/dnabert-config/bert-config-5/config.json'), help='配置文件路径')
    parser.add_argument('--num_train_epochs', type=int, default=50, help='训练轮数')
    parser.add_argument('--fp16', action='store_true', help='是否使用混合精度训练')
    parser.add_argument('--resume_from_checkpoint', type=str, default=None, help='Path to checkpoint directory to resume training')
    parser.add_argument('--n_process', type=int, default=1)
    parser.add_argument('--no_cuda', action='store_true')
    parser.add_argument('--model_name_or_path')
    args_parser = parser.parse_args()
    args = Config()
    if args_parser.n_process < 1 or args_parser.gradient_accumulation_steps < 1:
        parser.error('进程数和梯度累积步数必须为正数')
    if not args_parser.mlm:
        parser.error('DNA 预训练需要 --mlm')
    if not args_parser.output_dir:
        logger.error('输出目录不能为空')
        raise ValueError('输出目录不能为空')
    for key, value in vars(args_parser).items():
        setattr(args, key, value)
        logger.info(f'设置 {key} = {value}')
    if args.resume_from_checkpoint:
        args.should_continue = True
        args.model_name_or_path = args.resume_from_checkpoint
        args.overwrite_output_dir = False
        logger.info(f'设置从检查点恢复训练: {args.resume_from_checkpoint}')
        logger.info(f'覆盖输出目录设置为: {args.overwrite_output_dir}')
    if not os.path.exists(args.output_dir):
        logger.warning(f'输出目录不存在，创建: {args.output_dir}')
        os.makedirs(args.output_dir, exist_ok=True)
        logger.info(f'已创建输出目录: {args.output_dir}')
    if not os.path.exists(args.output_dir_init):
        logger.warning(f'初始化目录不存在，创建: {args.output_dir_init}')
        os.makedirs(args.output_dir_init, exist_ok=True)
        logger.info(f'已创建初始化目录: {args.output_dir_init}')
    if args.local_rank != -1:
        torch.cuda.set_device(args.local_rank)
        torch.distributed.init_process_group(backend='nccl')
    if args.model_type in ['bert', 'roberta', 'distilbert', 'camembert'] and (not args.mlm):
        raise ValueError('BERT and RoBERTa-like models do not have LM heads but masked LM heads. They must be run using the --mlm flag (masked language modeling).')
    if args.eval_data_file is None and args.do_eval:
        raise ValueError('Cannot do evaluation without an evaluation data file. Either supply a file to --eval_data_file or remove the --do_eval argument.')
    if args.should_continue:
        sorted_checkpoints = _sorted_checkpoints(args)
        if len(sorted_checkpoints) == 0:
            if args.resume_from_checkpoint and os.path.exists(args.resume_from_checkpoint):
                logger.info(f'直接使用指定的恢复检查点: {args.resume_from_checkpoint}')
                args.model_name_or_path = args.resume_from_checkpoint
            else:
                raise ValueError('Used --should_continue but no checkpoint was found in --output_dir or --resume_from_checkpoint is invalid.')
        else:
            args.model_name_or_path = sorted_checkpoints[-1]
    if os.path.exists(args.output_dir) and os.listdir(args.output_dir) and args.do_train and (not args.overwrite_output_dir) and (not args.resume_from_checkpoint):
        raise ValueError('Output directory ({}) already exists and is not empty. Use --overwrite_output_dir to overcome.'.format(args.output_dir))
    if args.server_ip and args.server_port:
        import ptvsd
        print('Waiting for debugger attach')
        ptvsd.enable_attach(address=(args.server_ip, args.server_port), redirect_output=True)
        ptvsd.wait_for_attach()
    config_class, model_class, tokenizer_class = MODEL_CLASSES[args.model_type]
    if args.config_name:
        config = config_class.from_pretrained(args.config_name, cache_dir=args.cache_dir)
    elif args.model_name_or_path:
        config = config_class.from_pretrained(args.model_name_or_path, cache_dir=args.cache_dir)
    else:
        config = config_class()
    if args.tokenizer_name:
        tokenizer = tokenizer_class.from_pretrained(args.tokenizer_name, cache_dir=args.cache_dir)
    elif args.model_name_or_path:
        tokenizer = tokenizer_class.from_pretrained(args.model_name_or_path, cache_dir=args.cache_dir)
    else:
        tokenizer = tokenizer_class
    logger.info(f'准备保存词表到: {args.output_dir}')
    if not os.path.exists(args.output_dir):
        logger.warning(f'输出目录不存在，创建: {args.output_dir}')
        os.makedirs(args.output_dir, exist_ok=True)
    try:
        vocab_file_path = os.path.join(args.output_dir, 'vocab.txt')
        logger.info(f'保存词表到文件: {vocab_file_path}')
        tokenizer.save_vocabulary(args.output_dir)
        logger.info('词表保存成功')
        if not os.path.exists(vocab_file_path):
            logger.warning(f'词表文件未创建: {vocab_file_path}')
            raise FileNotFoundError(f'词表文件未创建: {vocab_file_path}')
    except Exception as e:
        logger.error(f'保存词表失败: {str(e)}')
        logger.error(f'输出目录内容: {os.listdir(args.output_dir)}')
        raise RuntimeError('无法保存词表，请检查输出目录权限和空间') from e
    vocab_file = open(os.path.join(args.output_dir, 'vocab.txt'), 'r', encoding='utf8').readlines()
    vocab = list(map(lambda x: x.strip(), vocab_file))
    disease_vocab = []
    for i in vocab:
        if 'M' in i or 'L' in i:
            if i not in ['[CLS]', '[MASK]']:
                disease_vocab.append(vocab.index(i))
    args.disease_vocab = disease_vocab
    logger.info(f'识别到 {len(disease_vocab)} 个疾病相关词汇')
    if args.block_size <= 0:
        args.block_size = tokenizer.max_len
    else:
        args.block_size = min(args.block_size, tokenizer.max_len)
    logger.info('加载训练数据集')
    train_dataset = load_and_cache_examples(args, tokenizer, evaluate=False)
    if args.local_rank == -1 or args.no_cuda:
        device = torch.device('cuda:0' if torch.cuda.is_available() and (not args.no_cuda) else 'cpu')
        args.n_gpu = 0 if args.no_cuda else torch.cuda.device_count()
    else:
        torch.cuda.set_device(args.local_rank)
        device = torch.device('cuda', args.local_rank)
        if not torch.distributed.is_initialized():
            torch.distributed.init_process_group(backend='nccl')
        args.n_gpu = 1
    if args.local_rank != -1:
        args.n_gpu = 1
    args.device = device
    args.fp16 = args.fp16 and device.type == 'cuda'
    logger.warning('Process rank: %s, device: %s, n_gpu: %s, distributed training: %s, 16-bits training: %s', args.local_rank, device, args.n_gpu, bool(args.local_rank != -1), args.fp16)
    set_seed(args)
    if args.local_rank not in [-1, 0]:
        torch.distributed.barrier()
    if args.resume_from_checkpoint and os.path.exists(args.resume_from_checkpoint):
        logger.info(f'直接从检查点加载模型: {args.resume_from_checkpoint}')
        model = model_class.from_pretrained(args.resume_from_checkpoint)
        logger.info(f'从 {args.resume_from_checkpoint} 成功加载模型')
    elif args.model_name_or_path:
        logger.info(f'从预训练模型加载: {args.model_name_or_path}')
        model = model_class.from_pretrained(args.model_name_or_path, from_tf=bool('.ckpt' in args.model_name_or_path), config=config, cache_dir=args.cache_dir)
        logger.info(f'从 {args.model_name_or_path} 成功加载模型')
    else:
        logger.info('从头开始训练新模型')
        model = model_class(config=config)
    model.to(args.device)
    if args.local_rank == 0:
        torch.distributed.barrier()
    logger.info('Training/evaluation parameters %s', args)
    if args.do_train:
        if args.local_rank not in [-1, 0]:
            torch.distributed.barrier()
        if args.local_rank == 0:
            torch.distributed.barrier()
        logger.info('开始训练过程')
        try:
            global_step, tr_loss = train(args, train_dataset, model, tokenizer)
            logger.info('训练完成，global_step = %s, average loss = %s', global_step, tr_loss)
        except Exception as e:
            logger.error(f'训练过程中出错: {str(e)}')
            traceback.print_exc()
            raise
    if args.do_train and (args.local_rank == -1 or torch.distributed.get_rank() == 0):
        if args.local_rank in [-1, 0]:
            os.makedirs(args.output_dir, exist_ok=True)
        logger.info('将最终模型保存到 %s', args.output_dir)
        model_to_save = model.module if hasattr(model, 'module') else model
        model_to_save.save_pretrained(args.output_dir)
        tokenizer.save_pretrained(args.output_dir)
        torch.save(args, os.path.join(args.output_dir, 'training_args.bin'))
        logger.info('加载最终模型以进行评估')
        model = model_class.from_pretrained(args.output_dir)
        tokenizer = tokenizer_class.from_pretrained(args.output_dir)
        model.to(args.device)
    results = {}
    if args.do_eval and args.local_rank in [-1, 0]:
        checkpoints = [args.output_dir]
        if args.eval_all_checkpoints:
            checkpoints = list((os.path.dirname(c) for c in sorted(glob.glob(args.output_dir + '/**/' + WEIGHTS_NAME, recursive=True))))
            logging.getLogger('transformers.modeling_utils').setLevel(logging.WARN)
        logger.info('评估以下检查点: %s', checkpoints)
        for checkpoint in checkpoints:
            global_step = checkpoint.split('-')[-1] if len(checkpoints) > 1 else ''
            prefix = checkpoint.split('/')[-1] if checkpoint.find('checkpoint') != -1 else ''
            model = model_class.from_pretrained(checkpoint)
            model.to(args.device)
            result = evaluate(args, model, tokenizer, prefix=prefix)
            result = dict(((k + '_{}'.format(global_step), v) for k, v in result.items()))
            results.update(result)
    return results
if __name__ == '__main__':
    main()
