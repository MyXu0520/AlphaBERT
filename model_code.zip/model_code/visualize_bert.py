import sys as _sys
from pathlib import Path as _Path
_sys.path.insert(0, str(_Path(__file__).resolve().parents[1]))
from AlphaBERT_runtime import data_path
import os
import re
import numpy as np
import pandas as pd
import torch
import matplotlib.pyplot as plt
from tqdm import tqdm
from transformers import BertConfig, BertForSequenceClassification, DNATokenizer, BertModel
import seaborn as sns
from matplotlib.colors import LinearSegmentedColormap
import logging
import json
import plotly.express as px
import plotly.graph_objects as go
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)
dna_cmap = LinearSegmentedColormap.from_list('dna', ['#FF3333', '#33FF33', '#3333FF', '#FFFF33'])

def load_model_and_tokenizer(model_path, config_path=None):
    logger.info(f'加载模型和tokenizer: {model_path}')
    if not os.path.exists(model_path):
        logger.error(f'模型路径不存在: {model_path}')
        return (None, None, None, None)
    try:
        tokenizer = DNATokenizer.from_pretrained(model_path)
        logger.info(f'成功加载tokenizer')
    except Exception as e:
        logger.error(f'加载tokenizer失败: {e}')
        return (None, None, None, None)
    if config_path and os.path.exists(config_path):
        logger.info(f'使用自定义配置: {config_path}')
        try:
            config = BertConfig.from_pretrained(config_path)
        except Exception as e:
            logger.error(f'加载配置失败: {e}')
            return (None, None, None, None)
    else:
        logger.info('使用模型目录中的默认配置')
        try:
            config = BertConfig.from_pretrained(model_path)
        except Exception as e:
            logger.error(f'加载配置失败: {e}')
            return (None, None, None, None)
    logger.info(f'配置信息:')
    for attr in ['hidden_size', 'num_hidden_layers', 'num_attention_heads', 'intermediate_size', 'hidden_act', 'hidden_dropout_prob', 'attention_probs_dropout_prob', 'max_position_embeddings', 'type_vocab_size', 'initializer_range', 'layer_norm_eps', 'pad_token_id']:
        logger.info(f"  {attr}: {getattr(config, attr, '<未定义>')}")
    logger.info(f"  position_embedding_type: {getattr(config, 'position_embedding_type', '<未定义>')}")
    try:
        model = BertForSequenceClassification.from_pretrained(model_path, config=config)
        logger.info('成功加载分类模型')
    except Exception as e:
        logger.error(f'加载分类模型失败: {e}')
        return (None, None, None, None)
    config.output_attentions = True
    try:
        attention_model = BertModel.from_pretrained(model_path, config=config)
        logger.info('成功加载注意力模型')
    except Exception as e:
        logger.error(f'加载注意力模型失败: {e}')
        return (None, None, None, None)
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    logger.info(f'使用设备: {device}')
    model.to(device)
    attention_model.to(device)
    return (model, attention_model, tokenizer, device)

def process_data(data_path, tokenizer, max_length=300):
    logger.info(f'处理数据: {data_path}')
    if not os.path.exists(data_path):
        logger.error(f'数据文件不存在: {data_path}')
        return (None, None, None)
    try:
        df = pd.read_csv(data_path, sep='\t', header=None, names=['sequence', 'label'])
        logger.info(f'成功读取数据文件，样本数: {len(df)}')
    except Exception as e:
        logger.error(f'读取数据文件失败: {e}')
        return (None, None, None)
    sequences = df['sequence'].tolist()
    labels = df['label'].tolist()
    num_positive = sum(labels)
    num_negative = len(labels) - num_positive
    logger.info(f'阳性样本数: {num_positive} ({num_positive / len(labels):.2%})')
    logger.info(f'阴性样本数: {num_negative} ({num_negative / len(labels):.2%})')
    return (sequences, labels, df)

def predict_and_save_scores(model, tokenizer, sequences, labels, device, output_file, batch_size=32):
    if not model or not tokenizer:
        logger.error('模型或tokenizer未初始化')
        return None
    model.eval()
    logger.info(f'预测所有样本并保存得分到: {output_file}')
    predictions = []
    try:
        for i in tqdm(range(0, len(sequences), batch_size), desc='预测样本'):
            batch_sequences = sequences[i:i + batch_size]
            inputs = tokenizer.batch_encode_plus(batch_sequences, max_length=300, padding='max_length', truncation=True, return_tensors='pt')
            input_ids = inputs['input_ids'].to(device)
            attention_mask = inputs['attention_mask'].to(device)
            with torch.no_grad():
                outputs = model(input_ids, attention_mask=attention_mask)
                logits = outputs.logits if hasattr(outputs, 'logits') else outputs[0]
                probs = torch.softmax(logits, dim=-1).cpu().numpy()
                for j in range(len(batch_sequences)):
                    predictions.append({'sequence': batch_sequences[j], 'true_label': labels[i + j] if labels else None, 'prob_0': probs[j][0], 'prob_1': probs[j][1], 'predicted_label': 1 if probs[j][1] > 0.5 else 0})
        pred_df = pd.DataFrame(predictions)
        os.makedirs(os.path.dirname(output_file), exist_ok=True)
        pred_df.to_csv(output_file, sep='\t', index=False)
        logger.info(f'成功保存 {len(predictions)} 个样本的预测结果')
        return pred_df
    except Exception as e:
        logger.error(f'预测过程中出错: {e}')
        return None

def save_attention_scores(attention_scores, tokens, sample_idx, output_dir='attention_scores'):
    try:
        os.makedirs(output_dir, exist_ok=True)
        output_file = os.path.join(output_dir, f'attention_scores_{sample_idx}.csv')
        df = pd.DataFrame({'position': range(len(attention_scores)), 'token': tokens, 'attention_score': attention_scores})
        df.to_csv(output_file, index=False)
        logger.info(f'保存样本 {sample_idx} 的注意力得分到: {output_file}')
    except Exception as e:
        logger.error(f'保存注意力得分失败: {e}')

def predict_high_confidence_samples(model, tokenizer, sequences, labels, device, threshold=0.9, batch_size=32):
    if not model or not tokenizer:
        logger.error('模型或tokenizer未初始化')
        return ([], [])
    model.eval()
    logger.info(f'预测高置信度样本 (阈值={threshold})')
    all_probs = []
    high_confidence_samples = []
    try:
        for i in tqdm(range(0, len(sequences), batch_size), desc='预测样本'):
            batch_sequences = sequences[i:i + batch_size]
            batch_labels = labels[i:i + batch_size] if labels else [None] * len(batch_sequences)
            inputs = tokenizer.batch_encode_plus(batch_sequences, max_length=300, padding='max_length', truncation=True, return_tensors='pt')
            input_ids = inputs['input_ids'].to(device)
            attention_mask = inputs['attention_mask'].to(device)
            with torch.no_grad():
                outputs = model(input_ids, attention_mask=attention_mask)
                logits = outputs.logits if hasattr(outputs, 'logits') else outputs[0]
                probs = torch.softmax(logits, dim=-1).cpu().numpy()
                all_probs.extend(probs[:, 1])
                for j, prob in enumerate(probs[:, 1]):
                    if prob > threshold and (labels is None or batch_labels[j] == 1):
                        high_confidence_samples.append({'index': i + j, 'sequence': batch_sequences[j], 'label': batch_labels[j] if labels else None, 'prob': prob, 'input_ids': input_ids[j].cpu().clone(), 'attention_mask': attention_mask[j].cpu().clone()})
        logger.info(f'发现 {len(high_confidence_samples)} 个高置信度样本 (概率 > {threshold})')
        return (high_confidence_samples, all_probs)
    except Exception as e:
        logger.error(f'预测过程中出错: {e}')
        return ([], [])

def visualize_attention(attention_model, tokenizer, sample, device, sample_idx, output_dir='attention_plots'):
    if not attention_model or not tokenizer:
        logger.error('注意力模型或tokenizer未初始化')
        return (None, None)
    input_ids = sample['input_ids'].unsqueeze(0).to(device)
    attention_mask = sample['attention_mask'].unsqueeze(0).to(device)
    try:
        with torch.no_grad():
            outputs = attention_model(input_ids, attention_mask=attention_mask)
            if hasattr(outputs, 'attentions'):
                attentions = outputs.attentions
            elif isinstance(outputs, tuple) and len(outputs) > 1:
                attentions = outputs[-1]
            else:
                logger.error('无法获取注意力权重')
                return (None, None)
            tokens = tokenizer.convert_ids_to_tokens(input_ids[0].cpu().numpy())
        os.makedirs(output_dir, exist_ok=True)
        for layer_idx in range(len(attentions)):
            for head_idx in range(attentions[layer_idx].shape[1]):
                attention_matrix = attentions[layer_idx][0, head_idx].cpu().numpy()
                plt.figure(figsize=(16, 14))
                sns.heatmap(attention_matrix, cmap='viridis', linewidths=0.5)
                token_labels = []
                positions_to_label = set()
                for i, token in enumerate(tokens):
                    if token in ['[CLS]', '[SEP]', '[PAD]'] or '##' not in token:
                        token_labels.append(token)
                        positions_to_label.add(i)
                    else:
                        token_labels.append('')
                ax = plt.gca()
                ax.set_xticks(list(positions_to_label))
                ax.set_xticklabels([token_labels[i] for i in positions_to_label], rotation=45, ha='right', fontsize=8)
                ax.set_yticks(list(positions_to_label))
                ax.set_yticklabels([token_labels[i] for i in positions_to_label], rotation=0, fontsize=8)
                plt.title(f'Attention Heatmap - Sample {sample_idx}\nLayer {layer_idx + 1}/{len(attentions)} Head {head_idx + 1}')
                plt.xlabel('Key Position')
                plt.ylabel('Query Position')
                plt.tight_layout()
                plot_path = os.path.join(output_dir, f'sample_{sample_idx}_layer_{layer_idx}_head_{head_idx}.pdf')
                plt.savefig(plot_path, bbox_inches='tight')
                plt.close()
                logger.debug(f'保存注意力图: {plot_path}')
        return (attention_matrix, tokens)
    except Exception as e:
        logger.error(f'可视化注意力失败: {e}')
        return (None, None)

def extract_attention_activations(attention_model, tokenizer, sample, device):
    if not attention_model or not tokenizer:
        logger.error('注意力模型或tokenizer未初始化')
        return (None, None)
    input_ids = sample['input_ids'].unsqueeze(0).to(device)
    attention_mask = sample['attention_mask'].unsqueeze(0).to(device)
    try:
        with torch.no_grad():
            outputs = attention_model(input_ids, attention_mask=attention_mask)
            if hasattr(outputs, 'attentions'):
                attentions = outputs.attentions
            elif isinstance(outputs, tuple) and len(outputs) > 1:
                attentions = outputs[-1]
            else:
                logger.error('无法获取注意力权重')
                return (None, None)
            last_layer_attentions = attentions[-1].squeeze(0).cpu().numpy()
            attention_weights = last_layer_attentions.mean(axis=0)
            position_importance = attention_weights.mean(axis=1)
        tokens = tokenizer.convert_ids_to_tokens(input_ids[0].cpu().numpy())
        max_attention_positions = np.argsort(position_importance)[::-1][:10]
        motifs = []
        for pos in max_attention_positions:
            attention_value = position_importance[pos]
            start = max(0, pos - 5)
            end = min(len(tokens), pos + 6)
            window_tokens = tokens[start:end]
            window_attention = attention_weights[start:end, start:end]
            motif_matrix = np.zeros((4, len(window_tokens)))
            for i, token in enumerate(window_tokens):
                if token == '[PAD]':
                    continue
                base = token[-1]
                if base == 'M':
                    motif_matrix[1, i] = 1.0
                elif base == 'L':
                    motif_matrix[2, i] = 1.0
                elif base in ['A', 'C', 'G', 'T']:
                    base_idx = {'A': 0, 'C': 1, 'G': 2, 'T': 3}[base]
                    motif_matrix[base_idx, i] = 1.0
            for i in range(len(window_tokens)):
                motif_matrix[:, i] *= window_attention[i].mean()
            col_sums = motif_matrix.sum(axis=0)
            col_sums[col_sums == 0] = 1
            motif_matrix = motif_matrix / col_sums
            motifs.append({'position': pos, 'attention': attention_value, 'tokens': window_tokens, 'matrix': motif_matrix, 'start': start, 'end': end})
        return (motifs, position_importance.tolist())
    except Exception as e:
        logger.error(f'提取注意力激活失败: {e}')
        return (None, None)

def visualize_motifs(motifs, sample_idx, output_dir='motif_plots'):
    os.makedirs(output_dir, exist_ok=True)
    try:
        for i, motif in enumerate(motifs):
            plt.figure(figsize=(10, 3))
            sns.heatmap(motif['matrix'], cmap=dna_cmap, yticklabels=['A', 'C', 'G', 'T'], xticklabels=motif['tokens'], linewidths=0.5)
            plt.title(f"Motif - Sample {sample_idx}\nPosition {motif['position']} (Attention: {motif['attention']:.4f})")
            plt.xlabel('Sequence Position')
            plt.ylabel('Base')
            plot_path = os.path.join(output_dir, f'sample_{sample_idx}_motif_{i}.pdf')
            plt.savefig(plot_path, bbox_inches='tight')
            plt.close()
            logger.debug(f'保存Motif图: {plot_path}')
    except Exception as e:
        logger.error(f'可视化motifs失败: {e}')

def create_bubble_heatmap(attention_data, tokens, sample_idx, output_dir='bubble_heatmaps', interactive=False):
    os.makedirs(output_dir, exist_ok=True)
    try:
        position_importance = attention_data.mean(axis=1)
        if interactive:
            fig = go.Figure()
            for i in range(len(tokens)):
                if tokens[i] in ['[CLS]', '[SEP]', '[PAD]']:
                    continue
                fig.add_trace(go.Scatter(x=[i] * len(tokens), y=list(range(len(tokens))), mode='markers', marker=dict(size=attention_data[i] * 100, color=attention_data[i], colorscale='Viridis', showscale=True, colorbar=dict(title='Attention Weight')), text=[f'Query: {tokens[i]}<br>Key: {tokens[j]}<br>Attention: {attention_data[i, j]:.4f}' for j in range(len(tokens))], hoverinfo='text', name=tokens[i]))
            fig.update_layout(title=f'Interactive Attention Bubble Heatmap - Sample {sample_idx}', xaxis_title='Query Position', yaxis_title='Key Position', showlegend=False)
            plot_path = os.path.join(output_dir, f'sample_{sample_idx}_interactive_bubble.html')
            fig.write_html(plot_path)
            logger.info(f'保存交互式气泡热图: {plot_path}')
        else:
            plt.figure(figsize=(12, 10))
            x_positions, y_positions = np.meshgrid(range(len(tokens)), range(len(tokens)))
            x_flat = x_positions.flatten()
            y_flat = y_positions.flatten()
            size_flat = attention_data.flatten() * 100
            color_flat = attention_data.flatten()
            scatter = plt.scatter(x_flat, y_flat, s=size_flat, c=color_flat, cmap='viridis', alpha=0.6, edgecolors='none')
            plt.colorbar(scatter, label='Attention Weight')
            plt.xlabel('Query Position')
            plt.ylabel('Key Position')
            plt.title(f'Attention Bubble Heatmap - Sample {sample_idx}')
            significant_positions = [i for i, token in enumerate(tokens) if token not in ['[CLS]', '[SEP]', '[PAD]']]
            plt.xticks(significant_positions, [tokens[i] for i in significant_positions], rotation=45)
            plt.yticks(significant_positions, [tokens[i] for i in significant_positions])
            plt.tight_layout()
            plot_path = os.path.join(output_dir, f'sample_{sample_idx}_static_bubble.pdf')
            plt.savefig(plot_path, bbox_inches='tight')
            plt.close()
            logger.info(f'保存静态气泡热图: {plot_path}')
    except Exception as e:
        logger.error(f'创建气泡热图失败: {e}')

def create_position_bubble_chart(position_importance, tokens, sample_idx, output_dir='position_bubble_charts'):
    os.makedirs(output_dir, exist_ok=True)
    try:
        valid_indices = [i for i, token in enumerate(tokens) if token not in ['[CLS]', '[SEP]', '[PAD]']]
        valid_tokens = [tokens[i] for i in valid_indices]
        valid_importance = [position_importance[i] for i in valid_indices]
        plt.figure(figsize=(14, 6))
        scatter = plt.scatter(range(len(valid_tokens)), [1] * len(valid_tokens), s=np.array(valid_importance) * 1000, c=valid_importance, cmap='Reds', alpha=0.7, edgecolors='black', linewidth=0.5)
        plt.colorbar(scatter, label='Attention Importance')
        plt.xlabel('Sequence Position')
        plt.ylabel('')
        plt.title(f'Position Attention Importance - Sample {sample_idx}')
        plt.xticks(range(len(valid_tokens)), valid_tokens, rotation=45, ha='right')
        plt.yticks([])
        plt.grid(axis='x', linestyle='--', alpha=0.3)
        plt.tight_layout()
        plot_path = os.path.join(output_dir, f'sample_{sample_idx}_position_bubble.pdf')
        plt.savefig(plot_path, bbox_inches='tight')
        plt.close()
        logger.info(f'保存位置气泡图: {plot_path}')
    except Exception as e:
        logger.error(f'创建位置气泡图失败: {e}')

def save_motifs_to_meme(motifs, sample_idx, filename='motifs.meme'):
    try:
        with open(filename, 'a') as f:
            for i, motif in enumerate(motifs):
                f.write(f"\n\nMOTIF sample_{sample_idx}_pos_{motif['position']}\n")
                f.write(f"letter-probability matrix: alength=4 w={len(motif['tokens'])} nsites=1 E=0\n")
                for col in range(motif['matrix'].shape[1]):
                    probs = ' '.join([f"{motif['matrix'][j, col]:.6f}" for j in range(4)])
                    f.write(f'{probs}\n')
    except Exception as e:
        logger.error(f'保存motif到MEME文件失败: {e}')

def save_motifs_to_json(motifs, filename='motifs.json'):
    try:
        serializable_motifs = []
        for motif in motifs:
            serializable_motif = {'position': int(motif['position']), 'attention': float(motif['attention']), 'tokens': motif['tokens'], 'matrix': motif['matrix'].tolist(), 'start': int(motif['start']), 'end': int(motif['end'])}
            serializable_motifs.append(serializable_motif)
        with open(filename, 'w') as f:
            json.dump(serializable_motifs, f, indent=2)
        logger.info(f'保存motifs到JSON文件: {filename}')
    except Exception as e:
        logger.error(f'保存motifs到JSON文件失败: {e}')

def main():
    import argparse
    parser = argparse.ArgumentParser(description='AlphaBERT 注意力和 motif 可视化')
    parser.add_argument('--model', required=True)
    parser.add_argument('--data', required=True)
    parser.add_argument('--output', required=True)
    parser.add_argument('--confidence', type=float, default=0.9)
    parser.add_argument('--max-length', type=int, default=200)
    args = parser.parse_args()
    model_path = args.model
    config_path = None
    data_path = args.data
    confidence_threshold = args.confidence
    max_length = args.max_length
    output_base = args.output
    attention_output_dir = os.path.join(output_base, 'attention_plots')
    motif_output_dir = os.path.join(output_base, 'motif_plots')
    scores_output_dir = os.path.join(output_base, 'scores')
    attention_scores_dir = os.path.join(output_base, 'attention_scores')
    bubble_heatmap_dir = os.path.join(output_base, 'bubble_heatmaps')
    position_bubble_dir = os.path.join(output_base, 'position_bubble_charts')
    meme_file = os.path.join(output_base, 'motifs.meme')
    json_motif_file = os.path.join(output_base, 'motifs.json')
    os.makedirs(output_base, exist_ok=True)
    logger.info('验证路径...')
    if not os.path.exists(model_path):
        logger.error(f'模型路径不存在: {model_path}')
        return
    if config_path and (not os.path.exists(config_path)):
        logger.warning(f'配置路径不存在: {config_path}, 将使用模型内置配置')
        config_path = None
    if not os.path.exists(data_path):
        logger.error(f'数据路径不存在: {data_path}')
        return
    os.makedirs(attention_output_dir, exist_ok=True)
    os.makedirs(motif_output_dir, exist_ok=True)
    os.makedirs(scores_output_dir, exist_ok=True)
    os.makedirs(attention_scores_dir, exist_ok=True)
    os.makedirs(bubble_heatmap_dir, exist_ok=True)
    os.makedirs(position_bubble_dir, exist_ok=True)
    model, attention_model, tokenizer, device = load_model_and_tokenizer(model_path, config_path=config_path)
    if model is None or attention_model is None or tokenizer is None:
        logger.error('模型加载失败，无法继续')
        return
    sequences, labels, df = process_data(data_path, tokenizer, max_length)
    if sequences is None or labels is None:
        logger.error('数据处理失败，无法继续')
        return
    score_file = os.path.join(scores_output_dir, 'prediction_scores.tsv')
    pred_df = predict_and_save_scores(model, tokenizer, sequences, labels, device, score_file)
    high_confidence_samples, _ = predict_high_confidence_samples(model, tokenizer, sequences, labels, device, confidence_threshold)
    if not high_confidence_samples:
        logger.error('未找到高置信度样本! 尝试降低阈值')
        return
    num_samples = len(high_confidence_samples)
    logger.info(f'开始可视化 {num_samples} 个高置信度样本...')
    try:
        with open(meme_file, 'w') as f:
            f.write('MEME version 4\n\n')
            f.write('ALPHABET= ACGT\n\n')
            f.write('strands: + -\n\n')
            f.write('Background letter frequencies\n')
            f.write('A 0.25 C 0.25 G 0.25 T 0.25\n')
    except Exception as e:
        logger.error(f'创建MEME文件失败: {e}')
        return
    all_motifs = []
    for i, sample in enumerate(tqdm(high_confidence_samples, desc='处理样本')):
        sample_idx = sample['index']
        logger.info(f'\n处理样本 {i + 1}/{num_samples} (索引: {sample_idx})')
        logger.info(f"序列长度: {len(sample['sequence'])}")
        logger.info(f"预测概率: {sample['prob']:.4f}")
        if sample['label'] is not None:
            logger.info(f"真实标签: {sample['label']}")
        attention_matrix, tokens = visualize_attention(attention_model, tokenizer, sample, device, sample_idx, attention_output_dir)
        if tokens is not None and attention_matrix is not None:
            save_attention_scores(attention_matrix.mean(axis=1), tokens, sample_idx, attention_scores_dir)
            create_bubble_heatmap(attention_matrix, tokens, sample_idx, bubble_heatmap_dir, interactive=False)
            create_bubble_heatmap(attention_matrix, tokens, sample_idx, bubble_heatmap_dir, interactive=True)
            position_importance = attention_matrix.mean(axis=1)
            create_position_bubble_chart(position_importance, tokens, sample_idx, position_bubble_dir)
        motifs, position_importance = extract_attention_activations(attention_model, tokenizer, sample, device)
        if motifs:
            if tokens is not None and position_importance is not None:
                save_attention_scores(position_importance, tokens, sample_idx, attention_scores_dir)
            visualize_motifs(motifs, sample_idx, motif_output_dir)
            save_motifs_to_meme(motifs, sample_idx, meme_file)
            all_motifs.extend(motifs)
            logger.info(f'为样本 {sample_idx} 生成 {len(motifs)} 个motifs')
        else:
            logger.warning(f'无法为样本 {sample_idx} 提取motifs')
    if all_motifs:
        save_motifs_to_json(all_motifs, json_motif_file)
    logger.info('\n处理完成!')
    logger.info(f'注意力图保存在: {attention_output_dir}')
    logger.info(f'Motif图保存在: {motif_output_dir}')
    logger.info(f'预测得分保存在: {score_file}')
    logger.info(f'注意力得分保存在: {attention_scores_dir}')
    logger.info(f'气泡热图保存在: {bubble_heatmap_dir}')
    logger.info(f'位置气泡图保存在: {position_bubble_dir}')
    logger.info(f'所有motifs保存在: {meme_file} 和 {json_motif_file}')
if __name__ == '__main__':
    main()
