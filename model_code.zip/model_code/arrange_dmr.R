#!/usr/bin/env Rscript




library(DSS)
library(bsseq)
library(GenomicRanges)
library(annotatr)
library(clusterProfiler)
library(org.Hs.eg.db)









dmlTest.sm <- DMLtest(BSobj,
                      group1 = tumor_sample_names,
                      group2 = normal_sample_names,
                      smoothing = TRUE,
                      ncores = 2)





dmrs_raw <- callDMR(dmlTest.sm,
                    p.threshold = 0.01,
                    dis.merge   = 100)





dmrs <- dmrs_raw[
  elementNROWS(dmrs_raw$CpGpos) >= 3 &
  width(dmrs_raw) >= 100
]





dmrs <- dmrs[ abs(dmrs$meanDiff) > 0.2 ]




if ("qvalue" %in% names(mcols(dmrs))) {
  dmrs <- dmrs[ dmrs$qvalue < 0.05 ]
}





annots <- build_annotations(genome     = "hg38",
                            annotations = c("hg38_cpg_islands",
                                            "hg38_basic_promoters",
                                            "hg38_genes_promoters",
                                            "hg38_genes_5UTRs",
                                            "hg38_genes_exons"))


dmr_annot <- annotate_regions(regions       = dmrs,
                              annotations   = annots,
                              ignore.strand = TRUE)


cat("Annotation summary:\n")
print(table(dmr_annot$annotation))





genes <- unique(dmr_annot$gene_id[ dmr_annot$annotation == "hg38_genes_promoters" ])

enrich_go <- enrichGO(gene         = genes,
                      OrgDb        = org.Hs.eg.db,
                      keyType      = "ENSEMBL",
                      ont          = "BP",
                      pAdjustMethod= "BH",
                      qvalueCutoff = 0.05)


dotplot(enrich_go) + ggtitle("GO BP Enrichment of DMR-associated Genes")





saveRDS(dmrs, file = "filtered_DMRs.rds")

write.csv(as.data.frame(dmr_annot), file = "DMR_annotations.csv", row.names = FALSE)

write.csv(as.data.frame(enrich_go), file = "GO_enrichment.csv", row.names = FALSE)
